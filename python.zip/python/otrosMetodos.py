import numpy as np      # Libreri�a para trabajo numerico / matematico.
import sys              # Permite leer los ARGUMENTOS entregados al momento de llamar esta funcion.

from os import listdir	#...
import glob		#...
import time		#...


import cv2		#   Librería OpenCv para python. Gran parte de las funciones
			# de procesamiento de imagenes usadas.



###   --VARIABLES Y DEFINICIONES GLOBALES--   ###
kernel	 = np.ones((2, 2), np.uint8)	   # Matriz para procesar imagen (OpenCv2)
kernel2	 = np.ones((35, 35), np.uint8)  # Matriz para procesar imagen (OpenCv2). Efecto mayor.
#-----------------------------------------------------------------------------#

#------------------ METODOS --------------------------------------------------#
if __name__=='__main__':
	
	#  Lectura del parametro de entrada, al llamar desde JAVA.
	#  Adaptacion del String. Cambio de comillas.
	pathRoi = str(sys.argv[1]).replace('"', ' ');
	
	lista = sorted(glob.glob(pathRoi + "/*.tif"))  	 # Ordeno la lista de imagenes (OJO, ordena según nombre del archivo)

	img = cv2.imread(lista[1])
	img = img[:, :, 0]    				 # Tomo capa azul, ya que NO tiene letras de hora

	img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, kernel) # Aplico un filtro puntual, para eliminar el Inter-lineado
							     # en las imagenes (Ver imagenes, bordes).
							     # Esto es solo PRE-procesamiento
	
	
	im1 = np.uint8(img > 50)
	im1 = cv2.morphologyEx(im1, cv2.MORPH_ERODE,  kernel2);

	cv2.imwrite(pathRoi + '/mask.tiff', np.uint8(im1)); 






#	cv2.imshow('IMAGEN', img * np.uint8(im1))
#	cv2.waitKey(0)

#	imd = np.logical_and(np.uint8(im1), np.uint8(imd))

