import numpy as np      #Libreria para trabajo numerico / matematico
import sys              # Permite leer los ARGUMENTOS entregados al momento de llamar esta funcion.

import time		#...
import cv2		# Libreria OpenCv para python.

import scipy.signal	#...
from matplotlib import pyplot

from skimage.filters import prewitt, prewitt_h, prewitt_v #Libreria procesamiento imagenes, para calculos de gradientes (Vertical - Horizontal)
from PIL import Image, ImageDraw

###   --VARIABLES Y DEFINICIONES GLOBALES--   ###
#-----------------------------------------------#


#------------------ METODOS --------------------------------------------------#
def std_convoluted(image, N):  			#Metodo de prueba, para realizar la Desviacion Standar Local. No usado por ahora.
	im   = np.array(image, dtype=float)
	im2  = im**2
	ones = np.ones(im.shape)
	
	kernel = np.ones((2*N+1, 2*N+1))
	
	s  = scipy.signal.convolve2d(im, kernel, mode="same")
	s2 = scipy.signal.convolve2d(im2, kernel, mode="same")
	ns = scipy.signal.convolve2d(ones, kernel, mode="same")
		
	return np.sqrt((s2 - s**2 / ns) / ns)


# _METODO DETECCION DE BORDES...
def edg_detection(image, N):
	imm = cv2.medianBlur(image, 3); #Filtro mediana de 3

	kerHOR = np.array([[ 1, 1, 1],
	                   [ 0, 0, 0],
	                   [-1,-1,-1]])

	kerVER = np.array([[1, 0, -1],
			   [1, 0, -1],
                           [1, 0, -1]])

	edg_h = scipy.signal.convolve2d(imm, kerHOR, mode="valid")
	edg_v = scipy.signal.convolve2d(imm, kerVER, mode="valid")

	edg = np.sqrt(edg_v**2 + edg_h**2);
	return(edg)




# _METODO DETECCION DE BORDES.. ALTERNATIVO, PARA OTRAS PRUEBAS
def edg_deteccion2(image, N):			
	imm = cv2.medianBlur(img, 3);	#Filtro mediana de 3

	edg_h = np.sqrt(prewitt_h(imm)**2);
	edg_v =	np.sqrt(prewitt_v(imm)**2);
	
	#  Elimino los elementos menores a 0.02 
	# en ambas direcciones.
	edg_v = edg_v * np.uint8(edg_v > 0.02) #Antes era 0.05
	edg_h = edg_h * np.uint8(edg_h > 0.02)

	edg = np.sqrt(edg_v**2 + edg_h**2);

	im1 = np.uint8(edg > 0.040); # Rango Inferior.
	im2 = np.uint8(edg < 0.085); # Rango Superior.

	imm = np.logical_and(im1, im2);
	imm = 255*np.uint8(imm);
	
	return(imm)



def datoGuardar(dato):
	ff = open("datos.txt", "a")
	ff.write(str(dato))
	ff.write('\n')
	ff.close();



if __name__=='__main__':	
		
	kernel	 = np.ones((3, 3), np.uint8)	# Kernel 3x3, para aplicar funcion-Morphologica
	kernel2	 = np.ones((5, 5), np.uint8)	# Kernel 5x5, para aplicar funcion-Morphologica

	file = open("data_Python.txt", "r")
	Message = file.readlines();
	file.close();
	
	pathDir = Message[0];		#Direccion imagen actual
	pathDir = pathDir[:len(pathDir)-1];
		
	punto = Message[1].split();
	dimen = Message[2].split();
	
	pathRoi = Message[3];		#Direccion (path) de Animal a analizar
	pathRoi = pathRoi[:len(pathRoi)-1];
	
#-------------------------------------------------------------------------------------- #
	kernel	 = np.ones((2, 2), np.uint8)

	img = cv2.imread(pathDir)
	img = img[:, :, 0] #Tomo capa azul, ya que NO tiene letras de hora
	img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, kernel) #Elimino interlineado
#-------------------------------------------------------------------------------------- #

	xi = int(punto[0]);
	yi = int(punto[1]);
	dimx = int(dimen[1])
	dimy = int(dimen[0])

	mWidth  = dimx + xi;
	mHeight = dimy + yi;
	img = img[yi:mHeight, xi:mWidth]   # Segmento de la IMAGEN a cuantificar (Detectado en JAVA)
#----   --------------------------------   --------#

#--  ----------  DEFINICIO DE ZONAS Y BORDES  ----------------------------------------- --#
	imgDesv  =  std_convoluted(img, 1)   # Cuantificacion de standar Desviacion
	imgEdg   =  edg_detection(img, 1);  # Cuantificacion de Bordes


	imMsk01  = np.float64(img) / 255;
	dd       = imMsk01.shape
	imMsk01  = imMsk01[1:dd[0]-1, 1:dd[1]-1];
	im2      = cv2.multiply(imgEdg, imMsk01)

	med = np.average(im2[np.nonzero(im2)])
	im2 = cv2.multiply(im2, np.float64(im2 > med));
	med = np.average(im2[np.nonzero(im2)])
	im2 = cv2.multiply(im2, np.float64(im2 > med));

	im2 = im2 - scipy.signal.medfilt(im2, 3);
	imE = im2 > 0;   # imEdge (nombre variable)
# --------------------------------------------------------------------------------------- #

#  --------------------------------------------------------------------------- #
      # DEBO CONSTRUIR LA MASKARA
	msk2 = 2*np.float64(img);
	msk2 = np.uint8(msk2 > 255);				# SECTOR PARA CREAR UNA MASKARA EN BASE A LOS VALORES
	msk2 = cv2.morphologyEx(msk2, cv2.MORPH_ERODE, kernel2);  # MAS ALTOS. 
	dd   = msk2.shape
	mask = msk2[1:dd[0]-1, 1:dd[1]-1];
#  --------------------------------------------------------------------------- #

#  ===  Multiplicacion de la desviacion local y la maskara  === #
	imD  = np.multiply(imgDesv, msk2)
	imE2 = np.multiply(imE,  mask)
#  ===  =================================================   === #

    # _________ CUANTIFICACION ____________	
	datoD = np.sum(imD) / 50;
	datoE = np.sum(imE2);

    #______Guardar cuantificacion______
	datoGuardar(datoE)


  # ciclo for para enviar los datos a la puerta de salida
	for x in range(0, 1):	
		sys.stdout.write(str(datoD) + '_' + str(datoE) + '\n')






#	cv2.imshow('IMAG_A', np.uint8(imgEdg))
#	cv2.imwrite("borde_face2.jpg", 255*np.uint8(imE2))
#	cv2.waitKey(0)
#	cv2.imshow('IMAG_A', np.uint8(imgEdg))
#	cv2.imwrite("Pre_Analisis_A3.jpg", np.uint8(imgEdg))
#	cv2.waitKey(0)
