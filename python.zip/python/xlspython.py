import numpy as np      # Libreria para trabajo numerico / matematico.
import sys              # Permite leer los ARGUMENTOS entregados al momento de llamar esta funcion.

from math import factorial		#...
import matplotlib.pyplot as plt		#...

import xlwt
from datetime import datetime
from xlrd import open_workbook
from xlwt import Workbook
from xlutils.copy import copy
from filtrosPython import savitzky_golay
from filtrosPython import miFilter

###   --VARIABLES Y DEFINICIONES GLOBALES--   ###
#-----------------------------------------------------------------------------#


#------------------ METODOS --------------------------------------------------#
if __name__=='__main__':
	
	pathFile = '';
	if(len(sys.argv) == 2):
		pathFile = sys.argv[1];
	else:
		file = open("data_Python.txt", "r")
		Message = file.readlines();
		file.close();	

		pathRoi = Message[3];
		pathRoi = pathRoi[:len(pathRoi)-1];
		ll = len(pathRoi);
	
		pathFile = pathRoi + "/data_" + pathRoi[ll-3:ll] + ".xls"; #Construye la direccion y nombre del archivo de DATA.
	
	wx = open_workbook(pathFile)
	sheetLD = wx.sheet_by_index(0)
	sheetBD = wx.sheet_by_index(1)

 #---------------- STANDAR ---------------------------#
	data = sheetLD.col_values(5);
	data = np.array(data[2:len(data)])


      # --------- Filtros bordes ------------- #
	datFil5 = savitzky_golay(data, 11, 2); #Filtro Ruso, 5 ptos.
	datFil7 = savitzky_golay(data,  7, 2); #Filtro Ruso, 7 ptos.
	dataNo5 = miFilter(data, 5, 1);
      #----------------------------------------#

	wb = copy(wx)
	sheetCopia = wb.get_sheet(0)

	ll = len(dataNo5)
	for x in range(0, ll):
		sheetCopia.write(x+2,  6, round(dataNo5[x], 1))
		sheetCopia.write(x+2,  7, abs(round(data[x] - dataNo5[x], 1)))
		sheetCopia.write(x+2,  9, round(datFil5[x], 1))
		sheetCopia.write(x+2, 10, abs(round(data[x] - datFil5[x], 1)))



 #------------------- BORDES ----------------------------#
	data = sheetBD.col_values(5);
	data = np.array(data[2:len(data)])

       #---------- Filtros standar ----------#
	datFil5 = savitzky_golay(data, 11, 2);
	datFil7 = savitzky_golay(data,  7, 2);
	dataNo5 = miFilter(data, 5, 1);
       #-------------------------------------#	
	sheetCopia = wb.get_sheet(1)

	ll = len(dataNo5)
	for x in range(0, ll):
		sheetCopia.write(x+2,  6, round(dataNo5[x], 1))
		sheetCopia.write(x+2,  7, abs(round(data[x] - dataNo5[x], 1)))
		sheetCopia.write(x+2,  9, round(datFil5[x], 1))
		sheetCopia.write(x+2, 10, abs(round(data[x] - datFil5[x], 1)))


	wb.save(pathFile)


	
#	dataFilt = miFilter(data, 5, 1);
#	plt.plot(data, 'r', dataFilt, 'b')
#	plt.show()





