/*
 * CONJUNTO:
 *      
 * 
 * 
 * 
 * 
 * 
 */

package Abrir_guardar;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Date;

/**
 *
 * @author Felipe
 */
public class abrirObjeto{
    private FileInputStream file;
    private ObjectInputStream input;
    
public abrirObjeto(){}
    
public void abrir(String nameFile) throws IOException{
    file  = new FileInputStream(nameFile);
    input = new ObjectInputStream(file);
}

public void cerrar() throws IOException{
    if(input != null)
        input.close();
}


/**
 * Lee los objetos guardados, que guardan la informacion de las curvas y el genotipo.
 * @return objeto
 * @throws IOException
 * @throws ClassNotFoundException 
 */
public objetoGuardar2 leer() throws IOException, ClassNotFoundException{
    objetoGuardar  objet  = null;
    objetoGuardar2 objeto = null;    
    try{
        Object obb = input.readObject();
        if(obb instanceof objetoGuardar){
            //Castea al tipo de objeto original.
            objet = (objetoGuardar)obb;
            
            //Crea el nuevo objeto de salida.
            objeto = new objetoGuardar2(objet.getSerieBorde(), objet.getSerieStdLocal());
        }else
            if(obb instanceof objetoGuardar2){
                //Castea al nuevo objeto salida.
                objeto = (objetoGuardar2)obb;
            }
    }catch(IOException eof){
        System.out.println("No pudo leer, pero pasO bien !!!");
    }catch(ClassCastException e){
        System.out.println("No pudo Castear, pero paso bien !!!");
    }
    return(objeto);
}
}
