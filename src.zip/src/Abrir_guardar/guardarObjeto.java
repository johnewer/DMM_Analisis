/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Abrir_guardar;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 *
 * @author Felipe
 */
public class guardarObjeto{

    private FileOutputStream file;    
    private ObjectOutputStream output;

public guardarObjeto(String nameFile) throws FileNotFoundException, IOException{
    if(!(nameFile.endsWith(".datt") || nameFile.endsWith(".DATT")))
        nameFile = nameFile.concat(".datt");
    
    file = new FileOutputStream(nameFile);
    output = new ObjectOutputStream(file);
}
 
public void cerrar() throws IOException{
    if(output != null)
        output.close();
}

public void escribir(objetoGuardar _tDemp) throws IOException{
    if(output != null)
        output.writeObject(_tDemp);
}

public void escribir(objetoGuardar2 _tDemp) throws IOException{
    if(output != null)
        output.writeObject(_tDemp);
}

}
