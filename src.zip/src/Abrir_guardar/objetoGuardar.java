/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Abrir_guardar;

import java.io.Serializable;
import org.jfree.data.time.TimeSeries;

/**
 *
 * @author Felipe
 */
public class objetoGuardar implements Serializable{
    private TimeSeries serieBordes = null;
    private TimeSeries serieStdLoc = null;
    
    public objetoGuardar(TimeSeries _sBorde, TimeSeries _sStdLocal){
        serieBordes = _sBorde;
        serieStdLoc = _sStdLocal;
    }
    
    public TimeSeries getSerieBorde(){
        return(serieBordes);
    }
    public TimeSeries getSerieStdLocal(){
        return(serieStdLoc);
    }
    
}
