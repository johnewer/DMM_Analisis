/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Abrir_guardar;

import java.io.Serializable;
import org.jfree.data.time.TimeSeries;

/**
 *
 * @author Felipe
 */
public class objetoGuardar2 implements Serializable{
    private TimeSeries serieBordes = null;
    private TimeSeries serieStdLoc = null;
    private String Genotipe   = "";
    private String HoraColect = "--:--";
    
    public objetoGuardar2(){
    }
    
    public objetoGuardar2(TimeSeries _sBorde, TimeSeries _sStdLocal){
        serieBordes = _sBorde;
        serieStdLoc = _sStdLocal;
        Genotipe    = "";
        HoraColect  = "--:--";
    }
    
    public objetoGuardar2(TimeSeries _sBorde, TimeSeries _sStdLocal, 
            String _Genotipe, String _HoraColect){
        serieBordes = _sBorde;
        serieStdLoc = _sStdLocal;
        Genotipe    = _Genotipe;
        HoraColect  = _HoraColect; 
    }
    
    public TimeSeries getSerieBorde(){
        return(serieBordes);
    }
    public TimeSeries getSerieStdLocal(){
        return(serieStdLoc);
    }
    public String getGenotipe(){
        return(Genotipe);
    }
    public String getHoraColect(){
        return(HoraColect);
    }
    
// Carga de la data, al momento de volver a crear.
    /**
     * Carga la serie con Desviacion estandar.
     * @param _sStdLocal 
     */
    public void setTimeLocal(TimeSeries _sStdLocal){
        serieStdLoc = _sStdLocal;
    }
    /**
     * Carga la serie de Bordes.
     * @param _sBorde 
     */
    public void setTimeBorde(TimeSeries _sBorde){
        serieBordes = _sBorde;
    }
    
    
    
    public int setGenotipe(String _Genotipe){
        Genotipe = _Genotipe;
        return(0);
    }
    public int setHoraColect(String _HoraColect){
        HoraColect = _HoraColect;
        return(0);
    }
    
    
    
}
