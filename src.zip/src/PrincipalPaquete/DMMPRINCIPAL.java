/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PrincipalPaquete;

import com.sun.media.jai.codec.FileSeekableStream;
import com.sun.media.jai.codec.ImageCodec;
import com.sun.media.jai.codec.ImageEncoder;
import com.zfqjava.swing.JDirChooser;
import hebras.jFormatoMatlab;
import hebras.jhebraDetectar;
import hebras.jhebraEncontrar;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.image.renderable.ParameterBlock;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.media.jai.JAI;
import javax.media.jai.KernelJAI;
import javax.media.jai.PlanarImage;
import javax.media.jai.RenderedOp;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartMouseListener;
import org.jfree.chart.ChartPanel;
import org.jfree.data.Range;
import org.jfree.data.time.Minute;


/**
 *  CLASE PRINCIPAL DE TODO EL SISTEMA. 
 *  "INTERFACE DE USUARIO" que permite controlar la totalidad de los procesos.<p> 
 * @author Felipe
 */
public class DMMPRINCIPAL extends javax.swing.JFrame {

    /** 
     * OJO, PARA UN CORRECTO FUNCIONAMIENTO, MUCHAS COSAS SE CONTROLAN 
     * EN BASE A OTRAS, POR ENDE ESTE ES UN OBJETO QUE CONTENDRÁ CONTROLES 
     * VARIADOS, QUE COMPARTEN TODOS LOS OBJETOS EMBLEMATICOS.ESTO AYUDARÁ 
     * A ORGANIZAR LO QUE DEBE OCURRIR ENTRE OBJETOS, AL MOMENTO DE OCURRIR 
     * ALGUN EVENTO.<p>
     *      mCONTROL: Es un objeto que guarda una serie de variables de control, 
     *      booleanas para manejar la ejecuciòn de diferentes eventos, y està 
     *      conectada entre todos los objetos principales de este sistema, 
     *      siendo el mismo en cada uno de los objetos principales.
     *
     */
    public jCONTROLES mCONTROL = new jCONTROLES();{
    /* index  0 = Control de separacion de imagenes.
     * index  1 = Control TODO bien.
     * index  2 = Control de Inicio de analisis de datos.
     * index  3 = Control de graficas a mostrar.
     * index  4 = ...
     * index  5 = ...
     * index  6 = Control de eventos generales de ANALIZAR !.
     * index  7 = Control guardar data.
     * index 10 = Control ejecucion hebra de separación. Experimento completo.
     * index -- = ...
     * index 19 = ???
     * index 20 = Control hebra graficos.
    */
}
//  Set de codigos que serán enviados a MATLAB.
    public static int codError  = 1000;
    public static int codActiv  = 1001;
    public static int codAnalis = 1011;
    //---- Usados ---- //
    public static int codPrueba = 1013; //Codigo para llevar variables a ind = 0
    public static int codFondo  = 1012;
    
    public static int codOtros  = 1331; //Codigo para pruebas
// ---------------------------------------------------------------- \\
    /**
     * Hebras de detecciòn y anàlisis.
     */ 
    public jhebraDetectar mi_hebra     = null;
    /**
     * Hebra para encontrar las imàgenes perdidas.
     */
    public jhebraEncontrar hebraBuscar = null;
    /**
     *Timer control video reproductor principal.
     */
    public Timer timeStamp   = null;
    /**
     *Timer control avance y retroceso continuo (Video).
     */
    public Timer runContinA  = null;
    
    /**
     *Timer control avance y retroceso continuo (Anàlisis). 
     */
    public Timer runContinB  = null;

    /**
     * Lista de imàgenes a separar.
     */
    public String direc[]    = null;
    public File   direcT[]   = null;
    
    /**
     * Lista de imagenes a analizar.
     */
    public String direc2[]   = null;
    
    /**
     * Lista de animales a trabajar.
     */
    public String listExper[] = null;
    
    /**
     * Directorio (Path) de las imagenes de un experimento completo.
     */
    public String jPathImage         = "";
    /**
     * Directorio destino separacion de experimento.
     */
    public String jPathSeparacion    = ":\\";
    /**
     * Directorio (Path) experimento para anàlisis.
     */
    public String jPathAnalisis      = ":\\";
    /**
     * Directorio (Path) 
     */
    public String jPathDirecAnalisis = ":\\";
    /**
     * Directorio (Path) del experimento para visualizar los gràficos que 
     * queremos trabajar.
     */
    public String jPathGraficos      = "";
    /**
     * PreFijos para las carpetas de cada animal. Para la separaciòn.
     */
    public String preFijos[] = {"Imag_", "Expr_", "Mosc_"};
    /**
     * Carga la lista de IMÀGENES de un ANIMAL a analizar.
     */
    public String[] direc_2;
    
    /**
    * Esto para controlar acciones con las teclas. Yo prefiero el teclado.
    */
    public final InputMap  inputMap  = getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
    public final ActionMap actionMap = getRootPane().getActionMap(); 
    
    /**
     * Lista que guardará el experimento y las caracterìsticas de grupo de animales.
     */ 
    public List listSetImagenes = new LinkedList();   
    /** 
     * Lista de imagenes de control en la SEPARACIÒN.
     */
    public List listImgSeparar  = new LinkedList();
    
// -------------- VARIABLES GLOBALES DE TIPO INT !!! ----------------------- \\
    
    /** 
     * Valor que define el aspecto segùn la plataforma empleada. Inicaremos
     * trabajo con Mac y Ubuntu, los cuales puede que cambien el valor usado.
        TIPO_UI = 2 para Windows.
        TIPO_UI = 3 para Mac.
     */
    public int TIPO_UI = 3;
    /**
     * Tiempo para cada timer. Avance !.
     */
    public int timControl  = 200;
    /**
     * Controla la posiciòn de la imagen a REPRODUCIR dentro 
     * de la lista general.
     */ 
    public int INDICE      = -1;
    /**
     * Controla la posiciòn de la imagen a ANALIZAR.
     */
    public int INDICE_2    = -1;    
    /**
     * Factor de CUANTO debe avanzar la reproduccion de las imagenes.
     */
    public int salReprod   =  1;    
    /**
     * Control numèrico, que sirve para indicar si se debe avanzar o retroceder 
     * en la muestra de imàgenes. Usado por los botones de avance y retroceso.
     */
    public int direcRec    =  0;
    /**
     * Indica a Matlab que imagen mostrar en el anàlisis.
     */
    public int tipoImagen  =  0;
    /**
     * Nombre_numero para cada carpeta.
     */
    public int conFold     =  1001; //control para nombres de carpetas.

    public UIManager.LookAndFeelInfo apariencias[];
    public miBoton mBoton = new miBoton("INICIAR");
    
    public jBorrar fBorrador = new jBorrar();
   /**
     * MATRIX: Es un vector que se usa para pasar una imagen en color, a escala
     * de grises. Para realizar esto, se toma una proporciòn de cada una de las
     * componentes RGB y se suman. En este caso, la imagen es en escala de grises,
     * y por ende, con tomar una de las 3 capas es suficiente. En imagnes a color, 
     * se hace necesario definir (Puede ser lo comentado) que aporte harà cada
     * componente a*R + b*G + c*B.<p>
     * <p>
     *      MATRIX = {{ a, b, c }}
     * <p>
     * double[ ][ ] MATRIX = {{ 0.3D, 0.59D, 0.11D, 0D }};                   <p>
     * double[ ][ ] MATRIX = {{ 0.2D, 0.7D, 0.1D,   0D }};    
     */
        public double[][] MATRIX = {{ 0.0D, 0.0D, 1.0D, 0D }};
//    public double[][] MATRIX = {{ 1.0D, 0.0D, 0.0D }};
    /**
     * Arreglo usado para corregir el interlineado de las 
     * imàgenes, producto de la digitalizaciòn.
     */
    public float[] kLine = {1,1,1,1};
    
    /**
     * Objeto principal de ANÀLISIS.
     */
    public jAnalisis     jOb_Analisis = null;
    /**
     * Objeto ANÀLISIS experimento completo.
     */
    public jExperimento  expeRimento  = null;
    /**
     * OBJ: Para gràficar analisis actual.
     */
    public  jPlot_times  dataGrafico  = new jPlot_times(mCONTROL);
    /**
     * OBJ: Para graficar experimento completo. Analisis de experimento
     */
    public  jPlot_times  generalGraf  = null; //new jPlot_times(mCONTROL);
    /**
     * OBJ: Panel de graficos.
     */
    public ChartPanel temChart2 = null;
    
    public File pathGrafico = new File("."); 
//    public File pathGrafico = new File("/media/felipe/DATA/aCiNV_Mayo 2016/EXP_2017/Datos John/GENERAL/NORMAL"); //
    
    /**
     * OBJ: Para dar formato a los datos
     */
    public jFormatoMatlab formatoMatlab = null; //new jFormatoMatlab();
    
    /**
     * OBJ: Hora / Fecha apagado de la luz
     */
    public Date horaRefInit = null;
            
// Objeto para limpiar la memoria que queda como basura. \\
    Runtime LimpiadorMemoria = Runtime.getRuntime();
//---------------------------------------------------------\\
    
    /**
     * Creates new form DMMPRINCIPAL
     */
    public DMMPRINCIPAL() {
        initComponents();
        crearTimer();
        keyEscucha();
        
        jPanel7.setMinimumSize(null); //Debo entender porque use este objeto en nada.
        
    // ------------   CREAR OBJETOS EMBLEMATICOS   ------------ \\
        dataGrafico   = new jPlot_times(mCONTROL);
        generalGraf   = new jPlot_times(mCONTROL);
        jOb_Analisis  = new jAnalisis(mCONTROL, mBoton);
        formatoMatlab = new jFormatoMatlab();
    // -------------------------------------------------------- \\

        jPanelAnalisis.add(jOb_Analisis);
        
        jProgreso.setValue(0);
        jProgreso_2.setValue(0);
        jProgreso.setStringPainted(true);
        jProgreso_2.setStringPainted(true);
        
    //..... Referencia horaria APAGADO..........\\    
        horaRefInit = new Date();
        jOb_Analisis.horaRefInit = horaRefInit;
        dataGrafico.horaRefInit  = horaRefInit;
        generalGraf.horaRefInit  = horaRefInit;
        
    //--------------  HEBRAS ENCARGADAS DE BUSCAR. ---------------------- \\
        /** 
         * Hebra usada para trabajar cada animal por separado.
         */
        mi_hebra    = new jhebraDetectar(jImgPr, jProgreso);
        
        /** Hebra encargada de BUSCAR un experimento completo. Carga por cada 
         * busqueda, la hebra mi_hebra que se encarga de buscar un animal en 
         * especìfico.
         */
        hebraBuscar = new jhebraEncontrar(mi_hebra, jList_names, mCONTROL);
    //\ -------------------------------------------------------------------- /\\    
        
    // ---------------------------------------------------------------------- \\     
        jSpi_Tolerancia.setModel(new SpinnerNumberModel(2.0, 0.0, 100.0, 0.1));
        jSalto.setModel(new SpinnerNumberModel(1, 1, 10, 1));
        jRango.setModel(new SpinnerNumberModel(719.98, 718.00, 10000.0, 0.02));
        jVelocidadPlay.setModel(new SpinnerNumberModel(200, 100, 2000, 100));
        jS_CicloLuz.setModel(new SpinnerNumberModel(12, 6, 24, 3));
        jS_hInicio.setModel(new SpinnerNumberModel(10, 0, 11, 1));
        jSp_Datpuntos.setModel(new SpinnerNumberModel(4, 2, 8, 1));
        jSpi_Tolerancia.setModel(new SpinnerNumberModel(2.5, 0.5, 8.0, 0.1));
        
        jSp_UmbralGraf.setModel(new SpinnerNumberModel(100, 40, 250, 5));
        
   //\ --------------------------------------------------------------------- /\\
        jDatos.setVisible(true);

        jScrollPane2.setVisible(false);
        jScrollPane2.setSize(340, 150);
        jTab_Analisis.setEnabledAt(2, false); // NO habilitar.
        jTab_Analisis.setEnabledAt(3, false);
        
        //Este ChartPanel es para el momento de realizar el analisis. NO para mostrar.
        dataGrafico.setViewNameSerie(false);
        ChartPanel temChart = new ChartPanel(dataGrafico.getchartPanel().getChart());
        temChart.setPreferredSize(new java.awt.Dimension(355, 210));
        jPlot_panel.add(temChart);
        
        temChart2 = new ChartPanel(generalGraf.getchartPanel().getChart());
        
        jTabbedPane5.addTab("PLOT", temChart2);
        jTabbedPane5.setSelectedIndex(1);
        
        //OJO, Aca conecto ambos objetos, para que conversen entre ellos
        expeRimento = new jExperimento(jOb_Analisis, mBoton, mCONTROL);
        jOb_Analisis.setObjExperimen(expeRimento);
        jOb_Analisis.setContenedor(jPanelAnalisis.getComponents(), jP_Genotipol_Hora.getComponents());
        jOb_Analisis.setFrameForma(this);
        
        jOb_Analisis.mBotonSet = jB_SET;
        
        
        expeRimento.miGrafico  = dataGrafico;
        jOb_Analisis.miGrafico = dataGrafico;
        mCONTROL.setControl(1, true); //Seteo inicialmente que guarde TODO !.
        
        dataGrafico.setViewY_Range(false);
        dataGrafico.setEscalaPlot(0, 10000);
        jTableGraficos.setShowGrid(true);
        
   //  0 oooooooooooooooooooooooooooooooooooooooooooooooooooooooo 0 \\
            initMisDatos(TIPO_UI); //INICIO MIS DATOS...
   //  0 oooooooooooooooooooooooooooooooooooooooooooooooooooooooo 0 \\
            
   //  0 ---Init otras CONFIGURACIONES--------------------------- 0 \\ 
            Spinner_Configuration();
    //--------------------------------------------------------------\\        
            
        LimpiadorMemoria.gc();
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanelImagenes = new javax.swing.JPanel();
        jAbrirImag = new javax.swing.JButton();
        jImgPr = new javax.swing.JLabel();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jB_Separacion = new javax.swing.JButton();
        jB_StopSeparacion = new javax.swing.JButton();
        jPanel14 = new javax.swing.JPanel();
        jSecuDestino = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jImag_Lista = new javax.swing.JComboBox();
        jCheck_BATCH = new javax.swing.JCheckBox();
        jList_names = new javax.swing.JComboBox();
        jPanel3 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jSpi_Tolerancia = new javax.swing.JSpinner();
        jRango = new javax.swing.JSpinner();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jVelocidadPlay = new javax.swing.JSpinner();
        jLabel7 = new javax.swing.JLabel();
        jSalto = new javax.swing.JSpinner();
        jLabel9 = new javax.swing.JLabel();
        jPathImagenes = new javax.swing.JTextField();
        j_Atras = new javax.swing.JButton();
        j_Adelante = new javax.swing.JButton();
        jTexIndice = new javax.swing.JTextField();
        jIndice = new javax.swing.JLabel();
        jCONTROL = new javax.swing.JButton();
        jTexFile = new javax.swing.JTextField();
        jName_file = new javax.swing.JLabel();
        jProgreso = new javax.swing.JProgressBar();
        jDatos = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jPanelAnalisis = new javax.swing.JPanel();
        jDirectorio_2 = new javax.swing.JTextField();
        jB_AbrirAnalisis = new javax.swing.JButton();
        jTab_Analisis = new javax.swing.JTabbedPane();
        jPanel20 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jSp_Fecha = new javax.swing.JSpinner();
        jPanel1 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jTipoData = new javax.swing.JComboBox();
        jActivarArea = new javax.swing.JRadioButton();
        jButton9 = new javax.swing.JButton();
        jP_Genotipol_Hora = new javax.swing.JPanel();
        jGenotype = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jComb_Hora = new javax.swing.JComboBox();
        jComb_Min = new javax.swing.JComboBox();
        jB_SET = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jExper_Inf = new javax.swing.JSpinner();
        jExper_Sup = new javax.swing.JSpinner();
        jT_IndeSup = new javax.swing.JTextField();
        jT_IndeInf = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jPanel21 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jVerAnalis = new javax.swing.JComboBox();
        jPanel6 = new javax.swing.JPanel();
        jComboBox1 = new javax.swing.JComboBox();
        jBut_SaveData = new javax.swing.JButton();
        jImg_izq = new javax.swing.JButton();
        jImg_der = new javax.swing.JButton();
        jProgreso_2 = new javax.swing.JProgressBar();
        jImg_view = new javax.swing.JTextField();
        jTxTotal = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jTxIndice_2 = new javax.swing.JTextField();
        jPlot_panel = new javax.swing.JPanel();
        jStop_Analis = new javax.swing.JButton();
        jP_Test = new javax.swing.JPanel();
        jControl_Analisis = new javax.swing.JComboBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();
        jButton4 = new javax.swing.JButton();
        jPanelGraficos = new javax.swing.JPanel();
        jSplitPane1 = new javax.swing.JSplitPane();
        jSplitPane2 = new javax.swing.JSplitPane();
        jPanel11 = new javax.swing.JPanel();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTableGraficos = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableCambiar = new javax.swing.JTable();
        jScrollPane6 = new javax.swing.JScrollPane();
        jPanel22 = new javax.swing.JPanel();
        jSplitPane3 = new javax.swing.JSplitPane();
        jTabbedPane5 = new javax.swing.JTabbedPane();
        jPanel23 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jCheckBox2 = new javax.swing.JCheckBox();
        jScrollBar1 = new javax.swing.JScrollBar();
        jScrollPane3 = new javax.swing.JScrollPane();
        jPanel7 = new javax.swing.JPanel();
        jTabbedPane7 = new javax.swing.JTabbedPane();
        jPanel28 = new javax.swing.JPanel();
        jTFiltro = new javax.swing.JComboBox();
        jTData = new javax.swing.JComboBox();
        jLabel14 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jC_Color = new javax.swing.JComboBox();
        jPanel26 = new javax.swing.JPanel();
        jActivarCurva = new javax.swing.JRadioButton();
        jButton10 = new javax.swing.JButton();
        jSp_Datpuntos = new javax.swing.JSpinner();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTabData = new javax.swing.JTable();
        jPanel18 = new javax.swing.JPanel();
        jControTiempo = new javax.swing.JRadioButton();
        jLabel17 = new javax.swing.JLabel();
        jTiempoMin = new javax.swing.JTextField();
        jButton3 = new javax.swing.JButton();
        jPanel27 = new javax.swing.JPanel();
        jTextField4 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jPanel12 = new javax.swing.JPanel();
        jComboBox3 = new javax.swing.JComboBox();
        jS_CicloLuz = new javax.swing.JSpinner();
        jS_hInicio = new javax.swing.JSpinner();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jB_ResetCurvas = new javax.swing.JButton();
        jB_VerCurvas = new javax.swing.JButton();
        jPath_Graficos = new javax.swing.JTextField();
        jB_AbrirGraficos = new javax.swing.JButton();
        jP_Umbral = new javax.swing.JPanel();
        jSp_UmbralGraf = new javax.swing.JSpinner();
        jPanel17 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        j_Abrir = new javax.swing.JMenuItem();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenuItem8 = new javax.swing.JMenuItem();
        jMenuItem9 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jActiv = new javax.swing.JMenu();
        jAnalisis = new javax.swing.JRadioButtonMenuItem();
        jR_Shape = new javax.swing.JRadioButtonMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jRadioButtonMenuItem1 = new javax.swing.JRadioButtonMenuItem();
        jMenu3 = new javax.swing.JMenu();
        jComp = new javax.swing.JMenu();
        jRDesvia = new javax.swing.JRadioButtonMenuItem();
        jRBordes = new javax.swing.JRadioButtonMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1124, 730));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                formKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                formKeyReleased(evt);
            }
        });

        jTabbedPane1.setBorder(null);
        jTabbedPane1.setMinimumSize(new java.awt.Dimension(1124, 701));
        jTabbedPane1.setName(""); // NOI18N

        jPanelImagenes.setFont(new java.awt.Font("Ubuntu", 0, 15)); // NOI18N
        jPanelImagenes.setLayout(null);

        jAbrirImag.setText("Abrir");
        jAbrirImag.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jAbrirImagActionPerformed(evt);
            }
        });
        jPanelImagenes.add(jAbrirImag);
        jAbrirImag.setBounds(400, 10, 60, 25);

        jImgPr.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagneess/earth.jpg"))); // NOI18N
        jImgPr.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jImgPr.setOpaque(true);
        jPanelImagenes.add(jImgPr);
        jImgPr.setBounds(40, 40, 640, 480);

        jPanel4.setLayout(null);

        jB_Separacion.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jB_Separacion.setForeground(new java.awt.Color(0, 0, 255));
        jB_Separacion.setText("FIJAR");
        jB_Separacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_SeparacionActionPerformed(evt);
            }
        });
        jPanel4.add(jB_Separacion);
        jB_Separacion.setBounds(75, 95, 100, 50);
        jB_Separacion.getAccessibleContext().setAccessibleDescription("");

        jB_StopSeparacion.setText("Parar");
        jB_StopSeparacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jB_StopSeparacionActionPerformed(evt);
            }
        });
        jPanel4.add(jB_StopSeparacion);
        jB_StopSeparacion.setBounds(190, 105, 60, 30);

        jPanel14.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Destino:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(0, 51, 255))); // NOI18N
        jPanel14.setLayout(null);

        jSecuDestino.setText(":\\");
            jSecuDestino.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jSecuDestinoActionPerformed(evt);
                }
            });
            jPanel14.add(jSecuDestino);
            jSecuDestino.setBounds(20, 30, 230, 28);

            jButton1.setText("...");
            jButton1.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jButton1ActionPerformed(evt);
                }
            });
            jPanel14.add(jButton1);
            jButton1.setBounds(270, 30, 30, 20);

            jPanel4.add(jPanel14);
            jPanel14.setBounds(14, 10, 330, 70);

            jLabel6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
            jPanel4.add(jLabel6);
            jLabel6.setBounds(50, 110, 190, 20);

            jImag_Lista.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Fijar", "Lista", "Imagen" }));
            jImag_Lista.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jImag_ListaActionPerformed(evt);
                }
            });
            jPanel4.add(jImag_Lista);
            jImag_Lista.setBounds(265, 110, 90, 28);

            jCheck_BATCH.setSelected(true);
            jCheck_BATCH.setText("BATCH");
            jCheck_BATCH.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jCheck_BATCHActionPerformed(evt);
                }
            });
            jPanel4.add(jCheck_BATCH);
            jCheck_BATCH.setBounds(200, 162, 80, 24);

            jList_names.setMaximumRowCount(5);
            jList_names.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "..." }));
            jPanel4.add(jList_names);
            jList_names.setBounds(70, 160, 120, 28);

            jTabbedPane3.addTab("SEPARAR", jPanel4);

            jPanel3.setLayout(null);

            jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "CALIBRACION SEPARACION:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(0, 0, 255))); // NOI18N
            jPanel9.setLayout(null);

            jSpi_Tolerancia.setOpaque(false);
            jSpi_Tolerancia.setValue(new Double(3.2));
            jSpi_Tolerancia.addChangeListener(new javax.swing.event.ChangeListener() {
                public void stateChanged(javax.swing.event.ChangeEvent evt) {
                    jSpi_ToleranciaStateChanged(evt);
                }
            });
            jPanel9.add(jSpi_Tolerancia);
            jSpi_Tolerancia.setBounds(140, 54, 80, 28);

            jRango.addChangeListener(new javax.swing.event.ChangeListener() {
                public void stateChanged(javax.swing.event.ChangeEvent evt) {
                    jRangoStateChanged(evt);
                }
            });
            jPanel9.add(jRango);
            jRango.setBounds(140, 22, 80, 28);

            jLabel8.setForeground(new java.awt.Color(0, 0, 255));
            jLabel8.setText("Rango (s):");
            jPanel9.add(jLabel8);
            jLabel8.setBounds(31, 33, 80, 20);

            jLabel11.setForeground(new java.awt.Color(0, 0, 255));
            jLabel11.setText("Tolerancia:");
            jPanel9.add(jLabel11);
            jLabel11.setBounds(31, 55, 80, 20);

            jPanel3.add(jPanel9);
            jPanel9.setBounds(10, 110, 340, 90);

            jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "REPRODUCCION VIDEO:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(0, 0, 255))); // NOI18N
            jPanel10.setLayout(null);

            jVelocidadPlay.addChangeListener(new javax.swing.event.ChangeListener() {
                public void stateChanged(javax.swing.event.ChangeEvent evt) {
                    jVelocidadPlayStateChanged(evt);
                }
            });
            jPanel10.add(jVelocidadPlay);
            jVelocidadPlay.setBounds(140, 20, 80, 28);

            jLabel7.setForeground(new java.awt.Color(0, 0, 255));
            jLabel7.setText("Velocidad:");
            jPanel10.add(jLabel7);
            jLabel7.setBounds(40, 32, 85, 18);

            jSalto.addChangeListener(new javax.swing.event.ChangeListener() {
                public void stateChanged(javax.swing.event.ChangeEvent evt) {
                    jSaltoStateChanged(evt);
                }
            });
            jPanel10.add(jSalto);
            jSalto.setBounds(140, 50, 80, 28);

            jLabel9.setForeground(new java.awt.Color(0, 0, 255));
            jLabel9.setText("Salto (ms):");
            jPanel10.add(jLabel9);
            jLabel9.setBounds(37, 52, 85, 18);

            jPanel3.add(jPanel10);
            jPanel10.setBounds(10, 10, 340, 90);

            jTabbedPane3.addTab("CALIBRACION", jPanel3);

            jPanelImagenes.add(jTabbedPane3);
            jTabbedPane3.setBounds(700, 280, 370, 240);

            jPathImagenes.setText(":\\");
                jPathImagenes.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        jPathImagenesActionPerformed(evt);
                    }
                });
                jPathImagenes.addKeyListener(new java.awt.event.KeyAdapter() {
                    public void keyPressed(java.awt.event.KeyEvent evt) {
                        jPathImagenesKeyPressed(evt);
                    }
                });
                jPanelImagenes.add(jPathImagenes);
                jPathImagenes.setBounds(40, 10, 340, 28);

                j_Atras.setText("<<");
                j_Atras.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
                j_Atras.addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mousePressed(java.awt.event.MouseEvent evt) {
                        j_AtrasMousePressed(evt);
                    }
                    public void mouseReleased(java.awt.event.MouseEvent evt) {
                        j_AtrasMouseReleased(evt);
                    }
                });
                j_Atras.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
                    public void mouseDragged(java.awt.event.MouseEvent evt) {
                        j_AtrasMouseDragged(evt);
                    }
                    public void mouseMoved(java.awt.event.MouseEvent evt) {
                        j_AtrasMouseMoved(evt);
                    }
                });
                j_Atras.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        j_AtrasActionPerformed(evt);
                    }
                });
                jPanelImagenes.add(j_Atras);
                j_Atras.setBounds(190, 600, 70, 30);

                j_Adelante.setText(">>");
                j_Adelante.addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mousePressed(java.awt.event.MouseEvent evt) {
                        j_AdelanteMousePressed(evt);
                    }
                    public void mouseReleased(java.awt.event.MouseEvent evt) {
                        j_AdelanteMouseReleased(evt);
                    }
                });
                j_Adelante.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        j_AdelanteActionPerformed(evt);
                    }
                });
                jPanelImagenes.add(j_Adelante);
                j_Adelante.setBounds(480, 600, 70, 30);

                jTexIndice.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
                jTexIndice.setText("00");
                jTexIndice.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        jTexIndiceActionPerformed(evt);
                    }
                });
                jPanelImagenes.add(jTexIndice);
                jTexIndice.setBounds(610, 525, 70, 25);

                jIndice.setText("INDICE");
                jPanelImagenes.add(jIndice);
                jIndice.setBounds(630, 560, 55, 18);

                jCONTROL.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
                jCONTROL.setText("INICIO");
                jCONTROL.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        jCONTROLActionPerformed(evt);
                    }
                });
                jPanelImagenes.add(jCONTROL);
                jCONTROL.setBounds(290, 560, 160, 50);

                jTexFile.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
                jTexFile.addActionListener(new java.awt.event.ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        jTexFileActionPerformed(evt);
                    }
                });
                jPanelImagenes.add(jTexFile);
                jTexFile.setBounds(810, 555, 240, 26);

                jName_file.setText("NOMBRE:");
                jPanelImagenes.add(jName_file);
                jName_file.setBounds(730, 562, 75, 18);

                jProgreso.addMouseListener(new java.awt.event.MouseAdapter() {
                    public void mouseClicked(java.awt.event.MouseEvent evt) {
                        jProgresoMouseClicked(evt);
                    }
                });
                jProgreso.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
                    public void mouseDragged(java.awt.event.MouseEvent evt) {
                        jProgresoMouseDragged(evt);
                    }
                });
                jPanelImagenes.add(jProgreso);
                jProgreso.setBounds(50, 530, 550, 15);

                jDatos.setBackground(new java.awt.Color(255, 255, 255));
                jDatos.setBorder(javax.swing.BorderFactory.createEtchedBorder());
                jDatos.setOpaque(true);
                jPanelImagenes.add(jDatos);
                jDatos.setBounds(700, 40, 370, 230);

                jTextField5.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
                jTextField5.setText("00");
                jPanelImagenes.add(jTextField5);
                jTextField5.setBounds(570, 10, 65, 28);

                jLabel3.setText("Total");
                jPanelImagenes.add(jLabel3);
                jLabel3.setBounds(525, 14, 40, 18);

                jTabbedPane1.addTab(" SECUENCIAS ", jPanelImagenes);

                jPanelAnalisis.setLayout(null);

                jDirectorio_2.setText(":\\");
                    jDirectorio_2.addMouseListener(new java.awt.event.MouseAdapter() {
                        public void mouseClicked(java.awt.event.MouseEvent evt) {
                            jDirectorio_2MouseClicked(evt);
                        }
                    });
                    jDirectorio_2.addKeyListener(new java.awt.event.KeyAdapter() {
                        public void keyPressed(java.awt.event.KeyEvent evt) {
                            jDirectorio_2KeyPressed(evt);
                        }
                    });
                    jPanelAnalisis.add(jDirectorio_2);
                    jDirectorio_2.setBounds(40, 10, 340, 28);

                    jB_AbrirAnalisis.setText("Abrir");
                    jB_AbrirAnalisis.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jB_AbrirAnalisisActionPerformed(evt);
                        }
                    });
                    jPanelAnalisis.add(jB_AbrirAnalisis);
                    jB_AbrirAnalisis.setBounds(-450, 0, 60, 25);

                    jTab_Analisis.setAutoscrolls(true);

                    jPanel20.setLayout(null);

                    jLabel16.setFont(new java.awt.Font("Ubuntu", 1, 16)); // NOI18N
                    jLabel16.setForeground(new java.awt.Color(0, 0, 255));
                    jLabel16.setText("Apagado (HH/mm):");
                    jPanel20.add(jLabel16);
                    jLabel16.setBounds(40, 45, 150, 19);

                    jSp_Fecha.setFont(new java.awt.Font("Ubuntu", 0, 16)); // NOI18N
                    jSp_Fecha.setModel(new javax.swing.SpinnerDateModel());
                    jSp_Fecha.setEditor(new javax.swing.JSpinner.DateEditor(jSp_Fecha, ""));
                    jSp_Fecha.addChangeListener(new javax.swing.event.ChangeListener() {
                        public void stateChanged(javax.swing.event.ChangeEvent evt) {
                            jSp_FechaStateChanged(evt);
                        }
                    });
                    jPanel20.add(jSp_Fecha);
                    jSp_Fecha.setBounds(100, 70, 190, 35);

                    jTab_Analisis.addTab("H. APAGADO", jPanel20);

                    jPanel1.setLayout(null);

                    jPanel13.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Zonas:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N
                    jPanel13.setLayout(null);

                    jTipoData.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Ambos", "Busqueda", "Analisis" }));
                    jTipoData.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jTipoDataActionPerformed(evt);
                        }
                    });
                    jPanel13.add(jTipoData);
                    jTipoData.setBounds(40, 30, 100, 28);

                    jActivarArea.setText("Ver");
                    jActivarArea.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jActivarAreaActionPerformed(evt);
                        }
                    });
                    jPanel13.add(jActivarArea);
                    jActivarArea.setBounds(150, 30, 50, 24);

                    jButton9.setText("...");
                    jButton9.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jButton9ActionPerformed(evt);
                        }
                    });
                    jPanel13.add(jButton9);
                    jButton9.setBounds(208, 30, 30, 30);

                    jPanel1.add(jPanel13);
                    jPanel13.setBounds(10, 10, 250, 80);

                    jP_Genotipol_Hora.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

                    jGenotype.setEditable(true);
                    jGenotype.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Per01", "PerS", "CS", "" }));
                    jGenotype.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jGenotypeActionPerformed(evt);
                        }
                    });

                    jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
                    jLabel1.setForeground(new java.awt.Color(0, 0, 255));
                    jLabel1.setText("Genotype:");

                    jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
                    jLabel15.setForeground(new java.awt.Color(0, 0, 255));
                    jLabel15.setText("Time:");

                    jComb_Hora.setFont(new java.awt.Font("Ubuntu", 0, 10)); // NOI18N
                    jComb_Hora.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--", "00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23" }));
                    jComb_Hora.setMinimumSize(new java.awt.Dimension(44, 25));
                    jComb_Hora.setPreferredSize(new java.awt.Dimension(44, 25));
                    jComb_Hora.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jComb_HoraActionPerformed(evt);
                        }
                    });

                    jComb_Min.setFont(new java.awt.Font("Ubuntu", 0, 10)); // NOI18N
                    jComb_Min.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "--", "00", "15", "30", "45" }));
                    jComb_Min.setMinimumSize(new java.awt.Dimension(44, 25));
                    jComb_Min.setPreferredSize(new java.awt.Dimension(44, 25));
                    jComb_Min.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jComb_MinActionPerformed(evt);
                        }
                    });

                    javax.swing.GroupLayout jP_Genotipol_HoraLayout = new javax.swing.GroupLayout(jP_Genotipol_Hora);
                    jP_Genotipol_Hora.setLayout(jP_Genotipol_HoraLayout);
                    jP_Genotipol_HoraLayout.setHorizontalGroup(
                        jP_Genotipol_HoraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jP_Genotipol_HoraLayout.createSequentialGroup()
                            .addGap(11, 11, 11)
                            .addGroup(jP_Genotipol_HoraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jP_Genotipol_HoraLayout.createSequentialGroup()
                                    .addComponent(jLabel15)
                                    .addGap(8, 8, 8)))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jP_Genotipol_HoraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jP_Genotipol_HoraLayout.createSequentialGroup()
                                    .addComponent(jComb_Hora, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jComb_Min, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jGenotype, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    );
                    jP_Genotipol_HoraLayout.setVerticalGroup(
                        jP_Genotipol_HoraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jP_Genotipol_HoraLayout.createSequentialGroup()
                            .addContainerGap()
                            .addGroup(jP_Genotipol_HoraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jGenotype, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel1))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jP_Genotipol_HoraLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel15)
                                .addComponent(jComb_Hora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jComb_Min, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    );

                    jPanel1.add(jP_Genotipol_Hora);
                    jP_Genotipol_Hora.setBounds(10, 90, 250, 100);

                    jB_SET.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
                    jB_SET.setText("---");
                    jB_SET.setToolTipText("");
                    jB_SET.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jB_SETActionPerformed(evt);
                        }
                    });
                    jPanel1.add(jB_SET);
                    jB_SET.setBounds(272, 70, 65, 40);

                    jTab_Analisis.addTab("ANALISIS", jPanel1);

                    jPanel15.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Rango:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 10), java.awt.Color.blue)); // NOI18N

                    jExper_Inf.setModel(new javax.swing.SpinnerNumberModel(Integer.valueOf(1), Integer.valueOf(1), null, Integer.valueOf(1)));
                    jExper_Inf.addChangeListener(new javax.swing.event.ChangeListener() {
                        public void stateChanged(javax.swing.event.ChangeEvent evt) {
                            jExper_InfStateChanged(evt);
                        }
                    });

                    jExper_Sup.setModel(new javax.swing.SpinnerNumberModel(Integer.valueOf(1), Integer.valueOf(1), null, Integer.valueOf(1)));
                    jExper_Sup.addChangeListener(new javax.swing.event.ChangeListener() {
                        public void stateChanged(javax.swing.event.ChangeEvent evt) {
                            jExper_SupStateChanged(evt);
                        }
                    });

                    jT_IndeSup.setHorizontalAlignment(javax.swing.JTextField.CENTER);

                    jT_IndeInf.setHorizontalAlignment(javax.swing.JTextField.CENTER);

                    javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
                    jPanel15.setLayout(jPanel15Layout);
                    jPanel15Layout.setHorizontalGroup(
                        jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel15Layout.createSequentialGroup()
                            .addContainerGap(31, Short.MAX_VALUE)
                            .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jT_IndeInf)
                                .addComponent(jT_IndeSup, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jExper_Inf, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jExper_Sup, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                            .addContainerGap())
                    );
                    jPanel15Layout.setVerticalGroup(
                        jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel15Layout.createSequentialGroup()
                            .addContainerGap()
                            .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel15Layout.createSequentialGroup()
                                    .addComponent(jT_IndeInf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jT_IndeSup, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel15Layout.createSequentialGroup()
                                    .addComponent(jExper_Inf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jExper_Sup, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addContainerGap(18, Short.MAX_VALUE))
                    );

                    jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
                    jLabel2.setForeground(new java.awt.Color(0, 0, 255));
                    jLabel2.setText("CONFIGURACION :");

                    jPanel21.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Data:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 12), new java.awt.Color(0, 0, 255))); // NOI18N

                    javax.swing.GroupLayout jPanel21Layout = new javax.swing.GroupLayout(jPanel21);
                    jPanel21.setLayout(jPanel21Layout);
                    jPanel21Layout.setHorizontalGroup(
                        jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 126, Short.MAX_VALUE)
                    );
                    jPanel21Layout.setVerticalGroup(
                        jPanel21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 96, Short.MAX_VALUE)
                    );

                    javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
                    jPanel5.setLayout(jPanel5Layout);
                    jPanel5Layout.setHorizontalGroup(
                        jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addGap(21, 21, 21)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel5Layout.createSequentialGroup()
                                    .addGap(10, 10, 10)
                                    .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jPanel21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    );
                    jPanel5Layout.setVerticalGroup(
                        jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel5Layout.createSequentialGroup()
                            .addGap(18, 18, 18)
                            .addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel21, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addContainerGap(35, Short.MAX_VALUE))
                    );

                    jTab_Analisis.addTab("EXPERIMENTO", jPanel5);

                    jPanel19.setLayout(null);

                    jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Imagen:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

                    jVerAnalis.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Imagen", "Bordes", "StdLocal", "Ambos" }));
                    jVerAnalis.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jVerAnalisActionPerformed(evt);
                        }
                    });

                    javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
                    jPanel8.setLayout(jPanel8Layout);
                    jPanel8Layout.setHorizontalGroup(
                        jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                            .addContainerGap(37, Short.MAX_VALUE)
                            .addComponent(jVerAnalis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(23, 23, 23))
                    );
                    jPanel8Layout.setVerticalGroup(
                        jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel8Layout.createSequentialGroup()
                            .addComponent(jVerAnalis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(0, 16, Short.MAX_VALUE))
                    );

                    jPanel19.add(jPanel8);
                    jPanel8.setBounds(20, 10, 170, 66);

                    jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Data:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N

                    jComboBox1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Bordes", "LocalDesv", "Ambos" }));
                    jComboBox1.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jComboBox1ActionPerformed(evt);
                        }
                    });

                    jBut_SaveData.setText("...");
                    jBut_SaveData.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jBut_SaveDataActionPerformed(evt);
                        }
                    });

                    javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
                    jPanel6.setLayout(jPanel6Layout);
                    jPanel6Layout.setHorizontalGroup(
                        jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel6Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jBut_SaveData, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addContainerGap(24, Short.MAX_VALUE))
                    );
                    jPanel6Layout.setVerticalGroup(
                        jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jBut_SaveData, javax.swing.GroupLayout.PREFERRED_SIZE, 21, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addContainerGap())
                    );

                    jPanel19.add(jPanel6);
                    jPanel6.setBounds(120, 90, 210, 70);

                    jTab_Analisis.addTab("DATOS", jPanel19);

                    jPanelAnalisis.add(jTab_Analisis);
                    jTab_Analisis.setBounds(700, 290, 360, 230);

                    jImg_izq.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
                    jImg_izq.setText("<<");
                    jImg_izq.addMouseListener(new java.awt.event.MouseAdapter() {
                        public void mousePressed(java.awt.event.MouseEvent evt) {
                            jImg_izqMousePressed(evt);
                        }
                        public void mouseReleased(java.awt.event.MouseEvent evt) {
                            jImg_izqMouseReleased(evt);
                        }
                        public void mouseClicked(java.awt.event.MouseEvent evt) {
                            jImg_izqMouseClicked(evt);
                        }
                    });
                    jImg_izq.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jImg_izqActionPerformed(evt);
                        }
                    });
                    jPanelAnalisis.add(jImg_izq);
                    jImg_izq.setBounds(110, 570, 80, 25);

                    jImg_der.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
                    jImg_der.setText(">>");
                    jImg_der.addMouseListener(new java.awt.event.MouseAdapter() {
                        public void mousePressed(java.awt.event.MouseEvent evt) {
                            jImg_derMousePressed(evt);
                        }
                        public void mouseReleased(java.awt.event.MouseEvent evt) {
                            jImg_derMouseReleased(evt);
                        }
                        public void mouseClicked(java.awt.event.MouseEvent evt) {
                            jImg_derMouseClicked(evt);
                        }
                    });
                    jImg_der.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jImg_derActionPerformed(evt);
                        }
                    });
                    jPanelAnalisis.add(jImg_der);
                    jImg_der.setBounds(520, 570, 80, 25);

                    jProgreso_2.addMouseListener(new java.awt.event.MouseAdapter() {
                        public void mouseClicked(java.awt.event.MouseEvent evt) {
                            jProgreso_2MouseClicked(evt);
                        }
                    });
                    jPanelAnalisis.add(jProgreso_2);
                    jProgreso_2.setBounds(60, 540, 560, 15);

                    jImg_view.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
                    jPanelAnalisis.add(jImg_view);
                    jImg_view.setBounds(220, 580, 265, 28);

                    jTxTotal.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
                    jTxTotal.setText("00");
                    jPanelAnalisis.add(jTxTotal);
                    jTxTotal.setBounds(570, 10, 50, 28);

                    jLabel4.setText("Total");
                    jPanelAnalisis.add(jLabel4);
                    jLabel4.setBounds(525, 14, 40, 18);

                    jLabel5.setText("INDICE:");
                    jPanelAnalisis.add(jLabel5);
                    jLabel5.setBounds(630, 565, 55, 18);

                    jTxIndice_2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
                    jTxIndice_2.setText("00");
                    jTxIndice_2.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jTxIndice_2ActionPerformed(evt);
                        }
                    });
                    jPanelAnalisis.add(jTxIndice_2);
                    jTxIndice_2.setBounds(630, 535, 50, 25);

                    jPlot_panel.setBackground(new java.awt.Color(238, 238, 238));
                    jPlot_panel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
                    jPanelAnalisis.add(jPlot_panel);
                    jPlot_panel.setBounds(700, 50, 360, 210);

                    jStop_Analis.setFont(new java.awt.Font("Tahoma", 1, 8)); // NOI18N
                    jStop_Analis.setText("Stop");
                    jStop_Analis.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jStop_AnalisActionPerformed(evt);
                        }
                    });
                    jPanelAnalisis.add(jStop_Analis);
                    jStop_Analis.setBounds(920, 570, 50, 25);
                    jPanelAnalisis.add(jP_Test);
                    jP_Test.setBounds(810, 530, 100, 110);

                    jControl_Analisis.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
                    jControl_Analisis.setForeground(new java.awt.Color(0, 0, 255));
                    jControl_Analisis.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "DETECCION", "ANALISIS", "", "EXPERIMENTO COMPLETO" }));
                    jControl_Analisis.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jControl_AnalisisActionPerformed(evt);
                        }
                    });
                    jPanelAnalisis.add(jControl_Analisis);
                    jControl_Analisis.setBounds(730, 15, 300, 25);

                    jList1.addMouseListener(new java.awt.event.MouseAdapter() {
                        public void mouseClicked(java.awt.event.MouseEvent evt) {
                            jList1MouseClicked(evt);
                        }
                    });
                    jList1.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
                        public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                            jList1ValueChanged(evt);
                        }
                    });
                    jList1.addFocusListener(new java.awt.event.FocusAdapter() {
                        public void focusLost(java.awt.event.FocusEvent evt) {
                            jList1FocusLost(evt);
                        }
                    });
                    jList1.addKeyListener(new java.awt.event.KeyAdapter() {
                        public void keyPressed(java.awt.event.KeyEvent evt) {
                            jList1KeyPressed(evt);
                        }
                    });
                    jScrollPane2.setViewportView(jList1);

                    jPanelAnalisis.add(jScrollPane2);
                    jScrollPane2.setBounds(40, 30, 340, 1);

                    jButton4.setText("Abrir");
                    jButton4.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jButton4ActionPerformed(evt);
                        }
                    });
                    jPanelAnalisis.add(jButton4);
                    jButton4.setBounds(400, 10, 60, 25);

                    jTabbedPane1.addTab("TOMA DE DATOS", jPanelAnalisis);

                    jSplitPane1.setDividerLocation(510);
                    jSplitPane1.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
                    jSplitPane1.setAutoscrolls(true);
                    jSplitPane1.setOneTouchExpandable(true);

                    jSplitPane2.setDividerLocation(801);
                    jSplitPane2.setOneTouchExpandable(true);

                    jTableGraficos.setModel(new javax.swing.table.DefaultTableModel(
                        new Object [][] {
                            {null, null, null},
                            {null, null, null},
                            {null, null, null},
                            {null, null, null}
                        },
                        new String [] {
                            "Genotipo", "Animal", "Graficar"
                        }
                    ) {
                        Class[] types = new Class [] {
                            java.lang.Object.class, java.lang.Object.class, java.lang.Boolean.class
                        };
                        boolean[] canEdit = new boolean [] {
                            false, false, true
                        };

                        public Class getColumnClass(int columnIndex) {
                            return types [columnIndex];
                        }

                        public boolean isCellEditable(int rowIndex, int columnIndex) {
                            return canEdit [columnIndex];
                        }
                    });
                    jTableGraficos.addMouseListener(new java.awt.event.MouseAdapter() {
                        public void mousePressed(java.awt.event.MouseEvent evt) {
                            jTableGraficosMousePressed(evt);
                        }
                        public void mouseClicked(java.awt.event.MouseEvent evt) {
                            jTableGraficosMouseClicked(evt);
                        }
                    });
                    jScrollPane4.setViewportView(jTableGraficos);

                    jTabbedPane2.addTab("Lista", jScrollPane4);

                    jTableCambiar.setModel(new javax.swing.table.DefaultTableModel(
                        new Object [][] {
                            {null, null},
                            {null, null},
                            {null, null},
                            {null, null}
                        },
                        new String [] {
                            "Hora", "Animal"
                        }
                    ));
                    jTableCambiar.addMouseListener(new java.awt.event.MouseAdapter() {
                        public void mousePressed(java.awt.event.MouseEvent evt) {
                            jTableCambiarMousePressed(evt);
                        }
                    });
                    jScrollPane1.setViewportView(jTableCambiar);

                    jTabbedPane2.addTab("Tiempos", jScrollPane1);

                    javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
                    jPanel11.setLayout(jPanel11Layout);
                    jPanel11Layout.setHorizontalGroup(
                        jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jTabbedPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 313, Short.MAX_VALUE)
                    );
                    jPanel11Layout.setVerticalGroup(
                        jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jTabbedPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 520, Short.MAX_VALUE)
                    );

                    jSplitPane2.setRightComponent(jPanel11);

                    jSplitPane3.setDividerLocation(460);
                    jSplitPane3.setDividerSize(3);
                    jSplitPane3.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
                    jSplitPane3.addComponentListener(new java.awt.event.ComponentAdapter() {
                        public void componentResized(java.awt.event.ComponentEvent evt) {
                            jSplitPane3ComponentResized(evt);
                        }
                    });

                    javax.swing.GroupLayout jPanel23Layout = new javax.swing.GroupLayout(jPanel23);
                    jPanel23.setLayout(jPanel23Layout);
                    jPanel23Layout.setHorizontalGroup(
                        jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 791, Short.MAX_VALUE)
                    );
                    jPanel23Layout.setVerticalGroup(
                        jPanel23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 422, Short.MAX_VALUE)
                    );

                    jTabbedPane5.addTab("Graf01", jPanel23);

                    jSplitPane3.setTopComponent(jTabbedPane5);

                    jTextField1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
                    jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
                    jTextField1.setText("00:00");
                    jTextField1.setEnabled(false);

                    jTextField2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
                    jTextField2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
                    jTextField2.setText("48:00");
                    jTextField2.setEnabled(false);
                    jTextField2.addKeyListener(new java.awt.event.KeyAdapter() {
                        public void keyPressed(java.awt.event.KeyEvent evt) {
                            jTextField2KeyPressed(evt);
                        }
                    });

                    jCheckBox2.setText("Habilitar");
                    jCheckBox2.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jCheckBox2ActionPerformed(evt);
                        }
                    });

                    jScrollBar1.setMaximum(1000);
                    jScrollBar1.setOrientation(javax.swing.JScrollBar.HORIZONTAL);
                    jScrollBar1.setVisibleAmount(100);
                    jScrollBar1.setAutoscrolls(true);
                    jScrollBar1.addAdjustmentListener(new java.awt.event.AdjustmentListener() {
                        public void adjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {
                            jScrollBar1AdjustmentValueChanged(evt);
                        }
                    });

                    javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
                    jPanel24.setLayout(jPanel24Layout);
                    jPanel24Layout.setHorizontalGroup(
                        jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel24Layout.createSequentialGroup()
                            .addGap(10, 10, 10)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(30, 30, 30)
                            .addComponent(jScrollBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 510, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(17, 17, 17)
                            .addComponent(jCheckBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(31, 31, 31)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    );
                    jPanel24Layout.setVerticalGroup(
                        jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel24Layout.createSequentialGroup()
                            .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel24Layout.createSequentialGroup()
                                    .addGap(3, 3, 3)
                                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel24Layout.createSequentialGroup()
                                    .addGap(5, 5, 5)
                                    .addComponent(jScrollBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel24Layout.createSequentialGroup()
                                    .addGap(5, 5, 5)
                                    .addComponent(jCheckBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel24Layout.createSequentialGroup()
                                    .addGap(3, 3, 3)
                                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addContainerGap(28, Short.MAX_VALUE))
                    );

                    jSplitPane3.setRightComponent(jPanel24);

                    javax.swing.GroupLayout jPanel22Layout = new javax.swing.GroupLayout(jPanel22);
                    jPanel22.setLayout(jPanel22Layout);
                    jPanel22Layout.setHorizontalGroup(
                        jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jSplitPane3)
                    );
                    jPanel22Layout.setVerticalGroup(
                        jPanel22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jSplitPane3)
                    );

                    jScrollPane6.setViewportView(jPanel22);

                    jSplitPane2.setLeftComponent(jScrollPane6);

                    jSplitPane1.setTopComponent(jSplitPane2);

                    jPanel7.setMinimumSize(new java.awt.Dimension(1115, 155));
                    jPanel7.setName(""); // NOI18N
                    jPanel7.setLayout(null);

                    jPanel28.setLayout(null);

                    jTFiltro.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Normal", "Sgolay" }));
                    jTFiltro.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jTFiltroActionPerformed(evt);
                        }
                    });
                    jPanel28.add(jTFiltro);
                    jTFiltro.setBounds(190, 30, 130, 28);

                    jTData.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Bordes", "Desviación" }));
                    jTData.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jTDataActionPerformed(evt);
                        }
                    });
                    jPanel28.add(jTData);
                    jTData.setBounds(40, 30, 130, 28);

                    jLabel14.setFont(new java.awt.Font("Ubuntu", 1, 16)); // NOI18N
                    jLabel14.setText("Data:");
                    jPanel28.add(jLabel14);
                    jLabel14.setBounds(40, 10, 77, 19);

                    jLabel19.setFont(new java.awt.Font("Ubuntu", 1, 16)); // NOI18N
                    jLabel19.setText("Filtro:");
                    jPanel28.add(jLabel19);
                    jLabel19.setBounds(190, 10, 45, 19);

                    jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "COLOR:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Ubuntu", 1, 14))); // NOI18N
                    jPanel2.setLayout(null);

                    jC_Color.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
                    jC_Color.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Data", "Filtro", "Diff" }));
                    jC_Color.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jC_ColorActionPerformed(evt);
                        }
                    });
                    jPanel2.add(jC_Color);
                    jC_Color.setBounds(25, 20, 110, 28);

                    jPanel28.add(jPanel2);
                    jPanel2.setBounds(380, 10, 160, 70);
                    jPanel2.getAccessibleContext().setAccessibleName("");

                    jTabbedPane7.addTab("CURVAS:", jPanel28);

                    jActivarCurva.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jActivarCurvaActionPerformed(evt);
                        }
                    });

                    jButton10.setText("...");
                    jButton10.setPreferredSize(new java.awt.Dimension(45, 20));
                    jButton10.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jButton10ActionPerformed(evt);
                        }
                    });

                    jSp_Datpuntos.addChangeListener(new javax.swing.event.ChangeListener() {
                        public void stateChanged(javax.swing.event.ChangeEvent evt) {
                            jSp_DatpuntosStateChanged(evt);
                        }
                    });

                    jTabData.setModel(new javax.swing.table.DefaultTableModel(
                        new Object [][] {
                            {null, null, null, null, null, null},
                            {null, null, null, null, null, null},
                            {null, null, null, null, null, null},
                            {null, null, null, null, null, null},
                            {null, null, null, null, null, null},
                            {null, null, null, null, null, null},
                            {null, null, null, null, null, null},
                            {null, null, null, null, null, null},
                            {null, null, null, null, null, null},
                            {null, null, null, null, null, null}
                        },
                        new String [] {
                            "...", "Pend:", "Ang:", "Rango (hrs):", "Inicio (hr):", "Fin (hr):"
                        }
                    ) {
                        Class[] types = new Class [] {
                            java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
                        };
                        boolean[] canEdit = new boolean [] {
                            false, false, false, false, true, true
                        };

                        public Class getColumnClass(int columnIndex) {
                            return types [columnIndex];
                        }

                        public boolean isCellEditable(int rowIndex, int columnIndex) {
                            return canEdit [columnIndex];
                        }
                    });
                    jScrollPane7.setViewportView(jTabData);

                    javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
                    jPanel26.setLayout(jPanel26Layout);
                    jPanel26Layout.setHorizontalGroup(
                        jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel26Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 429, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                            .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel26Layout.createSequentialGroup()
                                    .addComponent(jActivarCurva)
                                    .addGap(4, 4, 4)
                                    .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jSp_Datpuntos, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(32, 32, 32))
                    );
                    jPanel26Layout.setVerticalGroup(
                        jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel26Layout.createSequentialGroup()
                            .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel26Layout.createSequentialGroup()
                                    .addGap(22, 22, 22)
                                    .addComponent(jSp_Datpuntos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(7, 7, 7)
                                    .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jActivarCurva)))
                                .addGroup(jPanel26Layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addContainerGap(13, Short.MAX_VALUE))
                    );

                    jTabbedPane7.addTab("DATOS:", jPanel26);

                    jControTiempo.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
                    jControTiempo.setText("ACTIVAR");
                    jControTiempo.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jControTiempoActionPerformed(evt);
                        }
                    });

                    jLabel17.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
                    jLabel17.setText("Tiempo (hrs):");

                    jTiempoMin.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
                    jTiempoMin.setHorizontalAlignment(javax.swing.JTextField.CENTER);
                    jTiempoMin.setText("00");

                    jButton3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
                    jButton3.setText("Set:");

                    javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
                    jPanel18.setLayout(jPanel18Layout);
                    jPanel18Layout.setHorizontalGroup(
                        jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel18Layout.createSequentialGroup()
                            .addGap(30, 30, 30)
                            .addComponent(jLabel17)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jTiempoMin, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(67, 67, 67)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 90, Short.MAX_VALUE)
                            .addComponent(jControTiempo)
                            .addGap(32, 32, 32))
                    );
                    jPanel18Layout.setVerticalGroup(
                        jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel18Layout.createSequentialGroup()
                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTiempoMin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jControTiempo))
                            .addGap(75, 75, 75))
                        .addGroup(jPanel18Layout.createSequentialGroup()
                            .addGap(19, 19, 19)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    );

                    jTabbedPane7.addTab("DESPLAZAR:", jPanel18);

                    jTextField4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
                    jTextField4.setHorizontalAlignment(javax.swing.JTextField.CENTER);
                    jTextField4.setText("1000");
                    jTextField4.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jTextField4ActionPerformed(evt);
                        }
                    });

                    jTextField3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
                    jTextField3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
                    jTextField3.setText("0");
                    jTextField3.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jTextField3ActionPerformed(evt);
                        }
                    });

                    jPanel12.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Ciclo de luz:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 1, 12), java.awt.Color.blue)); // NOI18N

                    jComboBox3.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "L_D", "D_L" }));
                    jComboBox3.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jComboBox3ActionPerformed(evt);
                        }
                    });

                    jS_CicloLuz.addChangeListener(new javax.swing.event.ChangeListener() {
                        public void stateChanged(javax.swing.event.ChangeEvent evt) {
                            jS_CicloLuzStateChanged(evt);
                        }
                    });

                    jS_hInicio.addChangeListener(new javax.swing.event.ChangeListener() {
                        public void stateChanged(javax.swing.event.ChangeEvent evt) {
                            jS_hInicioStateChanged(evt);
                        }
                    });

                    jLabel10.setText("Hora:");

                    jLabel12.setText("Rango:");

                    jLabel13.setText("Ciclo:");

                    javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
                    jPanel12.setLayout(jPanel12Layout);
                    jPanel12Layout.setHorizontalGroup(
                        jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jLabel10)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jS_hInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jLabel12)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jS_CicloLuz, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jLabel13)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addContainerGap(26, Short.MAX_VALUE))
                    );
                    jPanel12Layout.setVerticalGroup(
                        jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel12Layout.createSequentialGroup()
                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel13)
                                    .addComponent(jComboBox3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jS_hInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel12)
                                    .addComponent(jS_CicloLuz, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGap(31, 31, 31))
                    );

                    javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
                    jPanel27.setLayout(jPanel27Layout);
                    jPanel27Layout.setHorizontalGroup(
                        jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel27Layout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(72, 72, 72)
                            .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jTextField3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jTextField4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addContainerGap(33, Short.MAX_VALUE))
                    );
                    jPanel27Layout.setVerticalGroup(
                        jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel27Layout.createSequentialGroup()
                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(25, 25, 25))
                        .addGroup(jPanel27Layout.createSequentialGroup()
                            .addGap(22, 22, 22)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    );

                    jTabbedPane7.addTab("Escala:", null, jPanel27, "");

                    jPanel7.add(jTabbedPane7);
                    jTabbedPane7.setBounds(5, 5, 570, 140);

                    jB_ResetCurvas.setText("Reset");
                    jB_ResetCurvas.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jB_ResetCurvasActionPerformed(evt);
                        }
                    });
                    jPanel7.add(jB_ResetCurvas);
                    jB_ResetCurvas.setBounds(1020, 65, 80, 30);

                    jB_VerCurvas.setText("Ver");
                    jB_VerCurvas.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jB_VerCurvasActionPerformed(evt);
                        }
                    });
                    jPanel7.add(jB_VerCurvas);
                    jB_VerCurvas.setBounds(1020, 30, 80, 30);

                    jPath_Graficos.setText("://");
                    jPath_Graficos.addKeyListener(new java.awt.event.KeyAdapter() {
                        public void keyPressed(java.awt.event.KeyEvent evt) {
                            jPath_GraficosKeyPressed(evt);
                        }
                    });
                    jPanel7.add(jPath_Graficos);
                    jPath_Graficos.setBounds(630, 30, 330, 28);

                    jB_AbrirGraficos.setFont(new java.awt.Font("Ubuntu", 1, 16)); // NOI18N
                    jB_AbrirGraficos.setText("ABRIR");
                    jB_AbrirGraficos.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jB_AbrirGraficosActionPerformed(evt);
                        }
                    });
                    jPanel7.add(jB_AbrirGraficos);
                    jB_AbrirGraficos.setBounds(860, 60, 100, 40);

                    jP_Umbral.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Umbral:", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Abyssinica SIL", 0, 12))); // NOI18N
                    jP_Umbral.setToolTipText("");
                    jP_Umbral.setLayout(null);

                    jSp_UmbralGraf.setFont(new java.awt.Font("Ubuntu", 0, 16)); // NOI18N
                    jSp_UmbralGraf.setToolTipText("");
                    jSp_UmbralGraf.addChangeListener(new javax.swing.event.ChangeListener() {
                        public void stateChanged(javax.swing.event.ChangeEvent evt) {
                            jSp_UmbralGrafStateChanged(evt);
                        }
                    });
                    jP_Umbral.add(jSp_UmbralGraf);
                    jSp_UmbralGraf.setBounds(40, 18, 80, 30);

                    jPanel7.add(jP_Umbral);
                    jP_Umbral.setBounds(630, 60, 150, 60);

                    jScrollPane3.setViewportView(jPanel7);

                    jSplitPane1.setRightComponent(jScrollPane3);

                    javax.swing.GroupLayout jPanelGraficosLayout = new javax.swing.GroupLayout(jPanelGraficos);
                    jPanelGraficos.setLayout(jPanelGraficosLayout);
                    jPanelGraficosLayout.setHorizontalGroup(
                        jPanelGraficosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jSplitPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                    );
                    jPanelGraficosLayout.setVerticalGroup(
                        jPanelGraficosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jSplitPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 671, Short.MAX_VALUE)
                    );

                    jTabbedPane1.addTab("GRAFICOS", jPanelGraficos);

                    jPanel17.setLayout(null);

                    jButton2.setText("jButton2");
                    jButton2.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jButton2ActionPerformed(evt);
                        }
                    });
                    jPanel17.add(jButton2);
                    jButton2.setBounds(590, 210, 70, 40);

                    jTabbedPane1.addTab("OTROS", jPanel17);

                    getContentPane().add(jTabbedPane1, java.awt.BorderLayout.CENTER);

                    jMenuBar1.setBorder(null);

                    jMenu1.setText("   File ");
                    jMenu1.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N

                    j_Abrir.setFont(new java.awt.Font("Ubuntu", 1, 15)); // NOI18N
                    j_Abrir.setText("  Abrir  ");
                    j_Abrir.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            j_AbrirActionPerformed(evt);
                        }
                    });
                    jMenu1.add(j_Abrir);
                    jMenu1.add(jMenuItem7);

                    jMenuItem8.setText("  AaA");
                    jMenu1.add(jMenuItem8);

                    jMenuItem9.setText("jMenuItem9");
                    jMenu1.add(jMenuItem9);

                    jMenuBar1.add(jMenu1);

                    jMenu2.setText(" Edit ");
                    jMenu2.setToolTipText("");

                    jMenuItem1.setText("Archivos Datt");
                    jMenu2.add(jMenuItem1);
                    jMenu2.add(jMenuItem2);

                    jMenuItem3.setText("Borrar Lista Separar");
                    jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jMenuItem3ActionPerformed(evt);
                        }
                    });
                    jMenu2.add(jMenuItem3);

                    jMenuItem4.setText("Borrar Disco");
                    jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jMenuItem4ActionPerformed(evt);
                        }
                    });
                    jMenu2.add(jMenuItem4);

                    jMenuBar1.add(jMenu2);

                    jActiv.setText(" Activar ");

                    jAnalisis.setSelected(true);
                    jAnalisis.setText("Analisis");
                    jAnalisis.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jAnalisisActionPerformed(evt);
                        }
                    });
                    jActiv.add(jAnalisis);

                    jR_Shape.setSelected(true);
                    jR_Shape.setText("Grafico");
                    jR_Shape.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jR_ShapeActionPerformed(evt);
                        }
                    });
                    jActiv.add(jR_Shape);

                    jMenuItem5.setText("...");
                    jActiv.add(jMenuItem5);

                    jRadioButtonMenuItem1.setText("HebraFiltros");
                    jRadioButtonMenuItem1.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jRadioButtonMenuItem1ActionPerformed(evt);
                        }
                    });
                    jActiv.add(jRadioButtonMenuItem1);

                    jMenuBar1.add(jActiv);

                    jMenu3.setText("    ");
                    jMenuBar1.add(jMenu3);

                    jComp.setText("Comparar");

                    jRDesvia.setSelected(true);
                    jRDesvia.setText("Desviacion");
                    jRDesvia.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jRDesviaActionPerformed(evt);
                        }
                    });
                    jComp.add(jRDesvia);

                    jRBordes.setText("Bordes");
                    jRBordes.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                            jRBordesActionPerformed(evt);
                        }
                    });
                    jComp.add(jRBordes);

                    jMenuBar1.add(jComp);

                    setJMenuBar(jMenuBar1);

                    pack();
                }// </editor-fold>//GEN-END:initComponents

    /**
     * CARGA DE DATOS, PARAMETROS DE ALGUNOS OBJETOS IMPORTANES, AL MOMENTO DE
     * INICIAR EL SISTEMA.
     */ 
    public void initMisDatos(int mod){
        jP_Test.add(mBoton);
        
        mBoton.setStartColor(new Color(92,136,163));
        mBoton.setPreferredSize(new Dimension(100, 100));
        mBoton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mBottonAction1(e);
            }
        });
        temChart2.addChartMouseListener(new ChartMouseListener() {
            @Override
            public void chartMouseClicked(ChartMouseEvent cme) {
                
                double      dScalX   = temChart2.getScaleX();
                Rectangle2D plotArea = temChart2.getScreenDataArea();
                
                Point2D p = temChart2.translateScreenToJava2D(new Point(cme.getTrigger().getX(),
                                            cme.getTrigger().getY()));
                
                double dXp = plotArea.getX() / dScalX;
                double Are = plotArea.getWidth() / dScalX;
                
                double xPunto = p.getX() - dXp;
                
                Range rg = temChart2.getChart().getXYPlot().getDomainAxis().getRange();
                
                if(xPunto >= 0 && xPunto <= Are){
                    double tPunto = xPunto * (rg.getLength() / Are);
                    tPunto = tPunto + rg.getLowerBound();
                    generalGraf.mysetMouseClicker(tPunto, jPanel23);
                }
                else
                    mensaje("Fuera de rangos");
            }
            @Override
            public void chartMouseMoved(ChartMouseEvent cme) {
            }
        });
        
//        temChart2.addMouseListener(new MouseListener() {
//            public void mouseClicked(MouseEvent e) {
//                ChartEntity et = temChart2.getEntityForPoint(e.getX(), e.getY());
//                generalGraf.mysetMouseClicker(e, et, jPanel23);
//            }
//            public void mousePressed(MouseEvent e) {
//            }
//            public void mouseReleased(MouseEvent e) {
//            }
//            public void mouseEntered(MouseEvent e) {
//            }
//            public void mouseExited(MouseEvent e) {
//            }
//        });
        
        jTabData.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        jTabData.getColumnModel().getColumn(0).setPreferredWidth(30);
        jTabData.getColumnModel().getColumn(1).setPreferredWidth(45);
        jTabData.getColumnModel().getColumn(2).setPreferredWidth(60);
        jTabData.getColumnModel().getColumn(3).setPreferredWidth(80);
        jTabData.getColumnModel().getColumn(4).setPreferredWidth(80);
        jTabData.getColumnModel().getColumn(5).setPreferredWidth(80);
        
        DefaultTableCellRenderer rRend = new DefaultTableCellRenderer();
        rRend.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
        
        jTabData.getColumnModel().getColumn(0).setCellRenderer(rRend);
        jTabData.getColumnModel().getColumn(1).setCellRenderer(rRend);
        jTabData.getColumnModel().getColumn(2).setCellRenderer(rRend);
        jTabData.getColumnModel().getColumn(3).setCellRenderer(rRend);
        jTabData.getColumnModel().getColumn(4).setCellRenderer(rRend);
        jTabData.getColumnModel().getColumn(5).setCellRenderer(rRend);
        
        //Entrego elementos al objeto plot.
        generalGraf.setUIObjetos(jTableGraficos, jTableCambiar);
        //Seting all tips of tablet. Init in false.
        for(int i=0; i < jTableGraficos.getRowCount(); i++){
            jTableGraficos.setValueAt(false, i, 2);
        }
        
        jTabbedPane2.setTitleAt(0, "   LISTA   ");
        jTabbedPane2.setTitleAt(1, "  TIEMPOS   ");
        
        //jSPinner configuracion
        //Spinner_Configuration();
        
        
        apariencias = UIManager.getInstalledLookAndFeels();
        try {
            UIManager.setLookAndFeel( apariencias[mod].getClassName() );
            SwingUtilities.updateComponentTreeUI(this);
        }
        // procesar problemas al cambiar la apariencia visual
        catch ( Exception excepcion ){
            mensaje("Ocurre el poblema aca ????");
            excepcion.printStackTrace();
        }
    }
    
    /**
     * Creación al momento de iniciar el sistema, de timers (hebras) que permiten
     * visualizar la progresion de las imagenes. El reproductor de video, en base
     * proyectar fotografias con un tiempo de separacion especifico, son controlados
     * por estos timers.
     */
    public void crearTimer(){
        timeStamp = new Timer(timControl, new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e){
                try {
                    if (INDICE > direc.length - (salReprod + 2)) {
                        timeStamp.stop();
                        jCONTROL.setText("INICIO");
                        return;
                    }
                    FileSeekableStream fTemp = null;
                    INDICE += salReprod;
                    jTexIndice.setText(new Integer(INDICE).toString());
                    jProgreso.setValue(INDICE);
                    fTemp = new FileSeekableStream(jPathImage + "/" + direc[INDICE]);
                    jTexFile.setText(direc[INDICE].substring(0, direc[INDICE].length() - 4));
                    jImgPr.setIcon(new ImageIcon((Image) leerIm(jPathImage, direc[INDICE]).getAsBufferedImage()));
                    jImgPr.repaint();

                } catch (IOException ex) {
                        Logger.getLogger(DMMPRINCIPAL.class.getName()).log(Level.SEVERE, null, ex);
                    }}});

        runContinA = new Timer(timControl, new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                if(direcRec == 0) {INDICE -= salReprod;}
                else {INDICE += salReprod;}
                if(INDICE < 0 || INDICE > direc.length - 2){
                    runContinA.stop();
                    return;
                }
                jTexIndice.setText(new Integer(INDICE).toString());
                jImgPr.setIcon(new ImageIcon((Image)leerIm(jPathImage,
                        direc[INDICE]).getAsBufferedImage()));
                jProgreso.setValue(INDICE);
                jTexFile.setText(direc[INDICE].substring(0, direc[INDICE].length() - 4));
            }});
            //Aca, un timer que corre en forma continua al apretar los botones de avance y retroceso

        runContinB = new Timer(100, new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                if(INDICE_2 == -1 || INDICE_2 < 1 || INDICE_2 > direc_2.length - 2){
                    runContinB.stop();
                    return;
                }
                if(direcRec == 0) INDICE_2--;
                else INDICE_2++;
                jTxIndice_2.setText(new Integer(INDICE_2).toString());
                jProgreso_2.setValue(INDICE_2);
                jOb_Analisis.setImagen(leerIm(jPathDirecAnalisis, direc_2[INDICE_2]));
                jImg_view.setText(direc_2[INDICE_2].substring(0, direc_2[INDICE_2].length() - 4));
            }});
    }
    /**
     * Metodo que inicia, al momento de abrir el sistema, los objetos que escuchan
     * si un evento sobre el TECLADO ha ocurrido.
     * Cada evento tiene una convinacion de teclas especifica:
     *      - Abrir una carpeta.
     *      - Borrar una lista de imagenes o puntos.
     *      - Avanzar una imagen.
     *      - Retroceder una imagen.
     *      - Otros eventos con teclado pueden ser incorporados acá.
     * 
     *      inputMap.PUT() : Carga del evento.
     *      actionMap.PUT(): Definicion del evento en si. Accion.
     */
    private void keyEscucha(){
        KeyStroke Borrar  = KeyStroke.getKeyStroke(KeyEvent.VK_X, Event.CTRL_MASK);
        KeyStroke Grabar  = KeyStroke.getKeyStroke(KeyEvent.VK_S, Event.CTRL_MASK);
        KeyStroke Denegar = KeyStroke.getKeyStroke(KeyEvent.VK_C, Event.CTRL_MASK);
        KeyStroke Cambiar = KeyStroke.getKeyStroke(KeyEvent.VK_D, Event.CTRL_MASK);
        KeyStroke Abrir   = KeyStroke.getKeyStroke(KeyEvent.VK_A, Event.CTRL_MASK);
        
        //Eventos para controlar la carga de Imagenes.
        KeyStroke Avance = KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, Event.CTRL_MASK);
        KeyStroke Retroc = KeyStroke.getKeyStroke(KeyEvent.VK_LEFT,  Event.CTRL_MASK);
        
        KeyStroke ENTERR = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, Event.CTRL_MASK);
        
        
        inputMap.put(Avance, "Avanzar");
        inputMap.put(Retroc, "Retroceder");
        actionMap.put("Retroceder", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (INDICE <= 0 || !mCONTROL.getControl(0)) {
                    return;
                }
                INDICE -= salReprod;
                moveImagnes();
            }
        });
        actionMap.put("Avanzar", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                if (INDICE < 0) INDICE = 0;
                if (!mCONTROL.getControl(0) || INDICE > direc.length - 2) {
                    return;
                }
                INDICE += salReprod;
                moveImagnes();
            }
        });
        
        //Estructuras para generar comandos con teclado.
        //Struct for generate commands with 
        inputMap.put(Grabar, "fGrabar");
        inputMap.put(Borrar, "fBorrar");
        inputMap.put(Denegar, "fDenegar");
        inputMap.put(Cambiar, "fCambiar");
        actionMap.put("fGrabar", new AbstractAction() {
            private static final long serialVersionUID = 1L;
            public void actionPerformed(ActionEvent e) {
                if(jPanelImagenes.isVisible())
                    ;
                if(jPanelAnalisis.isVisible())
                        jOb_Analisis.guarParametros(1);
            }});
        actionMap.put("fBorrar", new AbstractAction() {
            private static final long serialVersionUID = 1L;
            public void actionPerformed(ActionEvent e) {
                if(jPanelImagenes.isVisible())
                    ;
                if(jPanelAnalisis.isVisible() || jDirectorio_2.isFocusOwner()){
                    jOb_Analisis.resetPolig();
                }
            }});
        actionMap.put("fCambiar", new AbstractAction() {
            private static final long serialVersionUID = 1L;
            public void actionPerformed(ActionEvent e) {
                if(jPanelImagenes.isVisible())
                    ;
                if(jPanelAnalisis.isVisible()){
                    if( !jActivarArea.isSelected()){
                        jActivarArea.setSelected(true);
                        jTipoData.setSelectedIndex(jTipoData.getSelectedIndex());
                    }
                    else
                        jTipoData.setSelectedIndex(
                                (jTipoData.getSelectedIndex() + 1)%3);
                }
            }});
        actionMap.put("fDenegar", new AbstractAction() {
            private static final long serialVersionUID = 1L;
            public void actionPerformed(ActionEvent e) {
                System.out.println("Denegar...");
            }});
        
        inputMap.put(Abrir, "fAbrir");
        actionMap.put("fAbrir", new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                JDirChooser mDir = new JDirChooser();
                if (mDir.showDialog((Component) e.getSource()) == JDirChooser.OK_OPTION){
                    jAbrirTemp(mDir.getSelectedFile());
                }}});  
    }
    private void Spinner_Configuration(){
        jSp_Fecha.setModel(new SpinnerDateModel(new Date(), null, null, Calendar.HOUR));
        JSpinner.DateEditor spDate = new JSpinner.DateEditor(jSp_Fecha, "HH:mm  yyyy-MMM-dd");
        jSp_Fecha.setEditor(spDate);
        
        JSpinner.DateEditor editor = (JSpinner.DateEditor)jSp_Fecha.getEditor();
        editor.getTextField().addFocusListener(new FocusAdapter(){
            public void focusGained(final FocusEvent e){
            }
        });
        
        editor.getTextField().addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent ke) {
            }
            @Override
            public void keyPressed(KeyEvent ke) {
                if(ke.getKeyCode() == KeyEvent.VK_ENTER && mCONTROL.getControl(2)){
                    horaRefInit = (Date)jSp_Fecha.getValue();
                    
                    String Geno = jGenotype.getSelectedItem().toString();
                    String Hora = jComb_Hora.getSelectedItem().toString() + ":" +
                            jComb_Min.getSelectedItem().toString();
                    
                    boolean d1 = jOb_Analisis.saveDataParametros(Geno, Hora, horaRefInit);
                }
            }
            @Override
            public void keyReleased(KeyEvent ke) {
            }
        });       
    }
    
    /**
     * Boton para abrir direccion (path) de las imagenes, para visualizar o 
     * separar.
     * @param evt: Evento sobre el boton.
     */
    private void jAbrirImagActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jAbrirImagActionPerformed
        JDirChooser mDir = new JDirChooser();
            if (mDir.showDialog((Component) this, "", null, "DIRECTORIO IMAGENES:" ) 
                    == JDirChooser.OK_OPTION) {
                jAbrirTemp(mDir.getSelectedFile());
            }        
    }//GEN-LAST:event_jAbrirImagActionPerformed

    private void jB_SeparacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_SeparacionActionPerformed
        // TODO add your handling code here:
        if(!mCONTROL.getControl(0)) //CONTROL: Si no están todos ok, no carga.
            return;
        switch(jImag_Lista.getSelectedIndex()){
            case 0:
                jFijarImagenBusqueda();
                break;
            case 1:
                jSepararImagenes();
                break;
            case 2:
                jSaveGuardarImagen();
                break;
        }
    }//GEN-LAST:event_jB_SeparacionActionPerformed
    /**
     * Mètodo para fijar la primera imagen de un animal en especifico. Esto permite dar
     * inicio 
     */
    private void jFijarImagenBusqueda(){
        /* Acà busca si en lista ya existe dicha imagen guia. Busca en base al 
         * tiempo que se construye con el nombre de la imagen. 
         */
        if(listImgSeparar.size() > 0){
            double tt = mi_hebra.getTime(direc[INDICE]);
            for(int i = 0; i < listImgSeparar.size(); i++)
                if(tt - mi_hebra.getTime((String)listImgSeparar.get(i)) < 2){
                    return;
                }
        }
        
        /*Si pasa la busqueda y NO existe, se carga a la lista de imàgenes guìa, 
         * que serà usada para la busqueda: "jList_names"
         */
        String tte = preFijos[0] + Integer.toString(1000 + conFold).substring(1, 4);
        int dd = jList_names.getModel().getSize();
        jList_names.insertItemAt(tte, dd);
        jList_names.setSelectedIndex(dd);
        
        
        listImgSeparar.add(direc[INDICE]);
        conFold++;
    }
    /**
     * Mètodo que se ejecuta cuando quiero dar INICIO a la separaciòn de animales.
     */
    private void jSepararImagenes(){    
        File ff = new File(jSecuDestino.getText());
        String opc[] = {"SI", "NO"};
        int opd = -10;
        if (!ff.exists()) {
            opd = JOptionPane.showOptionDialog(null, "Desea crearlo ?", "DIRECTORIO NO VALIDO",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null,
                    opc, opc[0]);
            
            if (opd == 0) {
                ff.mkdir();
                //En caso de NO existir el directorio que se desea crear, indica y luego sale.
                if(!ff.exists()){
                    jSecuDestino.setBackground(Color.red);//RESALTO...
                    JOptionPane.showMessageDialog(null, "DEBE INDICAR UN DIRECTORIO DESTINO");
                    jSecuDestino.setBackground(Color.white);//VUELVO A NORMAL...
                    return;
                }
            } else {
                return;
            }
        }
        
        /**
         * Luego de fijar el directorio de destino del experimento, cargo los 
         * datos en la hebra encargada de separar el experimento completo. Le
         * entrego: 
         *     direc         = Arreglo con la lista completa de imagenes.
         *     Directorio    = File con el path donde estàn las imagenes.
         *     Destino       = File con el path destino del experimeto.
         * listImgSeparar    = Lista con las imàgenes guìa de (nombres de archivo)
         */
        hebraBuscar.setData(direc,
                    new File(jPathImage),
                    new File(jSecuDestino.getText()),
                    listImgSeparar
                );
        
        conFold = 1;//Este es el contador que da NOMBRE a las carpetas para cada animal.
        hebraBuscar.start();
    }    
    private void jSaveGuardarImagen(){
        GuardarImagen();  
    }
    /**
     * Acciòn del botòn que detiene la separaciòn.
     * @param evt: Evento click sobre el botòn. 
     */
    private void jB_StopSeparacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_StopSeparacionActionPerformed
        switch(jImag_Lista.getSelectedIndex()){
            case 0:
                mi_hebra.stop();
                break;
            case 1:
                mi_hebra.stop();
                mCONTROL.setControl(10, false);
                break;
        }
    }//GEN-LAST:event_jB_StopSeparacionActionPerformed

    private void jSecuDestinoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSecuDestinoActionPerformed
        File ff = new File(jSecuDestino.getText());
        if (ff.exists()) {
            jPathSeparacion = ff.getAbsolutePath();
        } else {
            JOptionPane.showMessageDialog(null, "DIRECTORIO NO VALIDO");
        }
    }//GEN-LAST:event_jSecuDestinoActionPerformed

    private void jImag_ListaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jImag_ListaActionPerformed
        // TODO add your handling code here:
        switch(jImag_Lista.getSelectedIndex()){
            case 0:
                jB_Separacion.setText("FIJAR");
                jList_names.setVisible(true);
                break;
            case 1:
                jB_Separacion.setText("INICIAR");
                jList_names.setVisible(true);
                break;
            case 2:
                jB_Separacion.setText("GUARDAR");
                jList_names.setVisible(true);
        }
    }//GEN-LAST:event_jImag_ListaActionPerformed

    /**
     *Metodo que indica la cantidad de imàgenes que salta en cada avance. Entre
     * 1 y 10.
     * @param evt 
     */
    private void jSaltoStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSaltoStateChanged
        salReprod = Integer.parseInt(jSalto.getValue().toString());
    }//GEN-LAST:event_jSaltoStateChanged

    /**
 * Metodo para ajustar la velocidad con que el Reproductor de imagenes proyecta 
 * las imagenes en pantalla.
 * @param evt 
 */    
    private void jVelocidadPlayStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jVelocidadPlayStateChanged
//      TODO add your handling code here:
        timControl = Integer.parseInt(jVelocidadPlay.getValue().toString());
        timeStamp.setDelay(timControl);
    }//GEN-LAST:event_jVelocidadPlayStateChanged

    /**
     * Evento sobre la barra direcciòn de separaciòn.
     * @param evt: evento enter del mouse.
     */    
    private void jPathImagenesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPathImagenesActionPerformed
        File ff = new File(jPathImagenes.getText());
        if (ff.exists()) {
            jAbrirTemp(ff);
        }else {
            JOptionPane.showMessageDialog(null, "DIRECTORIO NO VALIDO");
        }
//        else {
//            JDirChooser mDir = new JDirChooser();
//            if (mDir.showDialog((Component) this) == JDirChooser.OK_OPTION) {
//                jAbrirTemp(mDir.getSelectedFile());
//            }
//        }        
    }//GEN-LAST:event_jPathImagenesActionPerformed

    private void j_AtrasMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_j_AtrasMousePressed
        direcRec = 0;
        runContinA.start();
    }//GEN-LAST:event_j_AtrasMousePressed

    private void j_AtrasMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_j_AtrasMouseReleased
        runContinA.stop();
    }//GEN-LAST:event_j_AtrasMouseReleased

    private void j_AtrasMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_j_AtrasMouseDragged
        // TODO add your handling code here:
        if (j_Atras.getBounds().contains(evt.getLocationOnScreen()));
    }//GEN-LAST:event_j_AtrasMouseDragged

    private void j_AtrasMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_j_AtrasMouseMoved
        // TODO add your handling code here:
        //    if(j_Atras.getBounds().contains(evt.getLocationOnScreen()))
    }//GEN-LAST:event_j_AtrasMouseMoved

    private void j_AtrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_j_AtrasActionPerformed
        if (INDICE <= 0 || !mCONTROL.getControl(0)) {
            return;
        }
        INDICE -= salReprod;

        jProgreso.setValue(INDICE);
        jTexIndice.setText(new Integer(INDICE).toString());
        jTexFile.setText(direc[INDICE].substring(0, direc[INDICE].length() - 4));
        BufferedImage imm = leerIm(jPathImage, direc[INDICE]).getAsBufferedImage();
        jImgPr.setIcon(new ImageIcon((Image) imm));
        repaint();
    }//GEN-LAST:event_j_AtrasActionPerformed

    private void j_AdelanteMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_j_AdelanteMousePressed
        direcRec = 1;
        runContinA.start();
    }//GEN-LAST:event_j_AdelanteMousePressed

    private void j_AdelanteMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_j_AdelanteMouseReleased
        runContinA.stop();
    }//GEN-LAST:event_j_AdelanteMouseReleased

    private void j_AdelanteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_j_AdelanteActionPerformed
        if (INDICE < 0) INDICE = 0;
        if (!mCONTROL.getControl(0) || INDICE > direc.length - 2) {
            return;
        }
        INDICE += salReprod;

        jProgreso.setValue(INDICE);
        jTexIndice.setText(new Integer(INDICE).toString());
        jTexFile.setText(direc[INDICE].substring(0, direc[INDICE].length() - 4));
        BufferedImage imm = leerIm(jPathImage, direc[INDICE]).getAsBufferedImage();
        jImgPr.setIcon(new ImageIcon((Image) imm));
        repaint();
    }//GEN-LAST:event_j_AdelanteActionPerformed

    private void jTexIndiceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTexIndiceActionPerformed
        // TODO add your handling code here:
        try {
            INDICE = Integer.parseInt(jTexIndice.getText());
            if (INDICE > direc.length) {
                INDICE = direc.length - 1;
                jTexIndice.setText(String.valueOf(INDICE));
                jTexFile.setText(direc[INDICE]);
            }
            jProgreso.setValue(INDICE);
            jImgPr.setIcon(new ImageIcon((Image) leerIm(jPathImage, direc[INDICE]).getAsBufferedImage()));
        } catch (java.lang.NumberFormatException ex) {
        }
    }//GEN-LAST:event_jTexIndiceActionPerformed

    private void jCONTROLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCONTROLActionPerformed
        if (!mCONTROL.getControl(0))
            return;
        
        if (jCONTROL.getText().compareToIgnoreCase("INICIO") == 0) {
            timeStamp.start();
            jCONTROL.setText("PAUSE");
        } else {
            timeStamp.stop();
            jCONTROL.setText("INICIO");
        }
    }//GEN-LAST:event_jCONTROLActionPerformed

    private void jTexFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTexFileActionPerformed
        boolean ant = true;
        Date tiempoAhora = null;        
        Date momentNow   = getTime(jTexFile.getText().substring(0, 21));
        double dDelta = 10000000000.0;
        if (direc.length == 0) {return;}
        for (int i = 0; i < direc.length; i++) {
            if (jTexFile.getText().substring(0, 17).
                    equalsIgnoreCase(direc[i].substring(0, 17))) {
                INDICE = i;
                ant = false;
                jImgPr.setIcon(new ImageIcon((Image) leerIm(jPathImage, direc[INDICE]).getAsBufferedImage()));
                jTexIndice.setText(new Integer(INDICE).toString());
                jProgreso.setValue(INDICE);
                break;
            }
        }
        if(ant){
            for (int i = 0; i < direc.length; i++) {
                tiempoAhora = getTime(direc[i]);
                if(Math.abs(tiempoAhora.getTime() - momentNow.getTime()) < dDelta){
                    dDelta = Math.abs(tiempoAhora.getTime() - momentNow.getTime());
                    INDICE = i;
                }
            }
            jImgPr.setIcon(new ImageIcon((Image) leerIm(jPathImage, direc[INDICE]).getAsBufferedImage()));
            jTexFile.setText(direc[INDICE].substring(0, 21));
            jTexIndice.setText(new Integer(INDICE).toString());
            jProgreso.setValue(INDICE);
        }
        

//        if (direc.length != 0) {
//            for (int i = 0; i < direc.length; i++) {
//                if (jTexFile.getText().substring(0, 17).
//                        equalsIgnoreCase(direc[i].substring(0, 17))) {
//                    INDICE = i;
//                    ant = false;
//                    jImgPr.setIcon(new ImageIcon((Image) leerIm(jPathImage, direc[INDICE]).getAsBufferedImage()));
//                    jTexIndice.setText(new Integer(INDICE).toString());
//                    break;
//                }
//            }
//            if(ant){
//                for (int i = 0; i < direc.length; i++) {
//                    if (jTexFile.getText().substring(0, 16).
//                            equalsIgnoreCase(direc[i].substring(0, 16))) {
//                        INDICE = i;
//                        jImgPr.setIcon(new ImageIcon((Image) leerIm(jPathImage, direc[INDICE]).getAsBufferedImage()));
//                        jTexIndice.setText(new Integer(INDICE).toString());
//                        break;
//                    }}}
//        }
    }//GEN-LAST:event_jTexFileActionPerformed

    private void jProgresoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jProgresoMouseClicked
        // TODO add your handling code here:
        if (jProgreso.contains(evt.getPoint())) {
            double dd = (double) evt.getPoint().x * ((double) jProgreso.getMaximum()
                    / (double) jProgreso.getWidth());
            jProgreso.setValue((int) Math.round(dd));

            INDICE = (int) Math.round(dd);
            jProgreso.setValue(INDICE);
            jTexIndice.setText(new Integer(INDICE).toString());
            jTexFile.setText(direc[INDICE].substring(0, direc[INDICE].length() - 4));
            BufferedImage imm = leerIm(jPathImage, direc[INDICE]).getAsBufferedImage();
            jImgPr.setIcon(new ImageIcon((Image) imm));
            repaint();
        }
    }//GEN-LAST:event_jProgresoMouseClicked

    private void jProgresoMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jProgresoMouseDragged
        // TODO add your handling code here:
        if (jProgreso.contains(evt.getPoint()) && !mCONTROL.getControl(0)) {
            double dd = (double) evt.getPoint().x * ((double) jProgreso.getMaximum()
                    / (double) jProgreso.getWidth());
            jProgreso.setValue((int) Math.round(dd));
        }
    }//GEN-LAST:event_jProgresoMouseDragged

    private void jDirectorio_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jDirectorio_2MouseClicked
        if (evt.getClickCount() == 2) {
            jScrollPane2.setVisible(true);
            jList1.requestFocus();
        }
    }//GEN-LAST:event_jDirectorio_2MouseClicked

    /**
     * Evento para cargar paràmetros sobre el objeto de anàlisis de un experimento
     * completo.
     * @param evt 
     */
    private void jDirectorio_2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jDirectorio_2KeyPressed
        // TODO add your handling code here:
        if (evt.getKeyChar() == KeyEvent.VK_ESCAPE) {
            jScrollPane2.setVisible(false);
            
        } else if (evt.isControlDown() && evt.getKeyChar() == KeyEvent.VK_ENTER) {
            funcion_Abrir();
            
        } else if (evt.getKeyCode() == 40) {
            jScrollPane2.setVisible(true);
            jList1.requestFocus();
        } else if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            File ff = new File(jDirectorio_2.getText());
            if (ff.exists()) {
                jPathDirecAnalisis = ff.getAbsolutePath();
                jAbrirTemp2(ff);
            }
        }        
    }//GEN-LAST:event_jDirectorio_2KeyPressed
    
    private void jB_AbrirAnalisisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_AbrirAnalisisActionPerformed
        funcion_Abrir();
    }//GEN-LAST:event_jB_AbrirAnalisisActionPerformed

    private void jTipoDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTipoDataActionPerformed
        if (jActivarArea.isSelected()) {
            jOb_Analisis.setAreaData(jTipoData.getSelectedIndex());
        }
    }//GEN-LAST:event_jTipoDataActionPerformed

    private void jActivarAreaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jActivarAreaActionPerformed
        if (jActivarArea.isSelected()) {
            jOb_Analisis.setAreaData(jTipoData.getSelectedIndex());
        } else {
            jOb_Analisis.setOcultar();
        }
    }//GEN-LAST:event_jActivarAreaActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:        
        inputMap.keys();//Comandos por teclas.
        jOb_Analisis.resetPolig();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jImg_izqMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jImg_izqMousePressed
        if (INDICE_2 != -1) {
            try {
                Thread.sleep(100);
                
                direcRec = 0;
                runContinB.start();
            } catch (InterruptedException ex) {
                Logger.getLogger(DMMPRINCIPAL.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_jImg_izqMousePressed

    private void jImg_izqMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jImg_izqMouseReleased
        // TODO add your handling code here:
        runContinB.stop();
    }//GEN-LAST:event_jImg_izqMouseReleased

    private void jImg_izqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jImg_izqActionPerformed
        if ((evt.getModifiers() != 0) || INDICE_2 == -1) { return; }
        if (!(INDICE_2 <= 0)) {
            INDICE_2--;
        }
        jTxIndice_2.setText(new Integer(INDICE_2).toString());
        jImg_view.setText(direc_2[INDICE_2].substring(0, direc_2[INDICE_2].length() - 4));
        jOb_Analisis.setImagen(leerIm(jDirectorio_2.getText(), direc_2[INDICE_2]));
        jProgreso_2.setValue(INDICE_2);
        
    }//GEN-LAST:event_jImg_izqActionPerformed

    private void jImg_derMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jImg_derMousePressed
        try {
            direcRec = 1;
            Thread.sleep(100);
            
            runContinB.start();
        } catch (InterruptedException ex) {
            Logger.getLogger(DMMPRINCIPAL.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jImg_derMousePressed

    private void jImg_derMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jImg_derMouseReleased
        // TODO add your handling code here:
        runContinB.stop();
    }//GEN-LAST:event_jImg_derMouseReleased

    private void jImg_derActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jImg_derActionPerformed
        if ((evt.getModifiers() != 0) || INDICE_2 == -1) { return; }
        if (!(INDICE_2 >= direc_2.length - 1)) {
            INDICE_2++;
        }
        jTxIndice_2.setText(new Integer(INDICE_2).toString());
        jImg_view.setText(direc_2[INDICE_2].substring(0, direc_2[INDICE_2].length() - 4));
        jOb_Analisis.setImagen(leerIm(jPathDirecAnalisis, direc_2[INDICE_2]));
        jProgreso_2.setValue(INDICE_2);
        
    }//GEN-LAST:event_jImg_derActionPerformed

    private void jTxIndice_2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTxIndice_2ActionPerformed
        // TODO add your handling code here:
        if (INDICE_2 == -1) { return; }
        try {
            INDICE_2 = Integer.parseInt(jTxIndice_2.getText());
            if (INDICE_2 > direc_2.length - 1) {
                INDICE_2 = direc_2.length - 1;
                jTxIndice_2.setText(String.valueOf(INDICE_2));
            }
            jProgreso_2.setValue(INDICE_2);
            jOb_Analisis.setImagen(leerIm(jDirectorio_2.getText(), direc_2[INDICE_2]));

        } catch (NumberFormatException e) {
            jProgreso_2.setValue(0);
            jTxIndice_2.setText("00");
        }
    }//GEN-LAST:event_jTxIndice_2ActionPerformed

    private void jStop_AnalisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jStop_AnalisActionPerformed
        jOb_Analisis.stop();
        expeRimento.stop();
        mCONTROL.setControl(1, true); //Guardar datos analisis.
        mCONTROL.setControl(2, true);
        
        mBoton.setStartColor(new Color(92,136,163));
        jProgreso_2.setValue(0);
        mBoton.setText("INICIAR");
    }//GEN-LAST:event_jStop_AnalisActionPerformed

    /**
     * CONTROL PARA DETERMINAR SI BUSCA, ANALIZA o EXPERIMENTO COMPLETO.
     * @param evt 
     */
    private void jControl_AnalisisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jControl_AnalisisActionPerformed
        //ACTIVAR EL CONTROL DEL OBJETO EXPERIMENTO
        if(jControl_Analisis.getSelectedIndex() == 3)
            expeRimento.setACTIVACION(true);
        else
            expeRimento.setACTIVACION(false);
        
        jOb_Analisis.setTipoAnalisis(jControl_Analisis.getSelectedIndex());
        jOb_Analisis.setTitulo(jControl_Analisis.getSelectedItem().toString());
        
        
        
        // Habilitar o NO la ventana para experimento completo.
        if(jControl_Analisis.getSelectedIndex() == 3)
            jTab_Analisis.setEnabledAt(2, true);
        else{
            jTab_Analisis.setEnabledAt(2, false);
            if(jTab_Analisis.getSelectedIndex() == 2)
                jTab_Analisis.setSelectedIndex(0);
        }        
    }//GEN-LAST:event_jControl_AnalisisActionPerformed

    private void jList1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jList1MouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            jPathDirecAnalisis = jPathAnalisis + "/" + listExper[jList1.getSelectedIndex()];

            jDirectorio_2.setText(jPathDirecAnalisis);
            jScrollPane2.setVisible(false);
            jDirectorio_2.requestFocus();
            jAbrirTemp2(new File(jPathDirecAnalisis));
        }
    }//GEN-LAST:event_jList1MouseClicked

    private void jList1ValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_jList1ValueChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_jList1ValueChanged

    private void jList1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jList1FocusLost
        // TODO add your handling code here:
        jScrollPane2.setVisible(false);
    }//GEN-LAST:event_jList1FocusLost

    private void jList1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jList1KeyPressed
        // TODO add your handling code here:
        if (evt.getKeyChar() == KeyEvent.VK_ESCAPE) {
            jScrollPane2.setVisible(false);
            jDirectorio_2.requestFocus();
        } else if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            jPathDirecAnalisis = jPathAnalisis + "/" + listExper[jList1.getSelectedIndex()];
            jDirectorio_2.setText(jPathDirecAnalisis);
            jScrollPane2.setVisible(false);
            jDirectorio_2.requestFocus();
            jAbrirTemp2(new File(jPathDirecAnalisis));
        }
    }//GEN-LAST:event_jList1KeyPressed

    private void formKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyPressed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_formKeyPressed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        // TODO add your handling code here:        
        jOb_Analisis.ClosingObject();
        expeRimento.stop();
        direc  = null;
        direc2 = null;
        
        LimpiadorMemoria.gc();
        
        mi_hebra.limpiarMemoria();
        hebraBuscar.limpiarMemoria();
        
    }//GEN-LAST:event_formWindowClosing

    private void jExper_InfStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jExper_InfStateChanged
        // TODO add your handling code here:
        if( !mCONTROL.getControl(1) ) // SI NO está todo OK, no entra
            return;
        
        int d1 = Integer.parseInt(jExper_Inf.getValue().toString());
        int d2 = Integer.parseInt(jExper_Sup.getValue().toString());
        if(d1 < d2)
            jExper_Inf.setValue(new Integer(d1));
        else
            jExper_Inf.setValue(new Integer(d2));
        
        expeRimento.setMinIndex(Integer.parseInt(jExper_Inf.getValue().toString()));
        jT_IndeInf.setText(listExper[Integer.parseInt(jExper_Inf.getValue().toString())-1]);        
    }//GEN-LAST:event_jExper_InfStateChanged

    private void jExper_SupStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jExper_SupStateChanged
        // TODO add your handling code here:
        if( !mCONTROL.getControl(1) ) // SI NO está todo OK, no entra
            return;
        
        int d1 = Integer.parseInt(jExper_Inf.getValue().toString());
        int d2 = Integer.parseInt(jExper_Sup.getValue().toString());
        if(d1 < d2)
            jExper_Sup.setValue(new Integer(d2));
        else
            jExper_Sup.setValue(new Integer(d1));
        
        expeRimento.setMaxIndex(Integer.parseInt(jExper_Sup.getValue().toString()));
        jT_IndeSup.setText(listExper[Integer.parseInt(jExper_Sup.getValue().toString())-1]);
    }//GEN-LAST:event_jExper_SupStateChanged

    private void jAnalisisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jAnalisisActionPerformed
        // TODO add your handling code here:
        jOb_Analisis.setActAnalisis(jAnalisis.isSelected());
    }//GEN-LAST:event_jAnalisisActionPerformed

    private void jR_ShapeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jR_ShapeActionPerformed
        // TODO add your handling code here:
        dataGrafico.setShapeActivar(jR_Shape.isSelected());
    }//GEN-LAST:event_jR_ShapeActionPerformed

    private void jVerAnalisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jVerAnalisActionPerformed
        // TODO add your handling code here:
        tipoImagen = jVerAnalis.getSelectedIndex();
    }//GEN-LAST:event_jVerAnalisActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
        dataGrafico.setViewCurvas(jComboBox1.getSelectedIndex());
        
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jBut_SaveDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBut_SaveDataActionPerformed
        // TODO add your handling code here:
        if(mBoton.getText().equalsIgnoreCase("INICIAR")){
            jOb_Analisis.saveDataGrafics();
        }            
    }//GEN-LAST:event_jBut_SaveDataActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        JDirChooser mDir = new JDirChooser();
        
        if(mDir.showDialog((Component) this, "Secuencias", null, "DIRECTORIO DESTINO:") 
                            == JDirChooser.OK_OPTION) {
            jPathSeparacion  = mDir.getSelectedFile().getPath();
            String listSep[] = mDir.getSelectedFile().list(new MyFilter("-P"));
            
            jList_names.removeAllItems();
            for(String std:listSep)
                jList_names.addItem(std);
    
            jSecuDestino.setText(jPathSeparacion);   
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jB_AbrirGraficosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_AbrirGraficosActionPerformed
        // TODO add your handling code here:
        int dd = grafExperimento();
    }//GEN-LAST:event_jB_AbrirGraficosActionPerformed

    private void jTableGraficosMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableGraficosMousePressed
        // TODO add your handling code here:
        if(mCONTROL.getControl(3) == false) return;

        int col = jTableGraficos.columnAtPoint(evt.getPoint());
        int row = jTableGraficos.rowAtPoint(evt.getPoint());
        if(col == 0){}
        if(col == 2){
            Boolean b  = (Boolean)jTableGraficos.getValueAt(row, 2);
            String std = (String)jTableGraficos.getValueAt(row, 1);
            generalGraf.verCadaSerie(std, !b);
            generalGraf.verSerieUmbral(std, !b);
            if(b){
                generalGraf.crearLista(!b, std);
            }
        }
    }//GEN-LAST:event_jTableGraficosMousePressed

    private void jCheckBox2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox2ActionPerformed
        // TODO add your handling code here:
        jTextField1.setEnabled(jCheckBox2.isSelected());
        jTextField2.setEnabled(jCheckBox2.isSelected());
    }//GEN-LAST:event_jCheckBox2ActionPerformed

    private void jTextField2KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField2KeyPressed
        // TODO add your handling code here:
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            String txt = jTextField2.getText();
            int rango = Integer.parseInt(txt.substring(0, txt.length()-3));
            if(rango >= 24){
                generalGraf.setRangoHoras(rango);
            }
        }            
    }//GEN-LAST:event_jTextField2KeyPressed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
        double inf = Integer.parseInt(jTextField3.getText());
        double sup = Integer.parseInt(jTextField4.getText());
        generalGraf.setRangosEjes(inf, sup);        
    }//GEN-LAST:event_jTextField3ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        // TODO add your handling code here:
        double inf = Integer.parseInt(jTextField3.getText());
        double sup = Integer.parseInt(jTextField4.getText());
        generalGraf.setRangosEjes(inf, sup);        
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void jTDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTDataActionPerformed
        // TODO add your handling code here:
        generalGraf.setIndexV(jTData.getSelectedIndex());
        
        for(int i=0; i < jTableGraficos.getRowCount(); i++){
            boolean b  = (Boolean)jTableGraficos.getValueAt(i, 2);
            String std = (String)jTableGraficos.getValueAt(i, 1);
            generalGraf.verCadaSerie(std, b);
        }
    }//GEN-LAST:event_jTDataActionPerformed

    private void jS_CicloLuzStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jS_CicloLuzStateChanged
        // TODO add your handling code here:
        generalGraf.setParamCicloLuz(jComboBox3.getSelectedIndex(),
                           Integer.parseInt(jS_CicloLuz.getValue().toString()),
                           Integer.parseInt(jS_hInicio.getValue().toString()));    
    }//GEN-LAST:event_jS_CicloLuzStateChanged

    private void jS_hInicioStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jS_hInicioStateChanged
        // TODO add your handling code here:
        generalGraf.setParamCicloLuz(jComboBox3.getSelectedIndex(),
                           Integer.parseInt(jS_CicloLuz.getValue().toString()),
                           Integer.parseInt(jS_hInicio.getValue().toString()));
    }//GEN-LAST:event_jS_hInicioStateChanged

    private void jComboBox3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox3ActionPerformed
        // TODO add your handling code here:
        generalGraf.setParamCicloLuz(jComboBox3.getSelectedIndex(),
                           Integer.parseInt(jS_CicloLuz.getValue().toString()),
                           Integer.parseInt(jS_hInicio.getValue().toString()));
    }//GEN-LAST:event_jComboBox3ActionPerformed

    private void jCheck_BATCHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheck_BATCHActionPerformed
        // TODO add your handling code here:
        if(jCheck_BATCH.isSelected()){
            jCheck_BATCH.setText("BATCH");
            jList_names.setEnabled(true);
        }else{
            jCheck_BATCH.setText("NO BATCH");
            jList_names.setEnabled(false);
        }            
    }//GEN-LAST:event_jCheck_BATCHActionPerformed

    private void formKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyReleased
        // TODO add your handling code here:
        System.out.println("Soltó...");   
    }//GEN-LAST:event_formKeyReleased

    private void jTFiltroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTFiltroActionPerformed
        // TODO add your handling code here:
        generalGraf.setVerSeñalFiltro(jTFiltro.getSelectedIndex());
        
        for(int i=0; i < jTableGraficos.getRowCount(); i++){
            boolean b  = (Boolean)jTableGraficos.getValueAt(i, 2);
            String std = (String)jTableGraficos.getValueAt(i, 1);
            
            generalGraf.verCadaSerie(std, b);
        }
    }//GEN-LAST:event_jTFiltroActionPerformed

    private void jB_ResetCurvasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_ResetCurvasActionPerformed
        // TODO add your handling code here:
        int td = jTabbedPane2.getSelectedIndex(); 
        if(td == 0)
            activarApagarGraficos(td, jTableGraficos, false);//Tabla de VER GRAFICOS
        else
            activarApagarGraficos(td, jTableCambiar, false);//Tabla de MOVER GRAFICOS
    }//GEN-LAST:event_jB_ResetCurvasActionPerformed

    private void jB_VerCurvasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_VerCurvasActionPerformed
        int td = jTabbedPane2.getSelectedIndex();
        if(td == 0)
            activarApagarGraficos(td, jTableGraficos, true);
        else
            activarApagarGraficos(td, jTableCambiar, true);        
    }//GEN-LAST:event_jB_VerCurvasActionPerformed

    private void jTableGraficosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableGraficosMouseClicked
        // TODO add your handling code here:
        if(mCONTROL.getControl(3) == false) return;
        
        int col = jTableGraficos.columnAtPoint(evt.getPoint());
        int row = jTableGraficos.rowAtPoint(evt.getPoint());
        String std = (String)jTableGraficos.getValueAt(row, 1);
        Boolean bb = (Boolean)jTableGraficos.getValueAt(row, 2);
        
        if(evt.getClickCount() == 1){
            if(col == 0 && bb){
                generalGraf.setCurvaWidth(std, 3.0f); //Busca curva normal a marcar
                generalGraf.setCurvaWithUmbral(std, Color.GREEN);
                generalGraf.serieNomb.setText(" MOSCA " + std + " ");
            }
            if(col == 1){
                std = generalGraf.findInList(std);
            }
        }else
            if(evt.getClickCount() > 1){
                if(col == 1){
                    Color color = com.bric.swing.ColorPicker.showDialog(this, Color.RED);
                    if(color != null){
                        if(jC_Color.getSelectedIndex() == 0)
                            generalGraf.setCurvaColorDATA(std, color); //OJO, exclusivo para la curva de datos
                        else
                            generalGraf.setCurvaColor(std, color);
                    }
                }
                if(col == 0){
                    generalGraf.setCurvaWidth(std, 1.0f);
                    generalGraf.setCurvaWithUmbral("", Color.RED);
                }
        }
    }//GEN-LAST:event_jTableGraficosMouseClicked

    private void jActivarCurvaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jActivarCurvaActionPerformed
        generalGraf.setParamCurvaData(1, -1, jActivarCurva.isSelected(), false);
    }//GEN-LAST:event_jActivarCurvaActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        generalGraf.setParamCurvaData(0, 0, false, false);
        DefaultTableModel model = (DefaultTableModel)jTabData.getModel();
        model.setNumRows(0);
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jSp_DatpuntosStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSp_DatpuntosStateChanged
        // TODO add your handling code here:
        int val = Integer.parseInt(jSp_Datpuntos.getValue().toString());
        generalGraf.setParamCurvaData(4, val, false, false);
    }//GEN-LAST:event_jSp_DatpuntosStateChanged

    private void jC_ColorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jC_ColorActionPerformed
        int index = jC_Color.getSelectedIndex();
        generalGraf.setTipoCurvaColor(index);
    }//GEN-LAST:event_jC_ColorActionPerformed

    /**
     * Evento presionar "Enter" sobre la barra de direccion. Abre una ventana para 
     * buscar la direccion (path) de las imagenes a cargar.
     * @param evt 
     */    
    private void jPathImagenesKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jPathImagenesKeyPressed
        // TODO add your handling code here:
        if (evt.isControlDown() && evt.getKeyChar() == KeyEvent.VK_ENTER) {
            JDirChooser mDir = new JDirChooser();
            if (mDir.showDialog((Component) this) == JDirChooser.OK_OPTION){
                jPathDirecAnalisis = mDir.getSelectedFile().getAbsolutePath();
                jAbrirTemp(mDir.getSelectedFile());
            }
            
        } else if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            File ff = new File(jDirectorio_2.getText());
            if (ff.exists()) {
                jPathDirecAnalisis = ff.getAbsolutePath();
                jAbrirTemp2(ff);
            }
        }
    }//GEN-LAST:event_jPathImagenesKeyPressed

    /**
     * Mètodo para setear el tiempo de avance entre un set de imàgenes y el 
     * siguiente. Dado el disco y su velocidad, el tiempo es de 720 seg (12 min)
     * aproximadamente.
     * @param evt 
     */
    private void jRangoStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jRangoStateChanged
        mi_hebra.setTimeSalto(Double.valueOf(jRango.getValue().toString()));        
    }//GEN-LAST:event_jRangoStateChanged
    /**
     * Borra la lista de imagenes a separar. Secciòn 1.
     * @param evt Evento sobre el menu.
     */
    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        // TODO add your handling code here:
        hebraBuscar.borrarListas();
    }//GEN-LAST:event_jMenuItem3ActionPerformed
 
    private void jSpi_ToleranciaStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSpi_ToleranciaStateChanged
        // TODO add your handling code here:
        mi_hebra.setTolerancia(Double.valueOf(jSpi_Tolerancia.getValue().toString()));
    }//GEN-LAST:event_jSpi_ToleranciaStateChanged

    private void jGenotypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jGenotypeActionPerformed
        // TODO add your handling code here:
        int index = jGenotype.getSelectedIndex();
        if(index == -1){
            ComboBoxModel model = jGenotype.getModel();
            Object    newString = model.getSelectedItem();
            jGenotype.removeItem(newString);
            
            jGenotype.addItem(newString);
            return;
        }
        if(index == 3)
            jGenotype.setEditable(true);
        else
            jGenotype.setEditable(false);
        
        jOb_Analisis.botonSET("SET");
            
    }//GEN-LAST:event_jGenotypeActionPerformed

    private void jB_SETActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jB_SETActionPerformed
        if(jB_SET.getText().equalsIgnoreCase("---"))return;
        
        jOb_Analisis.guarParametros(1); //Guardo parametros
        String Geno = jGenotype.getSelectedItem().toString();
        String Hora = jComb_Hora.getSelectedItem().toString() + ":" +
                            jComb_Min.getSelectedItem().toString();

        boolean d1 = jOb_Analisis.saveDataParametros(Geno, Hora, horaRefInit);
        
        if(d1){
            jB_SET.setText("---");
            jB_SET.setForeground(new Color(76, 76, 76));
        }
    }//GEN-LAST:event_jB_SETActionPerformed

    private void formComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentResized
        // TODO add your handling code here:
        int td = jSplitPane3.getWidth();
        int tc = jSplitPane3.getHeight();
        
        jSplitPane1.setDividerLocation(this.getHeight() - 270);
        jSplitPane2.setDividerLocation(this.getWidth()  - 270);
        
        jB_VerCurvas.setLocation(this.getWidth() - 120, jB_VerCurvas.getY());
        jB_ResetCurvas.setLocation(this.getWidth() - 120, jB_ResetCurvas.getY());
        
        jPath_Graficos.setLocation(this.getWidth() - 512, jPath_Graficos.getY());
        jB_AbrirGraficos.setLocation(this.getWidth() - 280, jB_AbrirGraficos.getY());
        
        jP_Umbral.setLocation(jPath_Graficos.getX(), jP_Umbral.getY());
        
    }//GEN-LAST:event_formComponentResized

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        fBorrador.setVisible(true);
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jScrollBar1AdjustmentValueChanged(java.awt.event.AdjustmentEvent evt) {//GEN-FIRST:event_jScrollBar1AdjustmentValueChanged
        // TODO add your handling code here:
        if(jControTiempo.isSelected()){
            int valor = jScrollBar1.getValue() * 60 * 60 * 100;
            jTiempoMin.setText(String.valueOf( valor / (1000 * 60 * 60)));
            generalGraf.moverSeries(valor);
        }
    }//GEN-LAST:event_jScrollBar1AdjustmentValueChanged

    private void jPath_GraficosKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jPath_GraficosKeyPressed
        String[] list1 = null;
        String[] list2 = null;
        String opc[] = {"SI", "NO"};
        int dd = -1;
        
        if(evt.getKeyChar() == KeyEvent.VK_ENTER){
            
            if(jPath_Graficos.getText().compareToIgnoreCase("://") == 0){
                dd = grafExperimento();
            }
            
            else{
                File ff = new File(jPath_Graficos.getText());
                if(ff.exists()){
                    list1 = ff.list(new MyFilter(".tif"));
                    if(list1.length > 10){
                        list2 = ff.getParentFile().list(new MyFilter(("-P")));
                        if(list2.length > 5){
                            dd = JOptionPane.showOptionDialog(null, "Cargar ?", "EXPERIMENTO COMPLETO",
                                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null,
                                    opc, opc[0]);
                            if(dd == 0)
                                jPathGraficos = ff.getParentFile().getPath();
                                generalGraf.starrt(jPathGraficos);
                        }
                    }
                }
            }
        }
    }//GEN-LAST:event_jPath_GraficosKeyPressed

    private void jTableCambiarMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableCambiarMousePressed
        if(mCONTROL.getControl(3) == false) return;
        
//        int col = jTableCambiar.columnAtPoint(evt.getPoint());
//        int row = jTableCambiar.rowAtPoint(evt.getPoint());
//        switch(col){
//            case 0:
//                break;
//            case 1:
//            case 2:
//                Boolean bb = (Boolean)jTableGraficos.getValueAt(row, 2);
//                
//                Boolean b  = !(Boolean)jTableCambiar.getValueAt(row, 2);
//                String st2 = (String)jTableCambiar.getValueAt(row, 1);
//                if(bb){
//                    //Guardo en la lista !.
//                    generalGraf.crearLista(b, st2);
//                    generalGraf.moverSeries(jScrollBar1.getValue() * 60 * 60 * 100);
//                    if(!b)
//                        generalGraf.verCadaSerie(st2, true);
//                }else
//                    jTableCambiar.setValueAt(true, row, 2);
//        }        
    }//GEN-LAST:event_jTableCambiarMousePressed

    private void jControTiempoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jControTiempoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jControTiempoActionPerformed

    private void jRadioButtonMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItem1ActionPerformed
        mCONTROL.setControl(19, jRadioButtonMenuItem1.isSelected());
    }//GEN-LAST:event_jRadioButtonMenuItem1ActionPerformed

    private void jSplitPane3ComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_jSplitPane3ComponentResized
        // TODO add your handling code here:
        int Ancho = jSplitPane3.getHeight();
        jSplitPane3.setDividerLocation(Ancho - 45);        
    }//GEN-LAST:event_jSplitPane3ComponentResized

    private void jComb_HoraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComb_HoraActionPerformed
        jOb_Analisis.botonSET("SET");        
    }//GEN-LAST:event_jComb_HoraActionPerformed

    private void jComb_MinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComb_MinActionPerformed
        jOb_Analisis.botonSET("SET");
    }//GEN-LAST:event_jComb_MinActionPerformed

    private void jProgreso_2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jProgreso_2MouseClicked
        if (jProgreso_2.contains(evt.getPoint())) {
            double dd = (double) evt.getPoint().x * ((double) jProgreso_2.getMaximum()
                    / (double) jProgreso_2.getWidth());
            jProgreso_2.setValue((int) Math.round(dd));

            INDICE_2 = (int) Math.round(dd);
            jProgreso_2.setValue(INDICE_2);
            jTxIndice_2.setText(Integer.toString(INDICE_2));
            jImg_view.setText(direc_2[INDICE_2].substring(0, direc_2[INDICE_2].length() - 4));
            
            jOb_Analisis.setImagen(leerIm(jPathDirecAnalisis, direc_2[INDICE_2]));
            jOb_Analisis.repaint();
        }        
    }//GEN-LAST:event_jProgreso_2MouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        String std1 = "17-01-09 13.11.19,875.tif";
        std1 = std1.replace(".", ":");
        std1 = std1.replace(",", ".");
        
        String std2 = "17-01-09 13.23.18,187.tif";
        std2 = std2.replace(".", ":");
        std2 = std2.replace(",", ".");
        
        SimpleDateFormat sdf = new SimpleDateFormat("yy-M-dd hh:mm:ss.SSS");
        
        Date moment  = new Date(1498633960828L);
        Date moment2 = new Date(1498633920000L);
        
        mensaje(moment);
        mensaje(moment2);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        funcion_Abrir();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jRDesviaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRDesviaActionPerformed
        // TODO add your handling code here:
       if(jRDesvia.isSelected()){
           jComp.setText("DESVIACION");
           jRBordes.setSelected(false);
           //.............
       }else
           jRDesvia.setSelected(true);
    }//GEN-LAST:event_jRDesviaActionPerformed

    private void jRBordesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRBordesActionPerformed
        // TODO add your handling code here:
       if(jRBordes.isSelected()){
           jComp.setText("BORDES");
           jRDesvia.setSelected(false);
           //.............
       }else
           jRBordes.setSelected(true);
    }//GEN-LAST:event_jRBordesActionPerformed

    private void j_AbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_j_AbrirActionPerformed
        int ii = jTabbedPane1.getSelectedIndex();
        switch(ii){
            case 2:
                int dd = grafExperimento();
                break;
        }
    }//GEN-LAST:event_j_AbrirActionPerformed

    private void jSp_UmbralGrafStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSp_UmbralGrafStateChanged
        int id = -1;
        int intUmbral = Integer.parseInt(jSp_UmbralGraf.getValue().toString());
        
        generalGraf.UMBRAlGRAF = intUmbral;
        
        String stdd = generalGraf.serieNomb.getText().substring(7, 10);
        
        generalGraf.ANALISIS_y_DETECCION("df2", 1);
        generalGraf.setCurvaWithUmbral(stdd, Color.GREEN);
        
    }//GEN-LAST:event_jSp_UmbralGrafStateChanged

    private void jSp_FechaStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_jSp_FechaStateChanged
        // TODO add your handling code here:
        horaRefInit = (Date)jSp_Fecha.getValue();
        generalGraf.horaRefInit = horaRefInit;
        dataGrafico.horaRefInit = horaRefInit;        
    }//GEN-LAST:event_jSp_FechaStateChanged

    private void jImg_derMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jImg_derMouseClicked
        // TODO add your handling code here:
        if (INDICE_2 == -1) {return; }
        if (!(INDICE_2 >= direc_2.length - 1)) {
            INDICE_2++;
        }
        jTxIndice_2.setText(new Integer(INDICE_2).toString());
        jImg_view.setText(direc_2[INDICE_2].substring(0, direc_2[INDICE_2].length() - 4));
        jOb_Analisis.setImagen(leerIm(jPathDirecAnalisis, direc_2[INDICE_2]));
        jProgreso_2.setValue(INDICE_2);
    }//GEN-LAST:event_jImg_derMouseClicked

    private void jImg_izqMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jImg_izqMouseClicked
        if (INDICE_2 == -1) { return; }
        if (!(INDICE_2 <= 0)) {
            INDICE_2--;
        }
        jTxIndice_2.setText(new Integer(INDICE_2).toString());
        jImg_view.setText(direc_2[INDICE_2].substring(0, direc_2[INDICE_2].length() - 4));
        jOb_Analisis.setImagen(leerIm(jDirectorio_2.getText(), direc_2[INDICE_2]));
        jProgreso_2.setValue(INDICE_2);
        
    }//GEN-LAST:event_jImg_izqMouseClicked

    
//----------------  TAREAS PEQUEÑAS. CALCULOS INTERNOS   -----------------//
    private void LimpiarMemoria(){
        LimpiadorMemoria.gc();
    }
    private void setAlgúnParametro(String _nombre, int tipo){
        jSplitPane3.setDividerLocation(tipo - 40);
    }
    private void activarApagarGraficos(int _con, JTable tabla, boolean _condition){
        int[] dd = tabla.getSelectedRows(); //Segun la enviada por el requerimiento        
        if(dd.length >= 1){
            for(int j=0; j < dd.length; j++){
                String std = (String)tabla.getValueAt(dd[j], 1);
                if(_con == 0){
                    generalGraf.verCadaSerie(std, _condition);
                    generalGraf.verSerieUmbral(std, _condition);
                }
            }
        }else
            if(!_condition){
                for(int j=0; j < dd.length; j++){
                    String std = (String)tabla.getValueAt(dd[j], 1);
                    tabla.setValueAt(_condition, dd[j], 2);
                    if(_con == 0){
                        generalGraf.verCadaSerie(std, _condition);
                    }
                }
            }
    }
// ----------------------------------------------------------------------------- //     
    
    private int grafIndividual(){
        return(0);
    }
    
    private int saveDataAnalisis(int codigo){
        String Geno = jGenotype.getSelectedItem().toString();
        String Hora = jComb_Hora.getSelectedItem().toString() + ":" +
                            jComb_Min.getSelectedItem().toString();
        
        jOb_Analisis.saveDataParametros(Geno, Hora, horaRefInit);
        jOb_Analisis.guarParametros(1);
        return(0);
    }
    
    /**
     * Al abrir y llamar a este método, cargamos las curvas de cada uno de los 
     * animales de un experimento seleccionado. Se carga cada animal, se abre el 
     * archivo qeu contiene cada vector de 
     * @return 
     */
    private int grafExperimento(){        
//        JFileChooser mDirr = new JFileChooser("/media/felipe/DATA/aCiNV_Mayo 2016/EXP_2017/ExperiPasado/10_12 - 12");
        JFileChooser mDirr = new JFileChooser();
        
        mDirr.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        mDirr.setCurrentDirectory(pathGrafico);
        
        if (mDirr.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            int cont = 0;
            pathGrafico = mDirr.getSelectedFile().getParentFile();
            
            jPathGraficos = mDirr.getSelectedFile().getAbsolutePath(); //get Path
            jPath_Graficos.setText(jPathGraficos); //Set path in object.
            generalGraf.setControl(2);
            generalGraf.UMBRAlGRAF = 100;
            
        //  EJECUTA LA CARGA DE TODOS LOS ANIMALES  \\
            generalGraf.starrt(jPathGraficos); 
            
        }
        return(0);
    }
    
    //AVANCE Y RETROCESO DE IMAGENES
    public void moveImagnes(){
        jProgreso.setValue(INDICE);
        jTexIndice.setText(new Integer(INDICE).toString());
        jTexFile.setText(direc[INDICE].substring(0, direc[INDICE].length() - 4));
        BufferedImage imm = leerIm(jPathImage, direc[INDICE]).getAsBufferedImage();
        jImgPr.setIcon(new ImageIcon((Image) imm));
        repaint();
    }
    public void setData(Minute _min, double _datA, double _datB){
        dataGrafico.setData(_min, _datA, _datB);
    }
    public JButton returnButton(){
        return(mBoton);
    }
    public JPanel returPanel(){
        return(jPlot_panel);
    }
    public jAnalisis returAnalis(){
        return(jOb_Analisis);
    }
    public jPlot_times returnGeneralGraf(){
        return(generalGraf);
    }
    public String returnDirecAnalisis(){
        return(jPathDirecAnalisis);
    }
    public String returnDirecImagenes(){
        return(jPathImage);
    }
    public void miMetodo(int _code){
        processKeyEvent(new KeyEvent(this, KeyEvent.KEY_PRESSED, 
                System.currentTimeMillis(), 0, _code, '-'));
    }
    /**
     * Metodo para determinar el tiempo (milisegundos), en base al Nombre (String),
     * de una imagen en particular.
     * @param dia
     * @return 
     */
    public Date getTime(String _dia){
        String Hora = "";
        Date moment = null;
        
        Hora = _dia.replace(".", ":");
        Hora = Hora.replace(",", ".");        
        
        SimpleDateFormat sdf = new SimpleDateFormat("yy-M-dd hh:mm:ss.SSS");
        
        try {
            moment = sdf.parse(Hora.substring(0, 21));
            
        } catch (ParseException ex) {
            Logger.getLogger(DMMPRINCIPAL.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return(moment);
    }
    
    private void mBottonAction1(ActionEvent evt){
        if(!mCONTROL.getControl(2))
            return;
        
        //Aca cuando el experimento es completo... COMPLETO.
        if(jControl_Analisis.getSelectedIndex() == 3){
            
            mCONTROL.setControl(2, false); //No dejo que cambie, cuando esta corriendo
            
            if(mBoton.getText().equalsIgnoreCase("INICIAR") ||
                    mBoton.getText().equalsIgnoreCase("CONTIN..")){
                mBoton.setStartColor(new Color(255,0,0));
                mBoton.setText("PAUSE");
                jExper_InfStateChanged(null);
                expeRimento.continuar();
                
            }else{
                mBoton.setStartColor(new Color(255, 100, 0));
                mBoton.setText("CONTIN..");
                jOb_Analisis.setSleep();
            }
            
        }else{
            
        if(mBoton.getText().equalsIgnoreCase("INICIAR") && !jOb_Analisis.isRunning()){
            mBoton.setStartColor(new Color(255,0,0));
            mBoton.setText("PAUSE");
            
            jActivarArea.setSelected(false);
            jActivarAreaActionPerformed(evt);
            dataGrafico.resetData();
        //----------------------------------------------\\
            jOb_Analisis.cargarData();
            jOb_Analisis.botonSET("---");
        //----------------------------------------------\\    

            jOb_Analisis.start();
            
        }else
            if(mBoton.getText().equalsIgnoreCase("CONTIN..")){
                mBoton.setStartColor(new Color(255,0,0));
                mBoton.setText("PAUSE");
                jOb_Analisis.despertar();
            }else{
                mBoton.setStartColor(new Color(200,200,0));
                mBoton.setText("CONTIN..");
                jOb_Analisis.setSleep();
            }
        }
    }
    private RenderedOp leerIm(String path, String name){
        try {
            FileSeekableStream fTemp = new FileSeekableStream(path + "/" + name);
            ParameterBlock pb = new ParameterBlock();
            pb.addSource(JAI.create("stream", fTemp));
            pb.add(MATRIX);

            return( imCloseInterLine(JAI.create("BandCombine", pb, null).getAsBufferedImage()));
        //    return( imCloseInterLine(JAI.create("stream", fTemp).getAsBufferedImage()));            
        } catch (IOException ex) {
            Logger.getLogger(DMMPRINCIPAL.class.getName()).log(Level.SEVERE, null, ex);
            return(null);
        }
    }
    private boolean GuardarImagen(){
        FileSeekableStream fTemp = null;
        String _dFold = "";
        File fdir = null;
        try {
            fTemp = new FileSeekableStream(jPathImage + "/" + direc[INDICE]);
            
            _dFold = (String)jList_names.getSelectedItem();
            if(_dFold == null || !jList_names.isEnabled()) _dFold = "";
            
            
            fdir = new File(jPathSeparacion + "/" + _dFold);
            if(fdir.exists()){
                FileOutputStream os = new FileOutputStream(fdir.getAbsolutePath() + "/" + direc[INDICE]);
                ImageEncoder encoder = ImageCodec.createImageEncoder("TIFF", os, null);
                encoder.encode(JAI.create("stream", fTemp));
                os.close();
                return(true);
            }
            
        } catch (IOException ex) {
            Logger.getLogger(DMMPRINCIPAL.class.getName()).log(Level.SEVERE, null, ex);
            return(false);
        } finally {
            try {
                fTemp.close();
                return(false);
            } catch (IOException ex) {
                Logger.getLogger(DMMPRINCIPAL.class.getName()).log(Level.SEVERE, null, ex);
                return(false);
            }
        }
    }

    
//= FUNCIONES IMPLEMENTADAS PARA MANEJO DE IMAGENES, TRABAJO CON STACK,=\\
//==== EJECUCION DE FUNCIONES DE ABRIR Y CAGAR LISTAS DE IMAGENES  =====\\
    void funcion_Abrir(){
        //JDirChooser mDir = new JDirChooser("/media/felipe/DATA/aCiNV_Mayo 2016/EXP_2017/Datos John/Series/");
        JDirChooser mDir = new JDirChooser("/media/felipe/DATA/aCiNV_Mayo 2016/EXP_2017/Exp_Ene-04_B/");
        //JDirChooser mDir = new JDirChooser();
        
        if (mDir.showDialog((Component) this) == JDirChooser.OK_OPTION) {
            /* Carga en la variable, la direcciòn de anàlisis. */
            jPathAnalisis = mDir.getSelectedFile().getAbsolutePath();
                
                /*Lista de carpetas con datos y parametros*/
                listExper = new File(jPathAnalisis).list(new MyFilter("-P"));
                
                if (listExper.length != 0){
                //------------------------------------------------------------\\    
                    if(!(new File(jPathAnalisis + "/GENERAL").exists()))
                        new File(jPathAnalisis + "/GENERAL").mkdir();
                    
                    jPathDirecAnalisis = jPathAnalisis + "/" + listExper[0];
                    jDirectorio_2.setText(jPathDirecAnalisis);
                    jAbrirTemp2(new File(jPathDirecAnalisis));
                    
                    
                    mCONTROL.setControl(1, true); //Activo control para experimento.
                    mCONTROL.setControl(6, true); //Activar acciones de analizar
                    
                    //----    Fijo la lista en el objeto experimento    ----\\
                    expeRimento.setLista(listExper);
                    expeRimento.setPath(jPathAnalisis);
                    jExper_Sup.setModel(new SpinnerNumberModel(1, 1, listExper.length, 1));
                    jExper_Inf.setValue(new Integer(2));
                    jExper_Sup.setValue(new Integer(listExper.length));
                    //  ----------------------------------------------------- \\
                    
                    //Fijo la lista en la ventana emergente.
                    jList1.setModel(new javax.swing.AbstractListModel() {
                        public int getSize() {
                            return listExper.length;
                        }
                        public Object getElementAt(int i) {
                            return listExper[i];
                        }
                    });
                    jScrollPane2.setViewportView(jList1);
                    
                }else
                    if(listExper.length == 0){
                        jPathDirecAnalisis = jPathAnalisis;
                        jDirectorio_2.setText(jPathDirecAnalisis);
                        jAbrirTemp2(new File(jPathDirecAnalisis));
                    
                    }else{ //Si carga otro experimento, VACIO, vuelve a bloquear
                        mCONTROL.setControl(1, false);
                }   
        }
    }
// ========================================================================== \\    
    
    /**
     * Metodo usado para abrir una carpeta que contenga la lista de imagenes
     * a trabajar. Puede ser para simplemente ver dicha secuencia de imagenes
     * (cuando queremos ver la progresiòn temporal de un animal), o un set de 
     * un experimento completo (para separar cada animal del grupo).
     * 
     * @param fTemp Objeto "File" que contiene la direcciòn de las imàgenes.
     */
    private void jAbrirTemp(File fTemp){
        jPathImage = fTemp.getPath();
        jPathImagenes.setText(jPathImage);
        if(direc != null){
            direc = null;
            LimpiadorMemoria.gc();
        }
        direc = fTemp.list(new MyFilter(".tif"));
        java.util.Arrays.sort(direc);  //Ordena la lista
        
        if(direc.length != 0){
            mCONTROL.setControl(0, true);
            INDICE = 0;
            
            jProgreso.setMinimum(0);
            jProgreso.setMaximum(direc.length - 2);
            jTexIndice.setText("00");
            jProgreso.setValue(INDICE);
            jTextField5.setText(Integer.toString(direc.length));
            jTexFile.setText(direc[0].substring(0, direc[INDICE].length() - 4));
            hebraBuscar.borrarListas();
            
            jImgPr.setIcon(new ImageIcon((Image) leerIm(jPathImage, direc[0])
                    .getAsBufferedImage()));
            
        }else
            JOptionPane.showMessageDialog(null ,"DIRECTORIO VACIO");
    }
    /**
     * Metodo usado para abrir una carpeta que contenga la lista de imagenes
     * a ANALIZAR. Usada en la segunda pestaña de esta UI, para cargar la serìe
     * de imagenes una carpeta, de un animal en especìfico. Ademàs, llamà a otros
     * mètodos que preparan el anàlsis del mismo.
     * 
     * @param fTemp Objeto "File" que contiene la direcciòn de las imàgenes.
     */
    private void jAbrirTemp2(File ff){
        direc_2 = ff.list(new MyFilter(".tif"));
        java.util.Arrays.sort(direc_2);
        
        if(direc_2.length != 0){
            mCONTROL.setControl(1, true);
            
            INDICE_2 = 0;
            jImg_view.setText(direc_2[0]);
            if(horaRefInit == null){
                horaRefInit = getTime(direc_2[0]);
                jSp_Fecha.setValue(horaRefInit);
            }    
            
            jOb_Analisis.setData(ff.getPath(), direc_2);
            jOb_Analisis.setImagen(leerIm(ff.getPath(), direc_2[0]));
            jOb_Analisis.setTituloSegundo(ff.getName());
            
            mCONTROL.setControl(2, true);
            mCONTROL.setControl(7, true);
            jStop_AnalisActionPerformed(null);
            jOb_Analisis.cargarData();//Probando objeto cagar
            
//            jTipoData.setSelectedIndex(0);
            jDirectorio_2.addFocusListener(new java.awt.event.FocusAdapter(){});
            jOb_Analisis.botonSET("---");
            
       }else
            JOptionPane.showMessageDialog(null ,"DIRECTORIO VACIO");
    }
    private RenderedOp imCloseInterLine(BufferedImage imd){
        KernelJAI kerLin  = new KernelJAI(2, 2, 0, 0, kLine);
        ParameterBlock pb = new ParameterBlock();
        pb.addSource(imd);
        pb.add(kerLin);
        PlanarImage src = JAI.create("Dilate", pb);
        pb.removeParameters();
        pb.removeSources();
        pb.addSource(src);
        pb.add(kerLin);
        return(JAI.create("Erode", pb));
    }
    private void mensaje(Object _mensaje){
        System.out.println(_mensaje);
    }
    public void fijarData(int ind, String _text){
        switch(ind){
            case 0:
                break;
            case 1:
                jDirectorio_2.setText(_text);
                break;
            case 2:
                break;
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /*
         * Set the Nimbus look and feel
         */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /*
         * If Nimbus (introduced in Java SE 6) is not available, stay with the
         * default look and feel. For details see
         * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(DMMPRINCIPAL.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(DMMPRINCIPAL.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(DMMPRINCIPAL.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(DMMPRINCIPAL.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
        //</editor-fold>

        /*
         * Create and display the form
         */
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new DMMPRINCIPAL().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jAbrirImag;
    private javax.swing.JMenu jActiv;
    private javax.swing.JRadioButton jActivarArea;
    private javax.swing.JRadioButton jActivarCurva;
    private javax.swing.JRadioButtonMenuItem jAnalisis;
    private javax.swing.JButton jB_AbrirAnalisis;
    private javax.swing.JButton jB_AbrirGraficos;
    private javax.swing.JButton jB_ResetCurvas;
    private javax.swing.JButton jB_SET;
    private javax.swing.JButton jB_Separacion;
    private javax.swing.JButton jB_StopSeparacion;
    private javax.swing.JButton jB_VerCurvas;
    private javax.swing.JButton jBut_SaveData;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton9;
    private javax.swing.JButton jCONTROL;
    private javax.swing.JComboBox jC_Color;
    private javax.swing.JCheckBox jCheckBox2;
    private javax.swing.JCheckBox jCheck_BATCH;
    private javax.swing.JComboBox jComb_Hora;
    private javax.swing.JComboBox jComb_Min;
    private javax.swing.JComboBox jComboBox1;
    private javax.swing.JComboBox jComboBox3;
    private javax.swing.JMenu jComp;
    private javax.swing.JRadioButton jControTiempo;
    private javax.swing.JComboBox jControl_Analisis;
    private javax.swing.JLabel jDatos;
    private javax.swing.JTextField jDirectorio_2;
    private javax.swing.JSpinner jExper_Inf;
    private javax.swing.JSpinner jExper_Sup;
    private javax.swing.JComboBox jGenotype;
    private javax.swing.JComboBox jImag_Lista;
    private javax.swing.JLabel jImgPr;
    private javax.swing.JButton jImg_der;
    private javax.swing.JButton jImg_izq;
    private javax.swing.JTextField jImg_view;
    private javax.swing.JLabel jIndice;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JList jList1;
    private javax.swing.JComboBox jList_names;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem9;
    private javax.swing.JLabel jName_file;
    private javax.swing.JPanel jP_Genotipol_Hora;
    private javax.swing.JPanel jP_Test;
    private javax.swing.JPanel jP_Umbral;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel jPanelAnalisis;
    private javax.swing.JPanel jPanelGraficos;
    private javax.swing.JPanel jPanelImagenes;
    private javax.swing.JTextField jPathImagenes;
    private javax.swing.JTextField jPath_Graficos;
    private javax.swing.JPanel jPlot_panel;
    private javax.swing.JProgressBar jProgreso;
    private javax.swing.JProgressBar jProgreso_2;
    private javax.swing.JRadioButtonMenuItem jRBordes;
    private javax.swing.JRadioButtonMenuItem jRDesvia;
    private javax.swing.JRadioButtonMenuItem jR_Shape;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem1;
    private javax.swing.JSpinner jRango;
    private javax.swing.JSpinner jS_CicloLuz;
    private javax.swing.JSpinner jS_hInicio;
    private javax.swing.JSpinner jSalto;
    private javax.swing.JScrollBar jScrollBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTextField jSecuDestino;
    private javax.swing.JSpinner jSp_Datpuntos;
    private javax.swing.JSpinner jSp_Fecha;
    private javax.swing.JSpinner jSp_UmbralGraf;
    private javax.swing.JSpinner jSpi_Tolerancia;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JSplitPane jSplitPane2;
    private javax.swing.JSplitPane jSplitPane3;
    private javax.swing.JButton jStop_Analis;
    private javax.swing.JComboBox jTData;
    private javax.swing.JComboBox jTFiltro;
    private javax.swing.JTextField jT_IndeInf;
    private javax.swing.JTextField jT_IndeSup;
    private javax.swing.JTable jTabData;
    private javax.swing.JTabbedPane jTab_Analisis;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane3;
    private javax.swing.JTabbedPane jTabbedPane5;
    private javax.swing.JTabbedPane jTabbedPane7;
    private javax.swing.JTable jTableCambiar;
    private javax.swing.JTable jTableGraficos;
    private javax.swing.JTextField jTexFile;
    private javax.swing.JTextField jTexIndice;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTiempoMin;
    private javax.swing.JComboBox jTipoData;
    private javax.swing.JTextField jTxIndice_2;
    private javax.swing.JTextField jTxTotal;
    private javax.swing.JSpinner jVelocidadPlay;
    private javax.swing.JComboBox jVerAnalis;
    private javax.swing.JMenuItem j_Abrir;
    private javax.swing.JButton j_Adelante;
    private javax.swing.JButton j_Atras;
    // End of variables declaration//GEN-END:variables

}




//** FUNCIONES QUE NO S0N USADAS, PERO TIENEN DETALLES QUE PODRIAN SER UTILES **/

//    private BufferedImage cComImage(BufferedImage img) {
//        BufferedImage result = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_ARGB);
//        Graphics2D g2 = result.createGraphics();
//        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC, (float)jSlider1.getValue()/100));
//        g2.drawRenderedImage(img, null);
//        g2.dispose();
//        return(result);
//    }
//    private BufferedImage scaleImg(BufferedImage img){
//        BufferedImage imd = new BufferedImage(256, 192, BufferedImage.TYPE_INT_ARGB);
//        Graphics2D g2 = imd.createGraphics();
//        g2.drawImage(img, AffineTransform.getScaleInstance(0.4, 0.4), null);
//        g2.dispose();
//        return(imd);
//    }
//    private void dibTrans(int _indx){
//        if(direc2 != null){
//            imTrans.setIcon(new ImageIcon((Image)cComImage(scaleImg(
//                    leerIm(jSecuDestino.getText(), direc2[direc2.length- _indx - 2])
//                    .getAsBufferedImage()))));
//        }
//    }
        
//        TableCellRenderer renderer = new TableCellRenderer() {
//            JLabel label = new JLabel();
//            public Component getTableCellRendererComponent(JTable table,
//                    Object value, boolean isSelected, boolean hasFocus,
//                    int row, int column) {
//                label.setOpaque(true);
//                label.setText("" + value);
//                Color alternate = Color.green;
//                Boolean b  = (Boolean)jTableGraficos.getValueAt(row, 2);
//                if (b) {
//                    label.setBackground(alternate);
//                }else {
//                    label.setBackground(Color.WHITE);
//                }
//                return label;
//            }
//        };
//        jTableCambiar.setDefaultRenderer(Object.class, renderer);
//        inputMap.put(ENTERR, jSpinner1.getActionMap());
//        actionMap.put(jSpinner1.getActionMap(), new AbstractAction() {
//            @Override
//            public void actionPerformed(ActionEvent ae) {
//                mensaje("Estoy aca");
//            }
//        });
//      JOptionPane.showMessageDialog(null, "DIRECTORIO NO VALIDO");