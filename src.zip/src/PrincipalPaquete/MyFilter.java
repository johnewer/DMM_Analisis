/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package PrincipalPaquete;

import java.io.File;
import java.io.FilenameFilter;
import java.io.Serializable;

/**
 *
 * @author Felipe
 */
public class MyFilter implements FilenameFilter, Serializable{

    String extension;
    MyFilter(String extension){
        this.extension = extension;
    }

    public boolean accept(File dir, String name) {
        if(extension == null){
            return dir.isDirectory();
        }else
        if(extension.compareToIgnoreCase("--") == 0){
            return name.contains("Set_Img");
        }else
        if(extension.compareToIgnoreCase("-f") == 0){
            return name.contains("fond");
        }else
        if(extension.compareToIgnoreCase("-P") == 0){
            return (dir.isDirectory() && name.length() <= 8 &&
                    (name.startsWith("Img_") || name.startsWith("Imag_")));
        }else{
            return name.endsWith(extension);
        }
    }    
}
