/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PrincipalPaquete;

import com.sun.media.jai.codec.FileSeekableStream;
import jObjetoMosca.jObjetoAnalisis;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.geom.Rectangle2D;
import java.awt.image.*;
import java.awt.image.renderable.ParameterBlock;
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.media.jai.JAI;
import javax.media.jai.KernelJAI;
import javax.media.jai.PlanarImage;
import javax.media.jai.RenderedOp;
import javax.swing.*;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.jfree.data.time.Minute;


/**
 *  Esta clase esta encargada de manejar todos los eventos de definicion de 
 * sectores de busqueda y parametros necesarios para ello. Una vez definidos
 * todos estos parametros, se ejecuta la secuencia de analisis, en la cual se
 * busca, analiza y cuantifican los sectores de desados. 
 * 
 * 
 * @author Felipe
 */
public class jAnalisis extends JLabel implements Runnable, Serializable{
    
    /** 
     * mControles: Es un objeto que guarda una serie de variables booleanas de 
     *      control, para manejar la ejecuciòn de diferentes eventos, y està 
     *      conectada entre todos los objetos principales de este sistema. 
     *      Es el mismo en cada uno de los objetos principales.
     * 
     */
    public jCONTROLES mCONTROL = null;{
    /* index  0 = Control de separacion de imagenes
     * index  1 = Guardar data Analisis !.
     * index  2 = Control de Inicio de analisis de datos.
     * index  3 = Control de gràficas a mostrar.
     * index  4 = 
     * index  5 = 
     * index  6 = Control de eventos generales de ANALIZAR !.
     * index  7 = Control guardar data.
     * index 10 = Control ejecucion hebra de separación.
     * index 11 =
     * index 12 = 
     * index 13 =
     * index 14 = 
    */
}
    
//  Variables Booleanas para control de distintos eventos.   \\
    public boolean areaDatos        = false;
    public boolean areaBusqueda     = false;
    public boolean CONTROL          = false; //Control Hebra Principal de esta clase
    public boolean jSleep           = false;
    public boolean CONTROL_IMAGEN   = false;
    public boolean Control_RoiPoli  = true;
    public boolean actAnalisis      = true;
    public boolean cambioLista      = false;
// ---------------------------------------------------------------- \\
    
//  Set de codigos que serán enviados a MATLAB. 
    public static int codError  = 1000;
    public static int codActiv  = 1001;
    public static int codAnalis = 1011;
    //---- USADOS  ----//
    public static int codFondo  = 1012;
    public static int codReset  = 1013; //Codigo para llevar variables a ind = 0
    
    public static int codOtros  = 1331;
// ---------------------------------------------------------------- \\  
    public Date horaRefInit = null;  // Hora Referencia APAGADO.
    
    /** 
     * 
     * Indice de la imagen actual a trabajar.
     */
    public int INDICE   =  0;
    
    /** 
     * Rango que se usa para buscar en la imagen.
     */
    public int SaltoY   = 10;
    
    /**
     * Rango para rebusqueda de la imagen.
     */
    public int rBusq    = 10;
    
    /**
     * Control de los tres tipos de analisis a realizar: Busqueda, busqueda 
     * y anàlisis, o busqueda en experimento completo.
     */
    public int tipoAnalisis  =  0;
    
    /**
     * Indice que indica la cantidad de puntos en la zona de anàlisis (Usado para
     * entregarselo a Matlab).
     */
    public int listIndice    = -1;

    /**
     * 
     */
    public Point eA_1 = new Point(40, 50);
    
    /**
     * 
     */
    public Point eA_2 = new Point(600, 430);
    
    /**
     * 
     */
    public int mWidth  = Math.abs(eA_2.x - eA_1.x);
    
    /**
     * 
     */
    public int mHeight = Math.abs(eA_2.y - eA_1.y);
    
    /**
     * 
     */
    public int Area    = mWidth * mHeight;
    
    /**
     * 
     */
    public String path_Date = null;
    public String TITULE    = "";
    public String titulo2   = "";
    
    /**
     * 
     */
    public String direc[]    = null;
    
    /**
     * 
     */
    public Thread miHebra    = null;

    /**
     * Aca se almacena la Imagen Guia para buscar sobre las otras de la serie.
     */ 
    public BufferedImage miImg  = null;
    
    /**
     * 
     */
    public BufferedImage imt = null;
    
    /**
     * 
     */
    public Raster imGuiaR = null;
    
    /**
     * 
     */
    public Color mColor = new Color(0, 0, 255);
    
    /**
     * MATRIX: Es un vector que se usa para pasar una imagen en color, a escala
     * de grises. Para realizar esto, se toma una proporciòn de cada una de las
     * componentes RGB y se suman. En este caso, la imagen es en escala de grises,
     * y por ende, con tomar una de las 3 capas es suficiente. En imagnes a color, 
     * se hace necesario definir (Puede ser lo comentado) que aporte harà cada
     * componente a*R + b*G + c*B.
     * 
     *      MATRIX = {{ a, b, c }}
     * 
     */
    //    double[][] MATRIX = {{ 0.3D, 0.59D, 0.11D, 0D }};
    double[][] MATRIX = {{ 0.0D, 0.0D, 1.0D, 0D }};
    
    public JFrame       jVentana  = null;
    public JLabel       LMask     = new JLabel();
    public JProgressBar mi_bar    = null;
    public JTextField   indexText = null;
    public JTextField   totalText = null;
    public JTextField   dirPath   = null;
    
    //Data para el Genotipo y la hora de coleccion.
    public JComboBox genoTipo = null;
    public JComboBox horaHora = null;
    public JComboBox horaMinu = null;
    
    //Boton de control. Puntero al boton
    public miBoton mBoton    = null;

    //Boton control roi analisis
    public JButton mBotonSet = null;
    
    /**
     * Lista de puntos que gurda los puntos para construir la zona de anàlisis
     * dentro del animal.
     */
    List listPuntos = new LinkedList();
    
    /**
     * Al realizar el analisis de cada imagen, se crea un objeto que guarla las
     * caracteristicas de cada imagen, en el objeto obb y se almacena cada objeto
     * esta lista.
     */
    List listObjetosAnalisis = new LinkedList();
    
    public jExperimento miExperimento = null;
    
    /**
     * Objeto que almacena datos: Es el encargado de guardar todo lo referente 
     * a un animal en particular.
     */
    public jObjetoAnalisis obb = new jObjetoAnalisis();

    /**  
     * Contenedor de gràficos donde se trabaja, la muestra y analizan las curvas
     * de cada animal.
     */
    public jPlot_times miGrafico = new jPlot_times(mCONTROL);
    
    
//-----------------------------------------------------------------------------------------------------------------\\    
//-----------------------------------------------------------------------------------------------------------------\\
    
    /**
     * Contructor: Se pasa el objeto mCONTROL para conectarlo con el mismo objeto
     * en esta clase. Además se pasa el botòn principal que controla el los 
     * eventos en general.
     * 
     * @param _mCONTROL: Objeto que contiene gran variedad de variables de control.
     * @param _mBoton: Botòn principal.
     */
    public jAnalisis(jCONTROLES _mCONTROL, miBoton _mBoton){
       /** 
        * initComponents(): Este objeto tiene variedad de otros objetos gràficos, 
        * y de otro tipo que necesitan caracteristicas iniciales especificas. 
        * Esto es asì, para mejorar la ejecuciòn de variedad de procesos de bùsqueda, 
        * anàlisis y cuantificaciòn.
        * En este mètodo se cargan dichas caracterìsticas al momento de iniciar 
        * el programa completo.
        */
        initComponents();
        mCONTROL  =  _mCONTROL; // Variables de control
        mBoton    =  _mBoton;   // Botòn principal.
    }
    
    @Override
    /** 
     * PaintComponent: Metodo sobreescrito (ya existe), para marcar las zonas de 
     * deteccion y analisis de los distintas zonas de control y puesta en marcha.
     */
    public  void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics2D g2d=(Graphics2D) g;
        
        //Marca la zona de analsis. Zona azul.
        if(areaDatos){
            g2d.setColor(mColor);
            for(int i=0; i<listPuntos.size() - 1; i++){
                Point p1 = (Point)listPuntos.get(i);
                Point p2 = (Point)listPuntos.get(i + 1);
                g2d.drawLine(p1.x, p1.y, p2.x, p2.y);
                
                g2d.drawRect(p1.x - 1, p1.y - 1, 3, 3);
                g2d.drawRect(p2.x - 1, p2.y - 1, 3, 3);
            }
            if(!Control_RoiPoli){
                Point p1 = (Point)listPuntos.get(0);
                Point p2 = (Point)listPuntos.get(listPuntos.size()-1);
                g2d.drawLine(p1.x, p1.y, p2.x, p2.y);
            }
            if(!areaBusqueda){
                g2d.setColor(Color.GREEN);
                int with  = (int)Math.abs(eA_2.getX() - eA_1.getX());
                int higth = (int)Math.abs(eA_1.getY() - eA_2.getY());
                g2d.drawRect((int)eA_1.getX(), (int)eA_1.getY(), with, higth);
            }
        }
        
        //Marca la zona de busqueda. Cuadro rojo.
        if(areaBusqueda){
            g2d.setColor(Color.RED);
            int with  = (int)Math.abs(eA_2.getX() - eA_1.getX());
            int higth = (int)Math.abs(eA_1.getY() - eA_2.getY());
            g2d.drawRect((int)eA_1.getX(), (int)eA_1.getY(), with, higth);
        }
    }
    
    /**
     * Mètodo encargado de manejar el evento Click sobre la imagen. 
     * @param evt: Evento de mouse, entrada.
     * @return
     */
    public void fMouseClicked(java.awt.event.MouseEvent evt){
        //Control de un click del mouse.
        /* Al generar 2 click, indica que está cerrando la zona de analisis (azul),
         * y con ello, guarda el archivo de data.
        */
        if(evt.getClickCount() == 2 && areaDatos && !areaBusqueda){
            if(Control_RoiPoli){
                Control_RoiPoli = false;
                botonSET("SET");
            }
        }
        this.repaint();
    }
    
    /**
     * Metodo encargado de manejar el evento "Presionar Mouse" sobre la imagen. 
     * @param evt: Evento de mouse, entrada.
     * @return
     */    
    public void fMousePressed(java.awt.event.MouseEvent evt) {
        if(!mCONTROL.getControl(6))return; //Condiciones NO adecuadas, no entra.
        
        if(areaDatos ^ areaBusqueda){ //Activa boton para guardar 
            botonSET("SET");
        }
        
        if(areaDatos && !areaBusqueda && Control_RoiPoli){
            if(evt.getPoint().x > eA_1.x && evt.getPoint().x < eA_2.x 
                    && evt.getPoint().y > eA_1.y && evt.getPoint().y < eA_2.y){
                listPuntos.add(evt.getPoint());
                listIndice = listPuntos.size() - 1;
            }}
        
        if(areaDatos && !areaBusqueda && !Control_RoiPoli){
            for(int i = 0; i < listPuntos.size(); i++){
                Point pp = (Point)listPuntos.get(i);
                double dd = pp.distance(evt.getPoint());
                if(dd < 10){
                    listIndice = i;
                }}}
        
        /**
         * Asignan el punto en la zona cero de busqueda (cuadro rojo). Ambos 
         * superior e inferior, eA_1 y eA_2, quedan donde mismo, dado que se
         * inicia el marcado de la zona.
         * 
         */
        if(areaBusqueda && !areaDatos){
            eA_1 = eA_2 = evt.getPoint();
        }
        this.repaint();/*Repintar la zona de imagen*/
    }
    
    /**
     * Metodo encargado de manejar el evento "Liberar el mouse" sobre la imagen.
     * Para define el momento la zona total de busqueda, y crear el area de la mimsa.
     * @param evt: Evento de mouse, entrada.
     * @return
     */
    public void fMouseReleased(java.awt.event.MouseEvent evt){
        //Zona de bùsqueda y no la de anàlisis.
        if(areaBusqueda && !areaDatos){
            mWidth  = Math.abs(eA_2.x - eA_1.x);
            mHeight = Math.abs(eA_2.y - eA_1.y);
            Area    = mWidth * mHeight;
            
            LMask.setBounds(Math.round((640 - mWidth)/2),
                    Math.round((480 - mHeight) / 2), mWidth, mHeight);
        }else
            //Zona de anàlisis y no la de bùsqueda.
            if(areaDatos && !areaBusqueda && !Control_RoiPoli)
                miMetodo(codFondo);//Llamo a matlab para rehacer el fondo.
        
        // Al fijar la zona, se toma el cuadro de la imagen que será usada como 
        // referencias de busqueda en este set de imagenes.
        if(CONTROL_IMAGEN && Area != 0 )
            imGuiaR = miImg.getData(new Rectangle(eA_1.x, eA_1.y, mWidth, mHeight));
    }
    
    /**
     * Metodo encargado de manejar el evento "Arrastrar el Mouse" sobre la imagen.
     * Definido para el caso cuando el mouse presionado sobre la imagen, se mueve.
     * Ocupado principalmente para definir la zona de busqueda. Marca cuadro en rojo.
     * @param evt: Evento de mouse, entrada.
     */
    public void fMouseDragged(java.awt.event.MouseEvent evt) {
        if(!mCONTROL.getControl(6)) return;
        
        //punto sobre la imagen generado.
        Point eTemp = evt.getPoint();
        
        // Si el punto sale de la zona de la imagen, se fija en los bordes de la misma.
        if(eTemp.x > 640) eTemp.setLocation(640, eTemp.y);
        if(eTemp.y > 480) eTemp.setLocation(eTemp.x, 480);
        
        /** 
         * Si la zona de analisis esta activada, se carga el punto en la lista
         * de puntos de analisis (puntos en azul).
         */
        if(areaDatos && !areaBusqueda && !Control_RoiPoli){
            if(evt.getPoint().x > eA_1.x && evt.getPoint().x < eA_2.x
                    && evt.getPoint().y > eA_1.y && evt.getPoint().y < eA_2.y)
                listPuntos.set(listIndice, eTemp); //Guarda el punto en la lista.
        }
        /** 
         * Si la zona de bùsqueda està activa, se asigna al punto inferior.
         */
        if(areaBusqueda && !areaDatos){
            eA_2 = eTemp;
        }
        this.repaint();/* Repintar todo el contenedor */
    }
    
    /**
     * Metodo encargado que permite sacar la imagen guia de trabajo. Podría
     * ser necesitada para ser usada por otro objeto.
     * @return imt: Imagen guia de trabajo.
     */
    public BufferedImage getImagen(){
        return(imt);
    }
    
    /**
     * Metodo encargado de retornar el punto superior de la zona de busqueda.
     * @return eA_1: Punto superior.
     */
    public Point getP_Sup(){
        return(eA_1);
    }
    
    /**
     * Metodo encargado de retornar el punto inferior de la zona de busqueda.
     * @return eA_2: Punto inferior.
     */
    public Point getP_Inf(){
        return(eA_2);
    }
    
    /**
     * Metodo encargado de retornar la lista de puntos que formaran la 
     * zona de analisis. Usado por Matlab principalmente. 
     * @return listPuntos: Lista de puntos.
     */    
    public List getListaPuntos(){
        return(listPuntos);
    }
    
    /**
     * Carga los elementos graficos que este objeto ocupara para mostrar datos
     * al usuario (En la UI).
     * @param _contenedor 
     * @param _compGenoHora 
     */
    public void setContenedor(Component[] _contenedor, Component[] _compGenoHora){
        dirPath   = (JTextField)_contenedor[0];
        indexText = (JTextField)_contenedor[10];
        totalText = (JTextField)_contenedor[7];        
        mi_bar    = (JProgressBar)_contenedor[5];
        
        //  Este grupo es para la informacion del Genotipo y la Hora de 
        //coleccion, de cada animal al cargar en forma automatica.
        horaHora  = (JComboBox)_compGenoHora[2];
        horaMinu  = (JComboBox)_compGenoHora[3];
        genoTipo  = (JComboBox)_compGenoHora[4];
    }
    public void setFrameForma(JFrame _frame){
        jVentana = _frame;
    }
    public void setTituloGeneral(String _titulo, String _titulo2){
        jVentana.setTitle(_titulo + "   " + _titulo2);
    }
    public void setTitulo(String _title){
        TITULE = _title;
        setTituloGeneral(TITULE, titulo2);
    }
    public void setTituloSegundo(String _title){
        titulo2 = _title;
        setTituloGeneral(TITULE, titulo2);
    }
    
    /**
     * Activar area de busqueda.
     * @param _areaBusqueda.
     */    
    public void setAreaBusqueda(boolean _areaBusqueda){
        areaDatos = _areaBusqueda;
        this.repaint();
    }
    
    /**
     * Activar area de analisis.
     * @param _actAnalis.
     */    
    public void setActAnalisis(boolean _actAnalis){
        actAnalisis = _actAnalis;
    }
    
    /**
     * Elecciòn para mostrar zonas de anàlisis o de datos.
     * @param _valor: Indicador numèrico de que zona quiero ver.
     */
    public void setAreaData(int _valor){
        switch (_valor){
            case 0://Ambas.
                areaBusqueda    = true;
                areaDatos       = true;
                break;
            case 1://Zona de bùsqueda.
                areaBusqueda    = true;
                areaDatos       = false;
                break;
            case 2://Zona de anàlisis.
                areaDatos       = true;
                areaBusqueda    = false;
                break;
        }
        this.repaint();//Repintar el cuadro completo.
    } 
    
    /**
     * Set de parametros que seran entregados desde la interface gràfica. Es 
     * la lista y el path del set de imàgenes cargados para buscar y analizar en
     * este momento. NO todos, sino el actual.
     * 
     * @param _path_Date Path de la lista de imagenes.
     * @param _direc[] Arreglo con la lista de nombre de imagenes.
     */
    public void setData(String _path_Date, String _direc[]){
        path_Date = _path_Date;
        direc = _direc;
        
        dirPath.setText(path_Date);
        indexText.setText("00");
        totalText.setText(String.valueOf(direc.length));
        
        mi_bar.setMinimum(0);
        mi_bar.setMaximum(direc.length-2);
    }
    
    /**
     * Metodo encargado de cargar la direccion del archivo que contiene gran 
     * parte de los parametros almacenados para cada animal: Zona de busqueda,
     * zona de analisis, vectores con curvas normales y filtradas, y otros.
     * 
     * @param _dir path del archivo contenedor de datos.
     * @return: Si ha cargado bien los datos
     */
    public boolean setDatosCargados(String _dir){
        listPuntos.clear(); //Limpia la lista que almacena los puntos de la zona de anàlisis     
        try {
            BufferedReader in = new BufferedReader(new FileReader(_dir));
            String str;
            while ((str = in.readLine()) != null) {
                int d1 = str.indexOf(" ");
                listPuntos.add(new Point(Integer.parseInt(str.substring(0, d1)),
                        Integer.parseInt(str.substring(d1+1, str.length()))));
            }
            in.close();
        } catch (IOException e) {;}
        
        
        /**
         * OJO: La lista "listPuntos" contiene en la primera y segunda linea, datos
         * que NO corresponden a puntos pertenecientes a la zona de anàlisis y son
         * parametros para la zona de Bùsqueda, y son la ubicaciòn dentro del cuadro de
         * la imagen del punto superior "eA_1" y de el ancho y alto de la zona de busqueda,
         * con el cual se contruye el punto inferior "eA_2".
         */
        Point pp = (Point)listPuntos.get(2);
        if(pp.x == -1 && pp.y == -1){
            eA_1.setLocation((Point)listPuntos.get(0));
            pp = (Point)listPuntos.get(1);
            eA_2.setLocation(eA_1.x + pp.x, eA_1.y + pp.y);
            mWidth  = pp.x;
            mHeight = pp.y;
            
            /**Cargar en el objeto de parametros, para volver a guardar. Sino 
             * cambia, se carga el mismo dato que tenia almacenado.
             */
            obb.setPunto(eA_1.x, eA_1.y, mWidth, mHeight);
            imGuiaR    =  miImg.getData(new Rectangle(eA_1.x, eA_1.y, mWidth, mHeight));
            
            //Corto la lista desde el 3 punto.
            listPuntos =  listPuntos.subList(3, listPuntos.size());
            if(listPuntos.size() < 2)
                Control_RoiPoli = true;
            else
                Control_RoiPoli = false;
            
            this.repaint();
            return(true);
        }
        return(false);
    }
    
    /**
     * Se conecta con el objeto que controla el anàlisis de experimentos completos.
     * @param _experiment 
     */
    public void setObjExperimen(jExperimento _experiment){
        miExperimento = _experiment;
    }
    
    /**
     * Se ocultan las areas de busqueda y anàlisis. Se activa el control de la 
     * imagen.
     */
    public void setOcultar(){
        areaBusqueda    = false;
        areaDatos       = false;
        CONTROL_IMAGEN  = true;
        this.repaint();
    }
    
    /**
     * Mètodo para cambiar el color de la curva que marca la zona de busqueda.
     * @param _mColor: Color a marcar.
     */
    public void setColor(Color _mColor){
        mColor = _mColor;
        LMask.repaint();
    }
    
    /**
     * Mètodo encargado de cargar la imagen que es entregada desde un objeto
     * externo (Por lo general la UI), para cargarlo en el contenedor y 
     * mostrarlo a pantalla. 
     * 
     * @param img: imagen a cargar.
     */
    public void setImagen(RenderedOp img){
        LMask.setVisible(false);
        ParameterBlock pb = new ParameterBlock();
        pb.addSource(img);
        pb.add(MATRIX);
        miImg = img.getAsBufferedImage();
        
        this.setIcon(new ImageIcon((Image)miImg));
        this.repaint();
    }
    
    public void setImagen(Image _imd, int _dd){
        this.setIcon(new ImageIcon((Image)_imd));
        this.repaint();
    }
    
    /**
     * Este medoto es usado desde Matlab. Para mostrar la imagen mas los datos
     * morfologicos encontrados en matlab, pudiendo ser bordes o desviaciòn 
     * estandar local.
     * 
     * @param _imd: Imagen desde matlab.
     */
    public void setImagInMask(Image _imd){
        LMask.setIcon(new ImageIcon(_imd));
    }
    
    /**
     * Este medoto es usado desde Matlab. Para mostrar la imagen mas los datos
     * morfologicos encontrados en matlab, pudiendo ser bordes o desviacion 
     * estandar local. 
     * POLIMORFISMO de la funcion.
     * @param _imd
     * @param _index 
     */
    public void setImagInMask(Image _imd, int _index){
        LMask.setIcon(new ImageIcon(_imd));
    }
    
    /** 
     * Carga el indicador del tipo de anàlisis a realizar. Puede ser de sòlo buscar 
     * la mejor zona de la imagen, en base al cuadro inicial de referencia. Puede ser
     * buscar y ANALIZAR la imagen, llamando a Matlab. Tambièn en el caso de un
     * anàlisis de experimento completo, se usa como caso especial.
     * 
     * @param _tipoAnalisis 
     */
    public void setTipoAnalisis(int _tipoAnalisis){
        tipoAnalisis = _tipoAnalisis;
        this.repaint();
    }

    public void setSleep(){
        jSleep = true;
    }
    
    public void setListaPuntos(List _listPuntos){
        listPuntos = _listPuntos;
    }

    /**
     * Correcciòn de problemas en la imagen por interlineado. Ocurre cuando la 
     * imagen se digitaliza desde un medio anàlogo. En el estandar NTFS de imagenes
     * por video analògico suele ocurrir. En este caso es necesario.
     * @param imd: Imagen de entrada a corregir
     * @return Imagen corregida.
     */
    public BufferedImage imCloseInterLine(BufferedImage imd){
        float[] kLine = {1,1,1,1};
        KernelJAI kerLin  = new KernelJAI(2, 2, 0, 0, kLine);
        ParameterBlock pb = new ParameterBlock();
        pb.addSource(imd);
        pb.add(kerLin);
        PlanarImage src = JAI.create("Dilate", pb);
        pb.removeParameters();
        pb.removeSources();
        pb.addSource(src);
        pb.add(kerLin);
        return(JAI.create("Erode", pb).getAsBufferedImage());
    } 
      
    /**
     * PRINCIPALES CARACTERISTICAS DEL SISTEMA DE ANALISIS IMAGENES
     * Mètodo que da las caracterìsticas iniciales a mucho objetos internos a 
     * este objeto de anàlisis. Se carga sobretodo los objetos gràficos que se 
     * usaràn para desplegar informaciòn al usuario. Ademàs, se especifican las
     * funciones que "escuchan" (listeners) los eventos ocurridos sobre dichos
     * objetos gràficos.
     */
    public void initComponents() {
        super.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        super.setBounds(40, 40, 640, 480);
        this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagneess/earth-640x480.jpg")));
        this.setVisible(true);

        addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt){
                fMouseClicked(evt);
            }
            @Override
            public void mousePressed(java.awt.event.MouseEvent evt) {
                fMousePressed(evt);
            }
            @Override
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                fMouseReleased(evt);
            }
        });
        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            @Override
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                fMouseDragged(evt);
            }
        });

        //Evento que captura la interacción con Matlab. Usado como pivote.
        addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent evt) {
            }
        });
        addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyPressed(java.awt.event.KeyEvent evt) {}});

        LMask.setBounds(Math.round((640 - mWidth)/2),
                Math.round((480 - mHeight) / 2), mWidth, mHeight);
        LMask.setOpaque(false);
        LMask.setVisible(false);
        this.add(LMask);
    }
    
    /**
     * Mètodo que inicia una nueva hebra, un nuevo anàlisis desde cero.
     *      Mètodo nativo de la clase runnable (hebras de ejecuciòn).
     */
    public void start(){
        CONTROL = true;
        INDICE  = 0;
        
        miHebra = new Thread(this);
        miHebra.start();
    }
    
    /**
     * Mètodo para mata la hebra. OJO, no es como la detenciòn de un momento,
     * la hebra termina, estando en cualquier condiciòn.
     */
    public void stop(){
        CONTROL = false;
        despertar();
    }
    
    /**
     * Mètodo que cierra la hebra. 
     * <p> Se llama para asegurarse de terminar con la hebra en ejecuciòn.
     */
    public void ClosingObject(){
        CONTROL = false;
        despertar();
    }
    
// -------------------------------------------------------------------------- \\    
    /**
     * METODO PRINCIPAL DE LA HEBRA. Este se ejecuta al momento de hacer 
     * ejecutar el la funciòn "Start()", y dar inicio tanto a la busqueda de 
     * la zona central del animal, como del envio de peticiones a MATLAB
     * para realizar la cuantificación. Es parte del set de metodos de la clase
     * runnable.
     */
    @Override
    public void run() {
            int limY = 480 - mHeight;
            double coefCorr ;
            double coefTem  = -1;
            PlanarImage imd;
            ParameterBlock pb  = new ParameterBlock();
        
            /*Reset de los datos, para empezar con el ploteo*/
            miGrafico.resetData();
        
            /* Define el tamaña de la zona, dado que cambia con cada animal*/
            LMask.setBounds(Math.round((640 - mWidth)/2),
                    Math.round((480 - mHeight) / 2), mWidth, mHeight);
            LMask.setVisible(true);
        

            LMask.setIcon(new ImageIcon()); /*Carga la imagen*/
            this.setIcon(new ImageIcon());  
            pb.add(MATRIX);/* Carga la matriz que convierte a escala de grises.*/
        
            /*  INICIO DEL CUERPO DE LA HEBRA...  */
            while(CONTROL && INDICE < (direc.length)){
                /* Cargo la imagen y luego la creo para mostrarla */
                pb.addSource(leerIm(path_Date , direc[INDICE]));
                imd = JAI.create("BandCombine", pb, null);
                
                /* Detecta la mejor posicion en coordenada Y. Buequeda GRUESA.*/
                for(int d = 0; d < limY; d+=10){
                    coefCorr = corr2(imGuiaR, imd.getData(
                            new Rectangle(eA_1.x, d, mWidth, mHeight)));
                    if(coefCorr > coefTem){
                        coefTem = coefCorr;
                        SaltoY = d;
                    }
                }
                /* Luego de encontrar una zona más próxima a la imagen guía, se 
                 * hace una nueva busqueda más precisa de la zona, para asegurar
                 * que es la mejor.*/
                coefTem = -1;
                for(int d = SaltoY - rBusq; d < SaltoY + rBusq; d++){
                    coefCorr = corr2(imGuiaR, imd.getData(
                            new Rectangle(eA_1.x, d, mWidth, mHeight)));
                    if(coefCorr > coefTem){
                        coefTem = coefCorr;
                        SaltoY = d;
                    }
                }
                /* Luego de tener detectada la mejor zona en el eje y, pasamos a 
                * trabajar sobre esa zona en el eje x. Esto mueve un pequeño rango
                * en x, ya que el fundamente es que en el eje y ya se ha encontrado
                * la mejor zona. Este es en base al principio de que la mosca, la
                * cabeza NO se mueve mucho del cuadro en el eje X. */
                coefTem = -1;
                int i1  = -1;
                int j1  = -1;
                for(int i = eA_1.x - 10; i < eA_1.x + 10; i++){
                    coefCorr = corr2(imGuiaR, imd.getData(
                            new Rectangle(i, SaltoY, mWidth, mHeight)));
                    if(coefCorr > coefTem){
                        coefTem = coefCorr;
                        i1 = Math.min(Math.max(0, i), (imd.getWidth() - mWidth - 1));
                        j1 = Math.min(Math.max(0, SaltoY), (imd.getHeight()- mHeight - 1));
                    }}
            
            /**
             * A esta altura, tenemos detectada la mejor posición de la imagen, en
             * base a la imagen guia marcada en base a la zona guardada en el archivo
             * "Serie_Datos.datt". Desde acà en adelante, puedo trabajar con el 
             * segmento de la imagen que mejor ubicado de la cabeza, sobreponer el roi
             * de analisis y obtener los datos donde quiero.
            */
                try{
                    ParameterBlock pd = new ParameterBlock();
                    pd.add(imCloseInterLine(imd.getAsBufferedImage().
                                   getSubimage(i1, j1, mWidth, mHeight)));
                    imt = JAI.create("awtImage", pd).getAsBufferedImage();
                    
                    if((INDICE % 10) == 0)
                        imGuiaR = imt.getData();
                
                    obb.setPath(path_Date + "/" + direc[INDICE]);
                    obb.setPunto(i1, j1, mWidth, mHeight);
                    
                    guardarPuntos(i1, j1, mWidth, mHeight);
                    
                    
                    switch(tipoAnalisis){
                        case 0:
                            LMask.setIcon(new ImageIcon((Image)imt));
                            mCONTROL.setControl(7, false);
                            break;
                        case 1://Detección de sectores, llamado interno de java.
                            LMask.setIcon(new ImageIcon((Image)imt));
                            mCONTROL.setControl(7, false);
                            
                            dataPython();       //Seccion donde inicia PYTHON
                            procesoPython();
                            break;
                        case 3://CUANDO ANALIZO EXPERIMENTO COMPLETO.
                            /*
                                OJO. El caso 3, está considerado para DESPETAR A 
                            LA HEBRA de experimento COMPLETO. NO ACTIVA NI NADA 
                            DE LA HEBRA DE ANALISIS.
                            */
                            LMask.setIcon(new ImageIcon((Image)imt));
                            mCONTROL.setControl(1, false);
                            
                            dataPython();       //Seccion donde inicia PYTHON
                            procesoPython();       
                            break;
                    }
                }catch(RasterFormatException ex){
                    /**
                     * En caso de haber algun error o problema, y caer la hebra
                     * en una mala detecciòn, salta a este controlador de excepciones
                     * he imprime el indice y los puntos donde està mal calculada 
                     * la zona de la imagen.
                     */
                    System.out.println(INDICE + " " + i1 + " " + j1);
                    i1 = -1;
                    j1 = -1;
                
                    /*Carga en este objeto la imagen mal detectada.*/
                    obb.setPath(path_Date + "/" + direc[INDICE]);
                    obb.setPunto(i1, j1, -1, -1);
                }
                /** 
                 * Añado a la lista de objetos que guardará las coordenadas de cada 
                 * imagen, de cada animal. 
                 */ 
                listObjetosAnalisis.add(obb);
      
                /**
                 * Limpio el objeto de analisis de imagenes de Java. Para la nueva carga.
                 */ 
                pb.removeSources();

                coefTem = -1;
                INDICE++;
                mi_bar.setValue(INDICE);
                indexText.setText(Integer.toString(INDICE));
            
                /**
                 * IMPORTANTE: Este "if" detiene la hebra en caso de que se este en 
                 * modalidad de "Analisis" y se comunique a matlab 
                 */
                if(jSleep)
                    esperar();
            }    
            /*               FIN DEL METODO PRINCIPAL DE LA HEBRA             */    
        /* ------------------------------------------------------------------------- */
        
            /**
             * GUARDAR DATA EN EL ARCHIVO "Data_xxx" DE CADA ANIMAL.
             */
            if(CONTROL && mCONTROL.getControl(7)){
                saveDataGrafics();
            }
        
            /**
             * OJO: Si la opcion es analizar el esperimento COMPLETO, al finalizar 
             * de analizar UN ANIMAL, debe despertar a la otra hebra "miExperimento" 
             * que controla el analisis del grupo completo. En caso de NO estar 
             * corriendo un experimento completo, o un grupo de animales, pasa a
             * cambiar la condiciòn del botòn de control y su color.
             */
            if(tipoAnalisis == 3) miExperimento.despertar();
            else{
                mBoton.setStartColor(new Color(92, 136, 163));
                mBoton.setText("INICIAR");
            }
        
            INDICE = 0;
            CONTROL = false;
        }
// -------------------------------------------------------------------------- \\    
    
// --------------  METODO PARA INFORMAR A MATLAB Y ANALIZAR  ---------------- \\
    /**
     * ESTE ES EL PRINCIPAL METODO DE CONECCIÒN CON MATLAB. Aprovechando que matlab
     * trae incorporada la maquina virtual de JAVA, para sus aplicaciones gráficas,
     * muchas otras aplicaciones, generamos un protocolo que permite conectar, mediante
     * el llamado a "Eventos" de JAVA. el mètodo "miMetodo" es simplemente un llamdo 
     * a un 
     * .
     * 
     * @param _code Codigo que indica que metodo de Matlab es el llamado.
     */
    public void miMetodo(int _code){
        processKeyEvent(new KeyEvent(this, KeyEvent.KEY_PRESSED, 
                System.currentTimeMillis(), 0, _code, '-'));
    }
// -------------------------------------------------------------------------- \\
    
    /**
     * Metodo para hacer que la hebra ESPERE. Usado para detener la ejecuciòn 
     * de esta hebra, por ejemplo por Matlab o por el objeto que analiza completo
     * de un experimento. 
     * Se suele usar la detensiòn de esta hebra, para ver si està funcionando bien
     * la detecciòn o anàlisis de la misma.
     */
    public synchronized void esperar(){
      try {
          wait();
      } catch (InterruptedException ex) {
          Logger.getLogger(jAnalisis.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
    
    /**
     * Metodo para despertar la hebra. Usado para reactivar la ejecuciòn 
     * de esta hebra, por ejemplo por Matlab o por el objeto que analiza completo
     * de un experimento.
     */
    public synchronized void despertar(){
        jSleep = false;
        notify();
    }
    
    /**
     * Metodo llamado por Matlab, para despertar a esta hebra y continuar
     * con su ejecuciòn. Usado principalmente opr Matlab y no por esta 
     * hebra.
     */
    public void matlabDespierta(){
        if(!jSleep)
            despertar();
    }
    
    /**
     * Para ver si la hebra sigue viva.
     * @return Retorno el estado de la hebra.
     */
    public boolean isRunning(){
        return(CONTROL);
    }
    
    public void saveDataGrafics(){    
        int id = path_Date.length();
        boolean b1 = false;
        boolean b2 = false;
        
        String nameFile = "/data_" + path_Date.substring(id-3, id) + ".xls";
        File fDirec = new File(path_Date);
        
        
        if(new File(path_Date + "//" + nameFile).exists())
            miGrafico.GuadarSeries(path_Date, nameFile, 2);
        else{
            crearDataFile_XLS(path_Date, nameFile, 1);
            miGrafico.GuadarSeries(path_Date, nameFile, 1);
        }
        miGrafico.filtrosPython(path_Date +"//"+ nameFile, 0);   //Aplico los filtros !!!.
        
        
        if( new File(fDirec.getParent() + "/GENERAL").exists()){    
            if(new File(fDirec.getParent() + "/GENERAL/" + nameFile).exists())
                miGrafico.GuadarSeries(fDirec.getParent() + "/GENERAL/", nameFile, 2);
            else{
                crearDataFile_XLS(fDirec.getParent()+"/GENERAL/", nameFile, 1);
                miGrafico.GuadarSeries(fDirec.getParent()+"/GENERAL/", nameFile, 1);
            }
            miGrafico.filtrosPython(fDirec.getParent()+"/GENERAL/" + nameFile, 0);   //Aplico los filtros !!!.
        }
    }
    
//    /**
//     * Llama al objeto que maneja los gràficos de cada animal, y
//     * le pide que guarde dicho la serie dibujada en ese archivo.
//     */
//    public void saveDataGrafics(){    
//        int id = path_Date.length();
//        boolean b1 = false;
//        boolean b2 = false;
//        
//        String nameFile = "/data_" + path_Date.substring(id-3, id) + ".xls";
//        File fDirec = new File(path_Date);
//        
//        
//        if(new File(path_Date + "//" + nameFile).exists())
//            miGrafico.GuadarSeries(path_Date, nameFile, 2);
//        else{
//            crearDataFile_XLS(path_Date, nameFile, 1);
//            miGrafico.GuadarSeries(path_Date, nameFile, 1);
//        }
//        miGrafico.filtrosPython(path_Date +"//"+ nameFile, 0);   //Aplico los filtros !!!.
//        
//        
//        if( new File(fDirec.getParent() + "/GENERAL").exists()){
//            
//            if(new File(fDirec.getParent() + "/GENERAL/" + nameFile).exists())
//                miGrafico.GuadarSeries(fDirec.getParent() + "/GENERAL/", nameFile, 2);
//            else{
//                crearDataFile_XLS(fDirec.getParent()+"/GENERAL/", nameFile, 1);
//                miGrafico.GuadarSeries(fDirec.getParent()+"/GENERAL/", nameFile, 1);
//            }
//            miGrafico.filtrosPython(fDirec.getParent()+"/GENERAL/" + nameFile, 0);   //Aplico los filtros !!!.
//        }
//    }
    
    
    
    
    public void crearDataFile_XLS(String _path, String _fileName, int _param){
        try {
            String pathFile = _path + "//" + _fileName;
            FileOutputStream fileOut = new FileOutputStream(pathFile);
            HSSFWorkbook workbook    = new HSSFWorkbook();
            
            HSSFSheet worksheet1     = workbook.createSheet("LocalDesv_01");
            HSSFSheet worksheet2     = workbook.createSheet("Bordes_01");
            
            formatoHoja(worksheet1);
            formatoHoja(worksheet2);
            
            workbook.write(fileOut);
            fileOut.flush();
            fileOut.close();
            
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public void formatoHoja(HSSFSheet _hoja){
        HSSFRow row1    = _hoja.createRow(0);
        row1.createCell(4);
        
        row1    = _hoja.createRow(1); //Fila para el tiempo de APAGADO
        
        HSSFCell cellA1 = row1.createCell(1);
        cellA1.setCellValue("Fecha Inicio:");
        
        cellA1 = row1.createCell(4);
        cellA1.setCellValue("N° Segundos");
        cellA1 = row1.createCell(5);
        cellA1.setCellValue("Data");
        cellA1 = row1.createCell(6);
        cellA1.setCellValue("Filtro 5pts");
        cellA1 = row1.createCell(7);
        cellA1.setCellValue("DIFERENCIA NORMAL");
        
        cellA1 = row1.createCell(9);
        cellA1.setCellValue("Filtro SG 5pts");
        cellA1 = row1.createCell(10);
        cellA1.setCellValue("DIFERENCIA SG");
        
        
        row1 = _hoja.createRow(2);
        cellA1 = row1.createCell(1);
        cellA1.setCellValue("Hora Inicio");
        
        row1 = _hoja.createRow(4);
        cellA1 = row1.createCell(1);
        cellA1.setCellValue("Genotipo:");
        
        row1 = _hoja.createRow(5);
        cellA1 = row1.createCell(1);
        cellA1.setCellValue("Grupo:");
    }
    
    
    public boolean saveDataParametros(String _Genotipe, String _Hora, Date _dRefApagado){
        boolean resul = false;
        
        this.horaRefInit   = _dRefApagado;
        miGrafico.horaRefInit = _dRefApagado;
        
        int id = path_Date.length();
        String nameFile = "data_" + path_Date.substring(id-3, id) + ".xls";
        File filD = new File(path_Date + "/" + nameFile);
        
        resul = filD.exists();
        if(resul == false){
            crearDataFile_XLS(path_Date, nameFile, 1);
            resul = filD.exists();
        }
        saveDataParametros(filD, _Genotipe, _Hora, horaRefInit); //Guardo en XLs del animal
        
        
        String dirGENERAL = filD.getParentFile().getParent()+"/GENERAL/";
        filD = new File(dirGENERAL + nameFile);
        resul = filD.exists();
        if(resul == false){
            crearDataFile_XLS(dirGENERAL, nameFile, 1);
            resul = filD.exists();
        }
        saveDataParametros(filD, _Genotipe, _Hora, horaRefInit); //Guardo en XLs del animals
        
        return(resul);
    }
    
    public boolean saveDataParametros(File fd, String _Genotipe, String _Hora, Date _dt){    
        boolean bene = true;
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        String fechaInit = dateFormat.format(_dt);
        
        dateFormat = new SimpleDateFormat("HH:mm:ss");
        String  horaInit = dateFormat.format(_dt);
        
        if(bene){
            FileInputStream fileInput;
            try {
                fileInput = new FileInputStream(fd);
                HSSFWorkbook workbook = new HSSFWorkbook(fileInput);
                
                HSSFSheet workStands = workbook.getSheetAt(0);
                HSSFSheet workBordes = workbook.getSheetAt(1);
                fileInput.close();
                
                Row row1    = null;
                Cell colum  = null;
    //----------------------------------------------------------------\\        
                row1  = workBordes.getRow(1);
                if(row1.getCell(2) == null)
                    colum = row1.createCell(2);
                else
                    colum = row1.getCell(2);
                colum.setCellValue(fechaInit);
                
                row1  = workBordes.getRow(2);
                if(row1.getCell(2) == null)
                    colum = row1.createCell(2);
                else
                    colum = row1.getCell(2);
                colum.setCellValue(horaInit);
                
                row1  = workBordes.getRow(4);
                if(row1.getCell(2) == null)
                    colum = row1.createCell(2);
                else
                    colum = row1.getCell(2);
                colum.setCellValue(_Genotipe);
                
                row1  = workBordes.getRow(5);
                if(row1.getCell(2) == null)
                    colum = row1.createCell(2);
                else
                    colum = row1.getCell(2);
                colum.setCellValue(_Hora);
                
        //  0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0 \\
                calcRangoDelta(workBordes, _dt);
        //= 0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0 =\\
                
// ----------------------------------------------------------------- \\
                row1  = workStands.getRow(1);
                if(row1.getCell(2) == null)
                    colum = row1.createCell(2);
                else
                    colum = row1.getCell(2);
                colum.setCellValue(fechaInit);
                
                row1  = workStands.getRow(2);
                if(row1.getCell(2) == null)
                    colum = row1.createCell(2);
                else
                    colum = row1.getCell(2);
                colum.setCellValue(horaInit);
                
                row1  = workStands.getRow(4);
                if(row1.getCell(2) == null)
                    colum = row1.createCell(2);
                else
                    colum = row1.getCell(2);
                colum.setCellValue(_Genotipe);
                
                row1  = workStands.getRow(5);
                if(row1.getCell(2) == null)
                    colum = row1.createCell(2);
                else
                    colum = row1.getCell(2);
                colum.setCellValue(_Hora);
                
        //  0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0 \\
                calcRangoDelta(workStands, _dt);
        //= 0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0 =\\
// ----------------------------------------------------------------- \\                
                
                FileOutputStream out = new FileOutputStream(fd);
                workbook.write(out);
                out.close();
                
                bene = true;
            } catch (FileNotFoundException ex) {
                Logger.getLogger(jAnalisis.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(jAnalisis.class.getName()).log(Level.SEVERE, null, ex);
            }   
        }
        
        return(bene);
    }
    
    private void calcRangoDelta(HSSFSheet _hoja, Date _dt){
        Cell mVal  = null;
        Row row1   = _hoja.getRow(0);
        
        if(row1.getCell(4) == null){
            mVal = row1.createCell(4);
            mVal.setCellValue(_dt.getTime());
            return;
        }
        else{
            double dtime = 0;
            double ref1  = row1.getCell(4).getNumericCellValue();
            
            mVal = row1.getCell(4);
            mVal.setCellValue(_dt.getTime());
            
            int rango = _hoja.getLastRowNum()+1;
            
            for(int i = 2; i < rango; i++){
                row1  = _hoja.getRow(i); //OJO, acá "row1" tomó el valor de la FILA actual
                if(row1 == null) continue;
                
                if(row1.getCell(4) != null){
                    dtime = row1.getCell(4).getNumericCellValue() + (ref1 - _dt.getTime()) / 1000;
                    row1.getCell(4).setCellValue(Math.round(dtime));
                }
            }
        }
    }
    
    /**
     * Lee la imagen indicada en por el path_name. Metodo usado por la hebra, 
     * cuando esta corriendo en cualquier modalidad, ya sea buscando la mejor 
     * zona de la imagen completa, o tambièn analizando dicha bùsqueda.<p>
     * Carga la imagen respectiva.
     * 
     * @param path: Direcciòn de la carpeta donde estàn las imàgenes.
     * @param name: Nombre de la carpeta del animal a trabajar.
     * @return La imagen leida, o bien null en caso de algùn problema.
     */
    public RenderedOp leerIm(String path, String name){
        FileSeekableStream fTemp;
        try {
            fTemp = new FileSeekableStream(path + "/" + name);
            return(JAI.create("stream", fTemp));
            
        } catch (IOException ex) {
            Logger.getLogger(jAnalisis.class.getName()).log(Level.SEVERE, null, ex);
            return(null);
        }
    }
    
    /**
     * Funcion de CORRELACION: Esta permite contrast two images (los parametros they are 
     * vectors of both images) para determinar su parentesco. Es usado ampliamente
     * en el algoritmo de busqueda de la mejor zona de la imagen, para centrarla y 
     * enviarsela a Matlab para realizar el anàlisis.
     * 
     * @param img1: Primera imagen a comparar.
     * @param img2: Segunda imagen a comparar.
     * @return Factor de correclacion entre imagenes.
     */
    public double corr2(Raster img1, Raster img2){
        double coefCorr;
        double mean1 = 0;
        double mean2 = 0;
        double mean_a1 = 0;
        double mean_a2 = 0;
        double meanX = 0;
        
        DataBuffer A1 = img1.getDataBuffer();
        DataBuffer A2 = img2.getDataBuffer();
        for(int i = 0; i < A1.getSize(); i++){
            mean1   += A1.getElem(i);
            mean_a1 += Math.pow(A1.getElem(i),2);
            mean2   += A2.getElem(i);
            mean_a2 += Math.pow(A2.getElem(i),2);
            
            meanX += A1.getElem(i)*A2.getElem(i);
        }
        mean1  = mean1/Area;
        mean2  = mean2/Area;
        meanX += Area*(mean1 - mean2);
        
        //Formula de Correlacion entre vectores. Encontrada en cualquier parte.
        coefCorr = meanX / Math.sqrt(mean_a1*mean_a2 - Area*(mean2*mean_a1
                - mean1*mean_a2 - Area*mean1*mean2));
        
        return(coefCorr);
}
    
    /**
     * resetear todos los objetos que almacenen caracteristicas de un animal
     * en particular. 
     */
    public void resetPolig(){
        listPuntos.clear();
        Control_RoiPoli = true;
        
        botonSET("SET");
        this.repaint();
    }
    
    /**Mètodo que guarda en un archivo especìfico ("roi_poly.txt") los puntos
     * determinados por el usuario, que son parte de la zona de análisis de la
     * cabeza de un animal en particular.
     * @param _code 
     */
    public void guarParametros(int _code){
        if(_code == 1){
            if(path_Date == null)
                return;
            try {
                FileWriter outFile = new FileWriter(new File(path_Date + "/roi_poly.txt"));
                PrintWriter    out = new PrintWriter(outFile);
                // Write text to file
                out.println(eA_1.x + " " + eA_1.y);
                out.println(mWidth + " " + mHeight);
                out.println(-1 + " " + -1);
                for(int i=0; i < listPuntos.size(); i++){
                    Point pp = (Point)listPuntos.get(i);
                    out.println(pp.x + " " + pp.y);
                }
                out.close();
            }catch (IOException e){}
        }  
    }
    public boolean testZonas(){
        boolean temp = false;
        Rectangle2D.Double p1 = new Rectangle2D.Double(eA_1.x, eA_1.y, mWidth, mHeight);
        for(int i=0; i<listPuntos.size();i++){
            if(!p1.contains((Point)listPuntos.get(i))){
                temp = true;
            }
        }
        return(temp);
    }
    
    /**
     * Mètodo que carga los parametros del ROI y Otros para el anàlisis. Por 
     * cada animal se guardan un vector en un archivo de texto llamado 
     * "roi_poly.txt" y otros datos en un archivo propio de este sistema 
     * "Serie_Datos.datt". Ambos contienen todos los parametros ùtiles al momento
     * de trabajar (bùsqueda y anàlisis) una secuencia de imagenes.
     * @return 
     */
    public boolean cargarData(){
        boolean conD1 = false;
        boolean conD2 = false;
        
        listPuntos.clear();
        Control_RoiPoli = true;
        this.repaint();
        
        if(new File(path_Date + "/roi_poly.txt").exists()){
            setDatosCargados(path_Date + "/roi_poly.txt");
            miGrafico.resetData();
            conD1 = true;
        }
        
        //Si existe el archivo con los datos a cargar.
        int id = path_Date.length();
        String nameFile = path_Date + "/data_" + path_Date.substring(id-3, id) + ".xls";
        if(new File(nameFile).exists()){
            FileInputStream fileInput = null;
            
            try {
                fileInput = new FileInputStream(nameFile);
                HSSFWorkbook workbook = new HSSFWorkbook(fileInput);
                HSSFSheet workBordes = workbook.getSheetAt(0);
                HSSFSheet workStands = workbook.getSheetAt(1);
                fileInput.close();
                
                Row row1    = workBordes.getRow(4);
                Cell colum  = null;
                
                String valGenotipo = "";
                String valHora     = "";
                if(row1 != null){
                    colum = row1.getCell(2);
                    if(colum != null){
                        valGenotipo = colum.getStringCellValue();
                        genoTipo.setSelectedItem(valGenotipo);
                    }else{
                        genoTipo.setSelectedIndex(3);
                    }
                }
                row1    = workStands.getRow(5);
                if(row1 != null){
                    colum = row1.getCell(2);
                    if(colum != null){
                        valHora = colum.getStringCellValue();
                        horaHora.setSelectedItem(valHora.substring(0, 2));
                        horaMinu.setSelectedItem(valHora.substring(3, 5));
                    }else{
                        horaHora.setSelectedIndex(0);
                        horaMinu.setSelectedIndex(0);
                    }
                }
            }catch (FileNotFoundException e) {
                e.printStackTrace();
            }catch (IOException e) {
                e.printStackTrace();
            }
        }
        if(!new File(path_Date + "/mask.tiff").exists()){//OJO, pregunta si NO existe la maskara
            String s;
            Process p;
            ProcessBuilder pb;
            try {//OJO, cambie los 'espacios' por un doble comilla. Python los remplaza
                String[] command = {"python" ,"otrosMetodos.py", path_Date.replace(' ', '"')};
                
                pb = new ProcessBuilder(command);
                p  = pb.start();
                
                BufferedReader br = new BufferedReader(
                        new InputStreamReader(p.getInputStream()));
                
                BufferedReader stdError = new BufferedReader(
                        new InputStreamReader(p.getErrorStream()));
                
                while ((s = br.readLine()) != null){
                    mensaje("Comando" + s);
                }
                
                while ((s = stdError.readLine()) != null) {
                    mensaje("Error..." + s);
                }
                
                p.waitFor();
                p.destroy();
            } catch (Exception e) {
            }
        }
        
        return(conD1 && conD2);
    }

    /* ---  ACA, ANALISIS Y COMUNICACION CON PYTHON --- */
    /**
     * Metodo para guardar los datos necesarios para que python abra la imagen,
     * la zona adecuada, y sepa donde guardar los datos.
     */
    public  boolean dataPython(){
        boolean CONTROL = false;
        try {
            FileWriter outFile = new FileWriter(new File("data_Python.txt"));
            PrintWriter    out = new PrintWriter(outFile);
            // Write text to file
            out.println(obb.getPath().getAbsolutePath());
            
            Point pd = obb.getPunto();
            out.println(pd.x + " " + pd.y);  //Write point in the file
            
            out.println(mHeight + " " + mWidth); //Write segment in the file
            out.println(path_Date);
            
            out.close();   
            CONTROL = true; //Indica que todo bien
            
        } catch (IOException e){
            CONTROL = false;
        }
        return(CONTROL);
    }
    private boolean procesoPython(){
        String s;
        String lineCommand;
        Process p;
        ProcessBuilder pb;
        try {
            //lineCommand = "python proceso_Python.py " + obb.getPath().getAbsolutePath();
            String[] command = {"python" ,"proceso_Python.py", obb.getPath().getAbsolutePath()};
            
            pb = new ProcessBuilder(command);
            p  = pb.start();
            
            BufferedReader br = new BufferedReader(
                        new InputStreamReader(p.getInputStream()));
            
            BufferedReader stdError = new BufferedReader(
                        new InputStreamReader(p.getErrorStream()));
            
            
            Minute minn = construirMinute2(obb.getPath().getName());
            
            while ((s = br.readLine()) != null){
                int dd = s.indexOf('_');
                double dDesv = Double.parseDouble(s.substring(0, dd-1));
                double dEdge = Double.parseDouble(s.substring(dd+1, s.length()));
                
                miGrafico.setData(minn, dEdge, dDesv);    // Envio ambos datos al grafico, que luego puede guardar 
                
                Thread.sleep(100);
            }
            
            while ((s = stdError.readLine()) != null) {
                mensaje("Error..." + s);
            }
            p.waitFor();
            p.destroy();
            
            mCONTROL.setControl(7, true);
            return(true);
        } catch (Exception e) {
            mCONTROL.setControl(7, false);
            return(false);
        }        
    }
    
    public Minute construirMinute(String _path){
        int leng = _path.length();
        
        int minut = Integer.parseInt(_path.substring(leng-13, leng-11));
        int Horas = Integer.parseInt(_path.substring(leng-16, leng-14));
        int   dia = Integer.parseInt(_path.substring(leng-19, leng-17));
        
        int  Mess = Integer.parseInt(_path.substring(leng-22, leng-20));
        int  Ano  = Integer.parseInt(_path.substring(leng-25, leng-23)) + 2000;
        
        Minute minn = new org.jfree.data.time.Minute(minut, Horas, dia, Mess, Ano);  
        return(minn);
    }
    
    public Minute construirMinute2(String _dia){
        String Hora = "";
        Date moment = null;
        Minute minn = null;
        
        Hora = _dia.replace(".", ":");
        Hora = Hora.replace(",", ".");        
        
        SimpleDateFormat sdf = new SimpleDateFormat("yy-M-dd HH:mm:ss.SSS"); //IMPORTANTE: SErie de tiempo en 0-24 hrs
        
        try {
            moment = sdf.parse(Hora.substring(0, 21));
            minn = new Minute(moment);
            
        } catch (ParseException ex) {
            Logger.getLogger(DMMPRINCIPAL.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return(minn);
    }
    
    
    public void botonSET(String _std){
        if(_std.equalsIgnoreCase("---")){
            mBotonSet.setText(_std);
            mBotonSet.setForeground(new Color(76, 76, 76));            
        }else{
            mBotonSet.setText(_std);
            mBotonSet.setForeground(new Color(255, 0, 0));
        }
    }
    
  /**
  * NO usado. Simplemente para pruebas internas.
  * @param _mensaje 
  */
    public void mensaje(Object _mensaje){
        System.out.println(_mensaje);
    }
    
    /**
     * Metodo usado para sectores en Matlab !.
     * Metodo para guardar los puntos de seleccion de la mejor imagene, luego de la correlacion
     * @param _x: Posicion en x (esquina superior-izquierda)
     * @param _y: Posicion en y (esquina superior-izquierda)
     * @param _W: Width de la zona.
     * @param _H: High  de la zona.
     */
    public void guardarPuntos(int _x, int _y, int _W, int _H){
        try {
            FileWriter outFile = new FileWriter(new File(path_Date + "/control.txt"), true);
            BufferedWriter out = new BufferedWriter(outFile);
            // Write text to file
            int indx = INDICE + 1;
            out.write(indx + "   " + _x + " " + _y + " " +_W + " " + _H);
            out.newLine();
            out.close();
            
        }catch (IOException e){}
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
//    public void testMetodos(){
//        if(!new File(path_Date + "/mask.tiff").exists()){//NO existe la maskara
//            String s;
//            Process p;
//            ProcessBuilder pb;
//            try {//OJO, cambie los 'espacios' por un doble comilla. Python los remplaza
//                String[] command = {"python" ,"otrosMetodos.py", path_Date.replace(' ', '"')};
//                
//                pb = new ProcessBuilder(command);
//                p  = pb.start();
//                
//                BufferedReader br = new BufferedReader(
//                        new InputStreamReader(p.getInputStream()));
//                
//                BufferedReader stdError = new BufferedReader(
//                        new InputStreamReader(p.getErrorStream()));
//                
//                while ((s = br.readLine()) != null){
//                    mensaje("Comando" + s);
//                }
//                
//                while ((s = stdError.readLine()) != null) {
//                    mensaje("Error..." + s);
//                }
//                
//                p.waitFor();
//                p.destroy();
//            } catch (Exception e) {
//            }
//        }
//    }   
}






//** METODOS QUE NO S0N USADOS, PERO TIENEN DETALLES QUE PODRIAN SER UTILES **/

//    private boolean guardarImg(String Path, String ImgName, BufferedImage Img){
//        FileOutputStream os = null;
//        ParameterBlock pb = new ParameterBlock();
//        pb.add(Img);
//        try {
//            FileSeekableStream fTemp = null;
//            os = new FileOutputStream(Path + "/" + ImgName);
//            ImageEncoder encoder = ImageCodec.createImageEncoder("TIFF", os, null);
//            encoder.encode(JAI.create("awtImage", pb));
//            os.close();
//            return true;
//        } catch (IOException ex) {
//            Logger.getLogger(jAnalisis.class.getName()).log(Level.SEVERE, null, ex);
//            return(false);
//        } finally {
//            try {
//                os.close();
//                return(false);
//            } catch (IOException ex) {
//                Logger.getLogger(jAnalisis.class.getName()).log(Level.SEVERE, null, ex);
//                return(false);
//            }
//        }
//    }
//    private void generar(BufferedImage _imd, int _ranInf, int _ranSup){        
//        float[] mTem = {1,1,1,1,1,1,1,1,1};
//        KernelJAI kTem = new KernelJAI(3, 3, 1, 1, mTem);
//        
//        int dX = 0;
//        int dY = 0;
//        
//        if(_imd.getWidth() != 640){
//            dX = eA_1.x;
//            dY = eA_1.y;
//        }
//        miMask  = new BufferedImage(_imd.getWidth(), _imd.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
//        mMask_2 = new BufferedImage(_imd.getWidth(), _imd.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
//        
//        for(int j = 0; j < miMask.getHeight(); j++)
//            for(int i = 0; i < miMask.getWidth() ; i++)
//                miMask.setRGB(i, j, 50);
//        
//        for(int i = 0; i < _imd.getWidth(); i++)
//            for(int j = 0; j < _imd.getHeight(); j++)
//                if(new Color(_imd.getRGB(i, j)).getRed() > binRango 
//                && polyAnalisis.contains(i, j)){
//                    mMask_2.setRGB(i, j, Color.white.getRGB());
//                }
//        
//        ParameterBlock pb = new ParameterBlock();
//        pb.addSource(mMask_2);
//        pb.add(kTem);
//        PlanarImage src = JAI.create("dilate", pb);
//        mMask_2 = src.getAsBufferedImage();
//    }

//        try{
//            // Create file
//            FileWriter fstream = new FileWriter("C:\\out.txt", true);
//            BufferedWriter out = new BufferedWriter(fstream);
//            out.write(path_Date + "|||");
//            out.write(eA_1.x + ";" + eA_1.y + "==");
//            out.write(eA_2.x + ";" + eA_2.y + newline);
//            //Close the output stream
//            out.close();
//        }catch (Exception e){//Catch exception if any
//            System.err.println("Error: " + e.getMessage());
//        }  

//    private int gray2falseColor(){
//        int[][] red   = new int[miImg.getWidth()][miImg.getHeight()];
//        int[][] green = new int[miImg.getWidth()][miImg.getHeight()];
//        int[][] blue  = new int[miImg.getWidth()][miImg.getHeight()];
//        
//        float leftSlope  = (float) (255.0 / 85.0);
//        float midSlope   = (float) (255.0 / (160.0 - 85.0));
//        float rightSlope = (float) (-255.0 / 84.0 );
//        
//        Raster dR1 = miImg.getData();
//        DataBuffer buf1 = dR1.getDataBuffer();
//        int X;
//        int entry = 0;
//        for(int i = 0; i < miImg.getHeight(); i++)
//            for(int j = 0; j < miImg.getWidth(); j++){             
//                X = buf1.getElem(entry++);
//                if (X < 30) {
//                    red[j][i] = 0;
//                    green[j][i] = 0;
//                    blue[j][i] = Math.round( (128/30)*X + 127 );
//                }else if ((X >= 30) && (X < 85)) {
//                    red[j][i] = 0;
//                    green[j][i] = Math.round(leftSlope * X);
//                    blue[j][i] = 255;
//                
//                } else if ((X >= 85) && (X < 160)) {
//                    red[j][i] = Math.round(255 + midSlope * (X - 160));
//                    green[j][i] = 255;
//                    blue[j][i] = Math.round(255 - midSlope * (X - 85));
//                
//                }else if((X >= 160) && (X < 230)){
//                    red[j][i] = 255;
//                    green[j][i] = Math.round(255 + rightSlope * (X - 160));
//                    blue[j][i] = 0;
//                
//                }else{
//                    red[j][i] = Math.round(-(127/25)*(X - 230) + 255);
//                    green[j][i] = 0;
//                    blue[j][i] = 0;
//                }
//            }
//        
//        BufferedImage falseColor = 
//                new BufferedImage(miImg.getWidth(), miImg.getHeight(), BufferedImage.TYPE_INT_RGB);
//        WritableRaster falseColorRaster = falseColor.getRaster();
//        for (int y = 0; y < miImg.getHeight(); y++) {
//            for (int x = 0; x < miImg.getWidth(); x++) {
//                falseColorRaster.setSample(x, y, 0,   red[x][y]);
//                falseColorRaster.setSample(x, y, 1, green[x][y]);
//                falseColorRaster.setSample(x, y, 2,  blue[x][y]);
//            }
//        }
//        falseColor.setData(falseColorRaster);
//        this.setIcon(new ImageIcon((Image)falseColor));
//        return(1);   
//    }
//        image = (PlanarImage)JAI.create("awtImage", pb);

//    public void setjListaMoscas(jListaMoscas _lista){
//        path_Date = _lista.getPath();
//        eA_1 = _lista.getP1();
//        eA_2 = _lista.getP2();
//        listPuntos = _lista.getLista();
//        direc = new File(path_Date).list(new MyFilter(".tif"));
//        if(direc.length != 0)
//            setImagen(leerIm(path_Date, direc[0]));
//        setAreaData(0);
//    }
    
//    public void setBoundsMask(int _Width, int _Height){
//        this.setIcon(null);
//        LMask.setBounds(Math.round((640 - _Width)/2),
//                Math.round((480 - _Height) / 2), _Width, _Height);
//        LMask.setVisible(true);
//    }

//        String fechaInit = getFechaInicio(direc[0]);
//        String  horaInit = getHoraInicio(direc[0]);


//    public String getHoraInicio(String _nameFile){
//        int id = _nameFile.length();
//        String ret = _nameFile.substring(id-16, id - 8).replace('.', ':');
//        
//        return(ret);
//    }
//    public String getFechaInicio(String _nameFile){
//        int id = _nameFile.length();
//        String ret = _nameFile.substring(id-25, id-17);
//        ret = ret.substring(6, 8) + 
//                "-" + ret.substring(3, 5) +
//                    "-20" + ret.substring(0, 2);
//        
//        return(ret);
//    }
//  public boolean saveDataParametros(File fd, String _Genotipe, String _Hora, Date _dt){    
//        boolean bene = false;
//        
//        int id = path_Date.length();
//        String nameFile = "data_" + path_Date.substring(id-3, id) + ".xls";
//        
//        File filD = new File(path_Date + "/" + nameFile);
//        
//        bene = filD.exists();
//        if(bene == false){
//            crearDataFile_XLS(path_Date, nameFile, 1);
//            bene = filD.exists();
//        }
//        
//        
//        
//        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
//        String fechaInit = dateFormat.format(_dt);
//        
//        dateFormat = new SimpleDateFormat("HH:mm:ss");
//        String  horaInit = dateFormat.format(_dt);
//        
//        
//        if(bene){
//            FileInputStream fileInput;
//            try {
//                fileInput = new FileInputStream(path_Date + "/" + nameFile);
//                HSSFWorkbook workbook = new HSSFWorkbook(fileInput);
//                
//                HSSFSheet workBordes = workbook.getSheetAt(0);
//                HSSFSheet workStands = workbook.getSheetAt(1);
//                fileInput.close();
//                
//                Row row1    = null;
//                Cell colum  = null;
//    //----------------------------------------------------------------\\        
//                row1  = workBordes.getRow(1);
//                if(row1.getCell(2) == null)
//                    colum = row1.createCell(2);
//                else
//                    colum = row1.getCell(2);
//                colum.setCellValue(fechaInit);
//                
//                row1  = workBordes.getRow(2);
//                if(row1.getCell(2) == null)
//                    colum = row1.createCell(2);
//                else
//                    colum = row1.getCell(2);
//                colum.setCellValue(horaInit);
//                
//                row1  = workBordes.getRow(4);
//                if(row1.getCell(2) == null)
//                    colum = row1.createCell(2);
//                else
//                    colum = row1.getCell(2);
//                colum.setCellValue(_Genotipe);
//                
//                row1  = workBordes.getRow(5);
//                if(row1.getCell(2) == null)
//                    colum = row1.createCell(2);
//                else
//                    colum = row1.getCell(2);
//                colum.setCellValue(_Hora);
//                
//        //  0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0 \\
//                row1  = workBordes.getRow(0);
//                if(row1.getCell(4) == null)
//                    colum = row1.createCell(4);
//                else
//                    colum = row1.getCell(4);
//                colum.setCellValue(_dt.getTime());
//        //= 0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0 =\\
//                
//// ----------------------------------------------------------------- \\
//                row1  = workStands.getRow(1);
//                if(row1.getCell(2) == null)
//                    colum = row1.createCell(2);
//                else
//                    colum = row1.getCell(2);
//                colum.setCellValue(fechaInit);
//                
//                row1  = workStands.getRow(2);
//                if(row1.getCell(2) == null)
//                    colum = row1.createCell(2);
//                else
//                    colum = row1.getCell(2);
//                colum.setCellValue(horaInit);
//                
//                row1  = workStands.getRow(4);
//                if(row1.getCell(2) == null)
//                    colum = row1.createCell(2);
//                else
//                    colum = row1.getCell(2);
//                colum.setCellValue(_Genotipe);
//                
//                row1  = workStands.getRow(5);
//                if(row1.getCell(2) == null)
//                    colum = row1.createCell(2);
//                else
//                    colum = row1.getCell(2);
//                colum.setCellValue(_Hora);
//                
//        //  0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0 \\
//                row1  = workStands.getRow(0);
//                if(row1.getCell(4) == null)
//                    colum = row1.createCell(4);
//                else
//                    colum = row1.getCell(4);
//                colum.setCellValue(_dt.getTime());
//        //= 0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0=0 =\\
//// ----------------------------------------------------------------- \\                
//
//                FileOutputStream out = new FileOutputStream(path_Date + "/" + nameFile);
//                workbook.write(out);
//                out.close();
//                
//                bene = true;
//            } catch (FileNotFoundException ex) {
//                Logger.getLogger(jAnalisis.class.getName()).log(Level.SEVERE, null, ex);
//            } catch (IOException ex) {
//                Logger.getLogger(jAnalisis.class.getName()).log(Level.SEVERE, null, ex);
//            }   
//        }
//        
//        return(bene);
//    }


//    public boolean nuevaHoja(String _path, String _name){
//        String path_file = _path + "//" + _name;
//        try{
//            FileInputStream fileArchivoDatos = new FileInputStream(path_file);
//            HSSFWorkbook workbook = new HSSFWorkbook(fileArchivoDatos);
//            HSSFSheet   worksheet = workbook.getSheetAt(0);
//            
//            
//            String nameSheet = worksheet.getSheetName();
//            int ll = nameSheet.length();
//            int Index = Integer.parseInt(nameSheet.substring(ll-2, ll));
//            
//            String newName = nameSheet.substring(0, ll-1) + String.valueOf(Index+1);
//            
//            
//            HSSFSheet newShet = workbook.createSheet(newName);
//            HSSFRow row1    = newShet.createRow(1);
//            
//            HSSFCell cellA1 = row1.createCell(1);
//            cellA1.setCellValue("Fecha Inicio:");
//            
//            cellA1 = row1.createCell(4);
//            cellA1.setCellValue("N° Minutos");            
//            cellA1 = row1.createCell(5);
//            cellA1.setCellValue("Data");
//            
//            row1 = newShet.createRow(2);
//            cellA1 = row1.createCell(1);
//            cellA1.setCellValue("Hora Inicio");
//            
//            row1 = newShet.createRow(4);
//            cellA1 = row1.createCell(1);
//            cellA1.setCellValue("Genotipo:");
//            
//            row1 = newShet.createRow(5);
//            cellA1 = row1.createCell(1);
//            cellA1.setCellValue("Grupo:");
//            
//            fileArchivoDatos.close();
//            FileOutputStream out = new FileOutputStream(path_file);
//            workbook.write(out);
//            out.close();
//            
//            return(true);
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//            return(false);
//        } catch (IOException e) {
//            e.printStackTrace();
//            return(false);
//        }
//    }    