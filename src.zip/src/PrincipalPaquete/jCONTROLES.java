/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PrincipalPaquete;
/**
 *
 * @author Felipe
 */
public class jCONTROLES {
    //     CONTROLES     //
    /*  0:
    //  1:
    //  2:
    //  3:   
    //  4:  Control hebra Analisis. Esta corriendo = true;
    //  5:  Control hebra Análisis: Esta durmiendo = true;
    *   6:  Control Formato de datos;
         * index -- =
         * index 20 = Control hebra graficos.
     */ 
    
    private boolean CONTROLES[] = new boolean[20];
    public jCONTROLES() {
    }
    public void setControl(int _index, boolean _type){
        CONTROLES[_index] = _type;
    }
    public boolean getControl(int _index){
        return(CONTROLES[_index]);
    }
}
