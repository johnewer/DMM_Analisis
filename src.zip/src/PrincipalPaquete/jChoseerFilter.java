/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package PrincipalPaquete;

import java.io.File;
import javax.swing.filechooser.FileFilter;

/**
 *
 * @author Felipe
 */
public class jChoseerFilter extends FileFilter{
    
    public boolean accept (File fichero){
      if (fichero.isDirectory() || fichero.getName().endsWith(".dmm"))
         return true;
      else
         return false;
    }
    
    public String getDescription(){
      return ("Filtro dmm");
   }
}
