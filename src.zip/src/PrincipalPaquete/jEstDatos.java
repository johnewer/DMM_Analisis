/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PrincipalPaquete;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author Felipe
 */
public class jEstDatos {
    List listPX = new LinkedList();
    List listPY = new LinkedList();
    List listPT = new LinkedList();
    
    public jEstDatos(){
    }
    
    public void setData(double _data, int tipo){
        if(tipo == 0)
            listPX.add(_data);
        else if(tipo == 1)
            listPY.add(_data);
        else
            listPT.add(_data);;
    }
    
    public void getPromedio(){
        for(int i=0;i < listPT.size(); i++){
            
        }
                
    }

}


