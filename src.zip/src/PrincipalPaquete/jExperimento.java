/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PrincipalPaquete;

import java.awt.Color;
import java.io.File;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *  Clase jExperimento: Esta clase es usada para ANALIZAR un experimento completo,
 *       con su lista de carpetas donde esta cada animal.
 *       ANALIZA cada animal en forma AUTOMATICA y luego carga los datos en la 
 *       carpeta respectiva.
 * 
 *  @author Felipe
 */
public class jExperimento implements Serializable, Runnable{
    
    /** 
     * mControles: Es un objeto que guarda una serie de variables booleanas de 
     *      control, para manejar la ejecuciòn de diferentes eventos, y està 
     *      conectada entre todos los objetos principales de este sistema. 
     *      Es el mismo en cada uno de los objetos principales.
     * 
     */
    public jCONTROLES mCONTROL = null;{
    /* index  0 = Control de separacion de imagenes
     * index  1 = Guardar data Analisis !.
     * index  2 = Control de Inicio de analisis de datos.
     * index  3 = Control de gràficas a mostrar.
     * index  4 = 
     * index  5 = 
     * index  6 = Control de eventos generales de ANALIZAR !.
     * index  7 = Control guardar data.
     * index 10 = Control ejecucion hebra de separación.
     * index 11 =
     * index 12 = 
     * index 13 =
     * index 14 = 
    */
}
    
    
    //VARIABLE CONTROL DE ACTIVACION
    private boolean ACTIVAR = false;
    private boolean CONTROL = false;
    private boolean sleep   = false;
    public int INDICE   = 0;
    public int maxINDEX = 0;
    
    private Thread miHebra  = null;
    private String[] list   = null;
    private miBoton  mBoton = null;
    
    private String pathExperimento  = "";
    private String[] listNombre     = null;
    
    private jAnalisis miAnalisis  = null;
    public  jPlot_times miGrafico = null;
    
    
    
    /**
     * CONSTRUCTOR: Al construirse, conecta con los paràmetros de entrada, el
     * elemento que analizarà cada serie, y el boton GENERAL que controla las ordenes
     * de ejecuciòn.
     * 
     * @param _miAnalisis
     * @param _mBoton 
     */
    public jExperimento(jAnalisis _miAnalisis, miBoton _mBoton, jCONTROLES _mCONTROL){
        miAnalisis = _miAnalisis;
        mBoton     = _mBoton;
        mCONTROL   = _mCONTROL;
    }
    
    public void setPath(String _path){
        pathExperimento = _path;
    }
    public void setLista(String[] _listNombre){
        listNombre = _listNombre;
        maxINDEX = listNombre.length;
    }
    public void setACTIVACION(boolean _ACTIVAR){
        ACTIVAR = _ACTIVAR;
    }
    public void setMinIndex(int _minIndex){
        INDICE = _minIndex - 1;
    }
    public void setMaxIndex(int _maxIndex){
        maxINDEX = _maxIndex;
    }
    
    public void run() {
        if(!ACTIVAR){ return; }
        
        while(CONTROL){
            if(INDICE > (maxINDEX-1)){
                CONTROL = false;
                continue;
            }
            
            String dirMosca = pathExperimento.concat("/" + listNombre[INDICE]);
            if(!controlArchivos(dirMosca)){
                INDICE++;
                continue;
            }
            
            list = new File(dirMosca).list(new MyFilter(".tif"));
            java.util.Arrays.sort(list);
            
            miAnalisis.setOcultar();
            miAnalisis.setData(dirMosca, list);
            miAnalisis.cargarData();
            miAnalisis.setTituloSegundo(listNombre[INDICE]);
            miAnalisis.botonSET("---");
                    
            miGrafico.resetData();
            
     //      ------ HACE CORRER CADA ANIMAL ------       \\
                        miAnalisis.start();
     //--------------------------------------------------\\
            
            sleep = true; //Cambia para que ESTA hebra duerma.
            INDICE++;
            
            if(sleep){// SE va a dormir (ESTA HEBRA).
                esperar();
            }
        }
        mBoton.setText("INICIAR");
        mBoton.setStartColor(new Color(92, 136, 163));
        mCONTROL.setControl(1, true); //Guardar datos analisis.
        mCONTROL.setControl(2, true);
        miAnalisis.mi_bar.setValue(0);        
    }
    
    
    public void continuar(){
        if(!CONTROL)
            start();
        else{
            miAnalisis.despertar();
        }
    }
    public void start(){
            CONTROL = true;
            
            miHebra = new Thread(this);
            miHebra.start();
    }    
    public void stop(){
        CONTROL = false;
        despertar();
    }
    public synchronized void esperar(){
        try {
            wait();
        } catch (InterruptedException ex) {
            Logger.getLogger(jAnalisis.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    

    
    public synchronized void despertar(){
        try {
            sleep = false; //Cambia la variable que hace dormir a ESTA hebra.
            Thread.sleep(500);//Espero un tiempo para limpiar la memoria.
    
            notify();//DESPIERTA A ESTA HEBRA !!!. 
        } catch (InterruptedException ex) {
            Logger.getLogger(jExperimento.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    public void dormirUnrato(int rato){
       try {
           Thread.sleep(rato);
       } catch (InterruptedException ex) {
           Logger.getLogger(jExperimento.class.getName()).log(Level.SEVERE, null, ex);
       }
    }
    
    public boolean controlArchivos(String _direc){
        if(new File(_direc + "/roi_poly.txt").exists()){
            return(true);
        }else{
            return(false);
        }
    }
    
    /**
     * NO usado. Simplemente para pruebas internas.
     * @param _mensaje 
     */
    public void mensaje(Object _mensaje){
        System.out.println(_mensaje);
    }
    
}






