/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package PrincipalPaquete;

import Abrir_guardar.abrirObjeto;
import Abrir_guardar.guardarObjeto;
import Abrir_guardar.objetoGuardar;
import Abrir_guardar.objetoGuardar2;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.*;
import org.jfree.data.xy.XYDataset;

/**
 *
 * @author Felipe
 */
public class jPlot_Data implements Serializable{
    private jCONTROLES mCONTROL = null;
    
    TimeSeries series = null;
    TimeSeries serieBordes = null;
    TimeSeries serieLocDes = null;
    TimeSeries serieLoadBordes = null;
    TimeSeries serieLoadLDesv  = null;
    
    ChartPanel chartPanel = null;
    XYDataset dataset = null;
    
    XYPlot plot = null;
    XYLineAndShapeRenderer renderer = null;
    final TimeSeriesCollection datasett = new TimeSeriesCollection();

    int nSerie = 0; 
    int totalSeries = 0;
    int TotalColor = 1;
    int colorSerie = 0;
    
    public jPlot_Data(jCONTROLES _mControl){
        mCONTROL = _mControl;
        
        dataset = createDataSet();
        final JFreeChart chart = ChartFactory.createTimeSeriesChart(null,null, null,
            dataset,
            false,
            false,
            false );

        
        plot = (XYPlot)chart.getXYPlot();
        plot.getRangeAxis().setAutoRangeMinimumSize(10000);
        
        renderer = new XYLineAndShapeRenderer();
        plot.setRenderer(renderer);
        
        chartPanel = new ChartPanel(chart, true, true, true, false, true);
        chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
    }
    
    private XYDataset createDataSet(){
        series      = new TimeSeries("a1");
        serieBordes = new TimeSeries("a2");
        serieLocDes = new TimeSeries("a2");
        serieLoadBordes = new TimeSeries("a2");
        serieLoadLDesv  = new TimeSeries("a3");
        
        datasett.addSeries(series);
        datasett.addSeries(serieBordes);
        datasett.addSeries(serieLocDes);
        datasett.addSeries(serieLoadBordes);
        datasett.addSeries(serieLoadLDesv);
        
        return(datasett);
    }
    
    public XYDataset createMarcaTiempo(Date Inicio, long ranHor) {
        TimePeriodValues s1 = new TimePeriodValues("Series 1");
        TimePeriodValues s2 = new TimePeriodValues("Series 2");
        
        long tt = 1 * 60 * 60 * 1000; //Una hora en milisegundos.
        long td = 0;
        Date dt = new Date(Inicio.getTime());
        
        for(int i=1; i<10;i++){
            td = dt.getTime();
            s1.add(new SimpleTimePeriod(td, td+ranHor*tt), 180.00);
            s2.add(new SimpleTimePeriod(td+ranHor*tt, td+2*ranHor*tt), 180.00);
            
            dt.setTime(td + td+2*ranHor*tt); 
        }
        
        final TimePeriodValuesCollection dataset = new TimePeriodValuesCollection();
        dataset.addSeries(s1);
        dataset.addSeries(s2);
        return dataset;
    }
    
    
    public TimeSeries getSerie(int _tipo){
        switch(_tipo){
            case 0:
                return(serieBordes);
            case 1:
                return(serieLocDes);
        }
        return(null);
    }
    
    public ChartPanel getchartPanel(){
        return(chartPanel);
    }
    public void setData(Minute _min, double _bor, double _std){
        serieBordes.add(_min, _bor);
        serieLocDes.add(_min, _std);
    }    
    public void setNumSerie(int _nSerie){
        nSerie = _nSerie;
    }
    public void setTotalColor(int _TotalColor){
        TotalColor = _TotalColor;
    }
    public void setShapeActivar(boolean _control){
        renderer.setSeriesShapesVisible(0, _control);
        renderer.setSeriesShapesVisible(1, _control);
        renderer.setSeriesShapesVisible(2, _control);
        renderer.setSeriesShapesVisible(3, _control);
        renderer.setSeriesShapesVisible(4, _control);
    }
    public void setCurvaColor(int _nn){
        if(_nn < dataset.getSeriesCount()){
            for(int i=0; i < dataset.getSeriesCount(); i++)
                renderer.setSeriesPaint(i, Color.red);
            renderer.setSeriesPaint(_nn, Color.blue, true);
        }
    }
    public void setCurvaColor(int _id, Color _col){
        renderer.setSeriesPaint(_id, _col);
    }
    public void setViewCurvas(int _tipo) {
        switch(_tipo){
            case 0:
                renderer.setSeriesVisible(1, true);
                renderer.setSeriesVisible(2, false);
                renderer.setSeriesVisible(3, true);
                renderer.setSeriesVisible(4, false);                
                break;
            case 1:
                renderer.setSeriesVisible(1, false);
                renderer.setSeriesVisible(2, true);
                renderer.setSeriesVisible(3, false);
                renderer.setSeriesVisible(4, true);
                break;
            case 2:
                renderer.setSeriesVisible(1, false);
                renderer.setSeriesVisible(2, false);
                renderer.setSeriesVisible(3, true);
                renderer.setSeriesVisible(4, true);
                break;
        }
    }
    public void setRangoHoras(long _rangoTime){
        DateAxis axis = (DateAxis)plot.getDomainAxis();
        Date dt = axis.getMinimumDate();
        Date dmax = new Date(dt.getTime()+_rangoTime); 
        axis.setMaximumDate(dmax);
        
        ValueAxis ran = plot.getRangeAxis();
        ran.setRange(0, 10000);
    }
    public void setSeriesLuz(int rango){
    }
    
    public void GuadarSeries(String path, String name){     
        guardarObjeto gg;
        try {
            gg = new guardarObjeto(path + "//" + name);
            objetoGuardar miObjeto = new objetoGuardar(serieBordes, serieLocDes);
            gg.escribir(miObjeto);
            gg.cerrar();
        
        } catch (FileNotFoundException ex) {
            Logger.getLogger(jPlot_times.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(jPlot_times.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void AbrirSeries(String _path){
        resetData();
        try {
            objetoGuardar2 obb = new objetoGuardar2(null, null);
            abrirObjeto abrir = new abrirObjeto();
            abrir.abrir(_path + "//Serie_Datos.datt");
            
            obb = abrir.leer();
            serieLoadBordes.clear();
            serieLoadBordes.addAndOrUpdate(obb.getSerieBorde());
            serieLoadLDesv.clear();
            serieLoadLDesv.addAndOrUpdate(obb.getSerieStdLocal());

            for(int i=0; i<datasett.getSeriesCount(); i++){
                renderer.setSeriesShapesVisible(i, false);
            }
            
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(jPlot_times.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(jPlot_times.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void AbrirCadaSerie(String _path){
        try {
            objetoGuardar2 obb = new objetoGuardar2(null, null);
            abrirObjeto abrir = new abrirObjeto();
            abrir.abrir(_path);
            obb = abrir.leer();
            datasett.addSeries(obb.getSerieBorde());
            renderer.setSeriesShapesVisible(datasett.getSeriesCount()-1, false);
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(jPlot_times.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(jPlot_times.class.getName()).log(Level.SEVERE, null, ex);}
    }
    public void verCadaSerie(int _num, boolean _tipo){
        renderer.setSeriesVisible(_num, _tipo);
    }
    //Esto fijara la cantidad de horas que veremos.
    public void resetData(){
        series.clear();
        serieBordes.clear();
        serieLocDes.clear();
    }
    public void clearAllSeries(){
        datasett.removeAllSeries();
    }
    
    public void testVarios(Graphics2D gd){
        DateAxis axis = (DateAxis) plot.getDomainAxis();
        System.out.println(axis.getMinimumDate() + "  " + 
                axis.getMaximumDate().getTime());
        
        chartPanel.getChart().draw(gd, new Rectangle2D.Double(0, 0, 0.1, 1000));
                
    }
    //Este metodo setea todos los controles booleanos
    public void setControles(int _type, boolean _conA, boolean _conB){
        switch(_type){}
    }
}
