/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PrincipalPaquete;

import Abrir_guardar.objetoGuardar2;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Shape;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.*;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartMouseEvent;
import org.jfree.chart.ChartMouseListener;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.annotations.XYPointerAnnotation;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.event.PlotChangeListener;
import org.jfree.chart.labels.XYToolTipGenerator;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.Range;
import org.jfree.data.general.DatasetChangeEvent;
import org.jfree.data.general.DatasetChangeListener;
import org.jfree.data.time.*;
import org.jfree.data.xy.XYDataset;
import org.jfree.util.ShapeUtilities;

import org.jfree.chart.annotations.XYTextAnnotation;
import org.jfree.chart.plot.Marker;
import org.jfree.chart.plot.ValueMarker;
import org.jfree.date.SerialDate;
import org.jfree.ui.RectangleAnchor;
import org.jfree.ui.TextAnchor;

/**
 *
 * @author Felipe
 */
public class jPlot_times extends JLabel implements Serializable, Runnable, 
        ChartMouseListener{
    
    private jCONTROLES mCONTROL = null;{
    /* index  0 = Control de separacion de imagenes.
     * index  1 = Control TODO bien.
     * index  2 = Control de Inicio de analisis de datos.
     * index  3 = Control de graficas a mostrar.
     * index  4 = ...
     * index  5 = ...
     * index  6 = Control de eventos generales de ANALIZAR !.
     * index  7 = Control guardar data.
     * index 10 = Control ejecucion hebra de separación. Experimento completo.
     * index -- = ...
     * index 19 = ???
     * index 20 = Control hebra graficos.
    */
}
    private boolean    conBorde = true;
    private boolean    conStand = false;
    
    private boolean fNormal  = true;
    private boolean fSgolay  = false;
    private boolean conSca2  = false;
        
    public TimeSeries serieBordes = null;
    public TimeSeries serieLocDes = null;
    public TimeSeries serieLoadBordes = null;
    public TimeSeries serieLoadLDesv  = null;
    //Series filtradas....
    
    public TimeSeries lineCero = null;
    
    public ChartPanel chartPanel = null;
    public XYDataset  dataset    = null;
    
    private XYPlot plot = null;
    
    public XYLineAndShapeRenderer renderer   = null;
    public XYLineAndShapeRenderer renderBDS  = null;
    public XYLineAndShapeRenderer renderSTD  = null;
    public XYLineAndShapeRenderer renderSal  = null;
    public XYLineAndShapeRenderer rendMovBDS = null;
    public XYLineAndShapeRenderer rendMovSTD = null;
        
    public XYBarRenderer renderCicloLuz      = null;
    
    public TimeSeriesCollection dataGeneral = new TimeSeriesCollection();
    public TimeSeriesCollection datasetBDS  = new TimeSeriesCollection();
    public TimeSeriesCollection datasetSTD  = new TimeSeriesCollection();
    public TimeSeriesCollection dataSalida  = new TimeSeriesCollection(); //Marcadores de hora salida y punto inicio arrugamiento
    public TimeSeriesCollection dataMovBDS  = new TimeSeriesCollection();
    public TimeSeriesCollection dataMovSTD  = new TimeSeriesCollection();
    
    final double xx = new Day(14, SerialDate.DECEMBER, 2010).getMiddleMillisecond();
    public XYTextAnnotation serieNomb = new XYTextAnnotation(" MOSCA 000 ", 
            new Day().getMiddleMillisecond(), 10000.0);
    
    final XYPointerAnnotation pointer = new XYPointerAnnotation("Punto", xx, 163.0,
                                                                    3.0 * Math.PI / 4.0);
            
    int nSerie      =  0;
    int TotalColor  =  1;
    int cicloLuz    =  0;
    int horaCiclo   = 12;  //
    int ranPuntos   =  4;  //
    int tipoFiltro  =  0;
    int curvaColor  =  0;
    
    public  int UMBRAlGRAF = 100;
    private int INDEXtabla = 0;
    
    long RangoHora  = 10;  //
    long moverCurv  =  0;  //Desplazamiento de curvas.

    
    double[][] puntos   = new double [10][2];
    
    double scalaInf = -2000.0;
    double scalaSup = 20000.0;
    double ranCiclo =    50.0;
    
    public  Date dataleft    = null;
    public  Date dataright   = null; 
    public  Date horaReferen = new Date();
    public  Date horaRefInit = null;
    
    
    public  Shape      cross = new java.awt.geom.Ellipse2D.Double(0, -12, 0.8, 10.0);
    public  Shape     punto2 = new java.awt.geom.Ellipse2D.Double(0,0, 2.0, 2.0);
    
    public  JFreeChart chart = null;
    
    private JTable  mTabla      = null; //Tabla Graficos general
    private JTable  nTablaMover = null;
    
    private String jPathGraficos = "";    
    private String strinTemp     = ""; //String para uso varios. Temporal.
    private String[] lista       = null;
    
    
    private java.util.List listAnimales  = new LinkedList();
    private java.util.List listAnimalSTD = new LinkedList();
    
    
 // HEBRA de control, ejecucion de la carga           \\
        private boolean CONTROL = false;
        public  Thread  miHebra = null;
 // ------------------------------------------------- \\
    
    public jPlot_times(jCONTROLES _mControl){
        
        initComponents();
        mCONTROL = _mControl;
        dataset  = createDataSet();
        
        chart = ChartFactory.createTimeSeriesChart(null,null,
                null,
                dataset,
                false,
                false,
                false );
        plot = (XYPlot)chart.getXYPlot();
        plot.getRangeAxis().setAutoRangeMinimumSize(10000);
        
        renderer = new XYLineAndShapeRenderer();
        plot.setDataset(dataGeneral);
        plot.setRenderer(0, renderer);
        renderer.setSeriesPaint(0, Color.red);
        renderer.setSeriesPaint(1, Color.blue);
        renderer.setSeriesPaint(2, Color.red);
        renderer.setSeriesPaint(3, Color.blue);
        renderer.setSeriesPaint(4, Color.black);
        
        renderCicloLuz = new XYBarRenderer();
        plot.setDataset( 1, createCicloLuz(new Date(), 12));
        plot.setRenderer(1, renderCicloLuz);
        renderCicloLuz.setSeriesPaint(0, Color.BLACK);
        renderCicloLuz.setSeriesPaint(1, new Color(250, 250, 250));
        renderCicloLuz.setShadowVisible(false);
        renderCicloLuz.setBarPainter(new org.jfree.chart.renderer.xy.StandardXYBarPainter());
            renderCicloLuz.setSeriesVisible(0, false);
            renderCicloLuz.setSeriesVisible(1, false);
            
        
        renderSTD = new XYLineAndShapeRenderer();
        plot.setDataset( 2, datasetSTD);
        plot.setRenderer(2, renderSTD);
        
        renderBDS = new XYLineAndShapeRenderer();
        plot.setDataset( 3, datasetBDS);
        plot.setRenderer(3, renderBDS);
        
        renderSal = new XYLineAndShapeRenderer();
        plot.setDataset( 4, dataSalida);
        plot.setRenderer(4, renderSal);
        
        //Serie datos para Bordes.
        rendMovBDS = new XYLineAndShapeRenderer();
        plot.setDataset( 5, dataMovBDS);
        plot.setRenderer(5, rendMovBDS);
        
        //Serie datos para Standar Desviacion.
        rendMovSTD = new XYLineAndShapeRenderer();
        plot.setDataset( 6, dataMovSTD);
        plot.setRenderer(6, rendMovSTD);
        
        
        setShapeActivar(false);
        setEscalaPlot(scalaInf, scalaSup);
        setParamCurvaData(1, 0, false, false);
        
        chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
        
//        chartPanel.setMouseZoomable(true, false);
//        chartPanel.addChartMouseListener(this);
//        
        
        plot.addChangeListener(new PlotChangeListener() {
            public void plotChanged(PlotChangeEvent pce) {
                if(conSca2)return; //Control para no caer en loop-break
                
                Range rr = plot.getRangeAxis().getRange();
                if(new Double(rr.getLength()).isNaN()){
                    setEscalaPlot(scalaSup, scalaInf);
                    ranCiclo = 50.00;
                }else{
                    ranCiclo = rr.getLowerBound() + 0.01*(rr.getUpperBound()
                                            - rr.getLowerBound());
                }
                setCicloLuz(cicloLuz, RangoHora, horaCiclo);
            }});
        
        plot.addAnnotation(serieNomb);
        plot.addAnnotation(pointer);
                
        //   Modulo para agregar texto al momento de tener el mouse en una 
        //curva. En este caso, son los indicadores de hora de salida
        renderSal.setBaseToolTipGenerator(new XYToolTipGenerator() {
            public String generateToolTip(XYDataset xyd, int i, int i1) {
                return("Hola");
            }});

        dataleft  = ((DateAxis)plot.getDomainAxis()).getMinimumDate();
        dataright = ((DateAxis)plot.getDomainAxis()).getMaximumDate();
        
        renderer.setSeriesShapesVisible(4, false);
        renderer.setSeriesStroke(4, new BasicStroke(0.3f));
    }
    
      /**
     * PRINCIPALES CARACTERISTICAS DEL SISTEMA DE ANALISIS IMAGENES
     * Mètodo que da las caracterìsticas iniciales a mucho objetos internos a 
     * este objeto de anàlisis. Se carga sobretodo los objetos gràficos que se 
     * usaràn para desplegar informaciòn al usuario. Ademàs, se especifican las
     * funciones que "escuchan" (listeners) los eventos ocurridos sobre dichos
     * objetos gràficos.
     */
    public void initComponents() {
        super.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        super.setBounds(40, 40, 640, 480);
        
        //Evento hacia matlab.
        addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyPressed(java.awt.event.KeyEvent evt) {}});
       
        //Cambios en la serie General
        dataGeneral.addChangeListener(new DatasetChangeListener() {
            @Override
            public void datasetChanged(DatasetChangeEvent dce) {}});
        
        
        serieNomb.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 15));
        serieNomb.setPaint(new Color(0, 0, 0));
        serieNomb.setBackgroundPaint(Color.WHITE);
        
        pointer.setBaseRadius(45.0);
        pointer.setTipRadius(0.0);
        pointer.setFont(new java.awt.Font("SansSerif", java.awt.Font.BOLD, 15));
        pointer.setPaint(Color.black);
        pointer.setTextAnchor(TextAnchor.HALF_ASCENT_RIGHT);
        
    }
    
    public void setUIObjetos(JTable _mTabla, JTable _nTable){
        mTabla      = _mTabla;
        nTablaMover = _nTable;
    }
    
    private XYDataset createDataSet(){
        serieBordes = new TimeSeries("a1");
        serieLocDes = new TimeSeries("a2");
        serieLoadBordes = new TimeSeries("a3");
        serieLoadLDesv  = new TimeSeries("a4");
        
        lineCero = new TimeSeries("cero");
        
        dataGeneral.addSeries(serieBordes);
        dataGeneral.addSeries(serieLocDes);
        dataGeneral.addSeries(serieLoadBordes);
        dataGeneral.addSeries(serieLoadLDesv);
        dataGeneral.addSeries(lineCero); //Linea para comparar
        
        return(dataGeneral);
    }
    
    // --- METODOS "GET" --- \\
    public TimeSeries getSerie(int _tipo){
        switch(_tipo){
            case 0:
                return(serieBordes);
            case 1:
                return(serieLocDes);
        }
        return(null);
    } 
    public ChartPanel getchartPanel(){
        return(chartPanel);
    }
    public String getNameSerie(){
        String std = serieNomb.getText();
        return(std);
    }
   
     // --- METODOS "SET" --- \\
    public void setIndexV(int _ind){
        tipoFiltro = _ind;
        setControl(tipoFiltro);
    }
    public void setControl(int _ind){
        switch(_ind){
            case 0:
                conBorde = true;
                conStand = false;
                break;
            case 1:
                conBorde = false;
                conStand = true;
                break;
                
            //USADO PARA BORRADO DE TODAS LAS CURVAS    
            case 2:
                conBorde = true;
                conStand = true;
                break;
        }
    }
    public void setData(Minute _min, double _bor, double _std){
        serieBordes.add(_min, _bor);
        serieLocDes.add(_min, _std); 
    }
    public void setNumSerie(int _nSerie){
        nSerie = datasetBDS.getSeriesCount();
    }
    public void setNameSerie(String _std){
        serieNomb.setText(" " + _std + " ");
    }
    public void setViewNameSerie(boolean _ver){
        plot.removeAnnotation(serieNomb);
    }
            
    public void setTotalColor(int _TotalColor){
        TotalColor = _TotalColor;
    }
    public void setVerSeñalFiltro(int index){
        switch(index){
            case 0:
                fNormal  = true;
                fSgolay  = false;
                break;
            case 1:
                fNormal  = false;
                fSgolay  = true;
                break;
        }
    }
    public void setShapeActivar(boolean _control){
        renderer.setSeriesShapesVisible(0, _control);
        renderer.setSeriesShapesVisible(1, _control);
        renderer.setSeriesShapesVisible(2, _control);
        renderer.setSeriesShapesVisible(3, _control);
    }
    public void setTipoCurvaColor(int _tipo){
        curvaColor = _tipo;
    }
    public void setCurvaColor(String std, Color _col){
        boolean stdFolder = false;
        String stdIndex   = "";
        if(curvaColor == 1){
            if(fNormal) stdIndex = "f1d"; else stdIndex = "f2d";
        }
        if(curvaColor == 2){
            if(fNormal) stdIndex = "df1"; else stdIndex = "df2";
        }
        
        int dd = datasetBDS.getSeriesCount();
        for(int i=0; i < dd; i++){    
            //-------------- CAMBIO de BORDES --------------------------------\\
            stdFolder = datasetBDS.getSeries(i).getDescription().contains(std) && conBorde;
            if(stdFolder){
                if(datasetBDS.getSeries(i).getDescription().contains(stdIndex))
                    renderBDS.setSeriesPaint(i, _col);
            }
            
            //-------------- CAMBIO de DESVIACION --------------------------------\\
            stdFolder = datasetSTD.getSeries(i).getDescription().contains(std) && conStand;
            if(stdFolder){
                if(datasetSTD.getSeries(i).getDescription().contains(stdIndex))
                    renderSTD.setSeriesPaint(i, _col);
            }
        }
    }
    
    public void setCurvaColorDATA(String std, Color _col){
        boolean stdFolder = false;
        String stdIndex   = "";
        
        int dd = datasetBDS.getSeriesCount();
        for(int i=0; i < dd; i++){
            //-------------- CAMBIO de BORDES --------------------------------\\
            if(conBorde)
                if(datasetBDS.getSeries(i).getDescription().equalsIgnoreCase(std))
                        renderBDS.setSeriesPaint(i, _col);
            
            //-------------- CAMBIO de DESVIACION ----------------------------\\
            if(conStand)
                if(datasetSTD.getSeries(i).getDescription().equalsIgnoreCase(std))
                        renderSTD.setSeriesPaint(i, _col);
        }
    }
    public void setCurvaWidth(String std, float _width){
        int dd = datasetBDS.getSeriesCount();
        for(int i=0; i<dd; i++){
            if(conBorde){
                if(datasetBDS.getSeries(i).getDescription().equalsIgnoreCase(std))
                    renderBDS.setSeriesStroke(i, new BasicStroke(_width));
                else
                if(datasetBDS.getSeries(i).getDescription().equalsIgnoreCase("t"+std))
                    renderBDS.setSeriesStroke(i, new BasicStroke(_width));
                else
                    renderBDS.setSeriesStroke(i, new BasicStroke(1.0f));
            }
            else{
                if(datasetSTD.getSeries(i).getDescription().equalsIgnoreCase(std))
                    renderSTD.setSeriesStroke(i, new BasicStroke(_width));
                if(datasetSTD.getSeries(i).getDescription().equalsIgnoreCase("d"+std))
                    renderSTD.setSeriesStroke(i, new BasicStroke(_width));
            }
        }
    }
    public void setCurvaWithUmbral(String _std, Color _col){
        String  strd = "";
        Boolean bb   = false;
        for(int i=0; i<dataSalida.getSeriesCount(); i++){
            bb = (Boolean)mTabla.getValueAt(i, 2);
            
            if(!bb) //Si NO está marcada la serie, SIGUE
                continue;
            
            strd = dataSalida.getSeries(i).getDescription();
            
            if(strd.equalsIgnoreCase("df2" +  _std)){
                INDEXtabla = i;
                renderSal.setSeriesPaint(i, _col);
                renderSal.setSeriesShape(i, cross);
                
                renderSal.setSeriesVisible(i, true);
                renderSal.setSeriesShapesVisible(i, true);
            }else{
                renderSal.setSeriesPaint(i, Color.RED);
                renderSal.setSeriesShape(i, punto2);
                
                renderSal.setSeriesVisible(i, true);
                renderSal.setSeriesShapesVisible(i, true);
            }
        }
    }
    public void setTextPosition(double _dbX, double _dbY){
        double dLeft = plot.getDomainAxis().getRange().getLowerBound();
        double delta = plot.getDomainAxis().getRange().getLength();
        serieNomb.setX(dLeft + 0.92*delta);
        
        double dInf  = plot.getRangeAxis().getRange().getLowerBound();
        double dRang = plot.getRangeAxis().getRange().getLength();
        serieNomb.setY(dInf + 0.95*dRang);
        
    }
     
    public void setViewCurvas(int _tipo) {
        switch(_tipo){
            case 0:
                renderer.setSeriesVisible(0, true);
                renderer.setSeriesVisible(1, false);
                renderer.setSeriesVisible(2, true);
                renderer.setSeriesVisible(3, false);                
                break;
            case 1:
                renderer.setSeriesVisible(0, false);
                renderer.setSeriesVisible(1, true);
                renderer.setSeriesVisible(2, false);
                renderer.setSeriesVisible(3, true);
                break;
            case 2:
                renderer.setSeriesVisible(0, true);
                renderer.setSeriesVisible(1, true);
                renderer.setSeriesVisible(2, true);
                renderer.setSeriesVisible(3, true);
                break;
        }
    }
    public void setRangoHoras(long _rangoTime){
        //_rangoTime en HORAS (NO MILISEGUNDOS)
        long rangoTime = _rangoTime * 60*60*1000;
        DateAxis axis = (DateAxis)plot.getDomainAxis();
        
        dataleft  = axis.getMinimumDate();
        dataright = new Date(dataleft.getTime() + rangoTime);
        
        axis.setMaximumDate(dataright);
        plot.setDomainAxis(axis);
    }
    public void setEscalaPlot(double _inf, double _sup){
        ValueAxis ran = plot.getRangeAxis();
        ran.setRange(scalaInf, scalaSup);
    }
    
    public void setEscalaRangoTiempo(){
        DateAxis axis = (DateAxis)plot.getDomainAxis();
        Date _dt = axis.getMaximumDate();
        
        axis.setMinimumDate(horaRefInit);
        axis.setMaximumDate(_dt);
        
        plot.setDomainAxis(axis);
    }
    
    public void setCurrentMarker(Date _dt, boolean tipe){
        plot.clearDomainMarkers();
        
        final Marker currentEnd = new ValueMarker(_dt.getTime());    
        currentEnd.setPaint(Color.red);
        currentEnd.setLabel("");
        currentEnd.setLabelAnchor(RectangleAnchor.TOP_RIGHT);
        currentEnd.setLabelTextAnchor(TextAnchor.TOP_LEFT);
        
        plot.addDomainMarker(currentEnd);
    }
    
    public void setLineCero(){
        DateAxis axis = (DateAxis)plot.getDomainAxis();

        lineCero.clear();
        lineCero.add(new Minute(axis.getMinimumDate()), 0.0);
        lineCero.add(new Minute(axis.getMaximumDate()), 0.0);
    }
    public void setViewY_Range(boolean _view){
        ValueAxis ran = plot.getRangeAxis();
        ran.setVisible(_view);
    }
    public void setParamCicloLuz(int _ciclo, long _RangoHora, int _horaCiclo){
        cicloLuz  = _ciclo;
        RangoHora = _RangoHora;
        horaCiclo = _horaCiclo;
        setCicloLuz(_ciclo, _RangoHora, _horaCiclo);
    }
    public void setCicloLuz(int _ciclo, long _ranHor, int _hora){
        conSca2 = true; //close
        
        if(_ciclo != 0){
            renderCicloLuz.setSeriesPaint(0, Color.BLACK);
            renderCicloLuz.setSeriesPaint(1, new Color(250, 250, 250));
        }else{
            renderCicloLuz.setSeriesPaint(0, new Color(250, 250, 250));
            renderCicloLuz.setSeriesPaint(1, Color.BLACK);
        }
        
        horaReferen = new Date(horaReferen.getTime());
        Calendar calendar = GregorianCalendar.getInstance();
        calendar.setTime(horaReferen);
        
        calendar.set(calendar.get(Calendar.YEAR),
                     calendar.get(Calendar.MONTH),
                     calendar.get(Calendar.DATE),
                     _hora,
                     0);
        
        horaReferen = calendar.getTime();
        plot.setDataset( 1, createCicloLuz(horaReferen, _ranHor));
        plot.setRenderer(1, renderCicloLuz);
        
        setTextPosition(0, 0);
        
        conSca2 = false;//open
    }
    public void setVerCicloLuz(boolean _actv){
        renderCicloLuz.setSeriesVisible(0, _actv);
        renderCicloLuz.setSeriesVisible(1, _actv);
    }
    public void setRangosEjes(double _inf, double _sup){                
        scalaInf = _inf;
        scalaSup = _sup;
        setEscalaPlot(scalaInf, scalaSup);
    }
    public void setHoraInicioCicloLuz(){
        java.util.List list = datasetBDS.getSeries();
        long ld = -1;
        for(int i=0; i<list.size(); i++){
            TimeSeries tt = datasetBDS.getSeries(i);
            if(tt.getItemCount() > 0)
                if(tt.getDataItem(0).getPeriod().getStart().getTime() > ld)
                    ld = tt.getDataItem(0).getPeriod().getStart().getTime();
        }
        horaReferen = new Date(ld);
        plot.setDataset(1, createCicloLuz(horaReferen, 12));
    }
    public void setHoraDesplazamiento(int _val){
        moverCurv = (long)_val;
        moverSeries(_val);
    }
    /**
     * Metodo que fija la hora de referencia para crear los ciclos de luz y oscuridad.
     * @param _horaRef 
     */
    public void setHoraReferencia(Date _horaRef){
        horaReferen = _horaRef;
    }
    
    public void GuadarSeries(String _path, String _name, int _val){
        FileInputStream fileInput   = null;
        try {
            fileInput = new FileInputStream(_path + _name);
            HSSFWorkbook workbook = new HSSFWorkbook(fileInput);
            
            HSSFSheet workLocDes = workbook.getSheetAt(0);
            HSSFSheet workBordes = workbook.getSheetAt(1);
            
            limpiarSheet(workLocDes);          //LIMPIA AMBAS HOJAS, DE EXISTIR O NO
            limpiarSheet(workBordes);
            fileInput.close();
            
            int indC    = 4;
            Row row1    = null;
            Cell colum  = null;
            
            long tiempoPRIMERO = (long)workBordes.getRow(0).getCell(4).getNumericCellValue();
            
            if(tiempoPRIMERO == 0){
                HSSFSheet HojaTem = workBordes;
                for(int i=0; i<2; i++){
                    tiempoPRIMERO = horaRefInit.getTime();
                    HojaTem.getRow(0).getCell(4).setCellValue(tiempoPRIMERO);

                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                    String fechaInit = dateFormat.format(horaRefInit);
                    row1 = HojaTem.getRow(1);
                    row1.createCell(2).setCellValue(fechaInit);

                    dateFormat = new SimpleDateFormat("HH:mm:ss");
                    String  horaInit = dateFormat.format(horaRefInit);
                    row1 = HojaTem.getRow(2);
                    row1.createCell(2).setCellValue(horaInit);
                    
                    HojaTem = workLocDes;
                }
            }
            
            int  largoTotal    = serieBordes.getItemCount();
            for(int x = 2; x < (largoTotal + 2); x++){
                if(workBordes.getRow(x) == null)
                    row1    = workBordes.createRow(x);
                else
                    row1    = workBordes.getRow(x);
                
                if(row1.getCell(indC) == null)
                    colum = row1.createCell(indC);
                else
                    colum = row1.getCell(indC);
                
                long tdt = serieBordes.getDataItem(x-2).getPeriod().getFirstMillisecond();
                
                
        //  GUARDAR MINUTO DE LA IMAGEN IMPORTANTE para reconstruir GRAFICOS.    
                colum.setCellValue(Math.round((tdt - tiempoPRIMERO)/1000));
        //  ------------------------------------------------------  \\    
                
                if(row1.getCell(indC+1) == null)
                    colum = row1.createCell(indC+1);
                else
                    colum = row1.getCell(indC+1);            
                colum.setCellValue(serieBordes.getDataItem(x-2).getValue().doubleValue());
                
                
                if(workLocDes.getRow(x) == null)
                    row1    = workLocDes.createRow(x);
                else
                    row1    = workLocDes.getRow(x);
                
                
                if(row1.getCell(indC) == null)
                    colum = row1.createCell(indC);
                else
                    colum = row1.getCell(indC);
                colum.setCellValue(Math.round((tdt - tiempoPRIMERO)/1000));
                
                if(row1.getCell(indC+1) == null)
                    colum = row1.createCell(indC+1);
                else
                    colum = row1.getCell(indC+1);
                
                colum.setCellValue(serieLocDes.getDataItem(x-2).getValue().doubleValue());
            }
            
            
            //Guardo el tiempo primero.
            row1  = workBordes.createRow(0);
            colum = row1.createCell(4);
            colum.setCellValue(tiempoPRIMERO);
            
            //Guardo el tiempo primero.
            row1  = workLocDes.createRow(0);
            colum = row1.createCell(4);
            colum.setCellValue(tiempoPRIMERO);
            
            
            FileOutputStream out = new FileOutputStream(_path + "//" + _name);
            workbook.write(out);
            out.close();
            
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void limpiarSheet(HSSFSheet _hoja){
        for(int x = 2; x<500; x++){
            Row rro = null;
            if(_hoja.getRow(x) != null){
                    rro = _hoja.getRow(x);
                    
                    for(int y=4; y<20; y++){
                        Cell cellA1 = rro.getCell(y);
                        if(cellA1 != null)
                            rro.removeCell(cellA1);
                    }
                }
            }
    }
    
    public void filtrosPython(String _path, int _val){
        String s;
            
        File fDp = new File(_path);
        
        Process p;
        ProcessBuilder pb;
        try {
            String[] command = {"python" ,"xlspython.py", fDp.getAbsolutePath()};
            
            pb = new ProcessBuilder(command);
            p  = pb.start();
            
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(p.getInputStream()));
            
            BufferedReader stdError = new BufferedReader(
                    new InputStreamReader(p.getErrorStream()));
            
            while ((s = br.readLine()) != null){
                mensaje(s);
            }
            
            while ((s = stdError.readLine()) != null) {
                mensaje("Error..." + s);
            }
            
            p.waitFor();
            p.destroy();
            
            mCONTROL.setControl(1, true);
            
        } catch (Exception e) {
            mCONTROL.setControl(1, false);
            
        }
    }
    public void AbrirSeries(objetoGuardar2 _obb){
        resetData();
        
        serieLoadBordes.clear();
        serieLoadBordes.addAndOrUpdate(_obb.getSerieBorde());
        serieLoadLDesv.clear();
        serieLoadLDesv.addAndOrUpdate(_obb.getSerieStdLocal());
        
        plot.setDataset(1, createCicloLuz(
                new Date(serieLoadBordes.getDataItem(0).getPeriod()
                .getStart().getTime()), 12));
        
        for(int i=0; i < dataGeneral.getSeriesCount(); i++){
            renderer.setSeriesShapesVisible(i, false);
        }
    }
    
    public void verSerieUmbral(String _std, boolean _tip){
        String strd = "";
        
        for(int i=0; i<dataSalida.getSeriesCount(); i++){
            strd = dataSalida.getSeries(i).getDescription();
            if(strd.equalsIgnoreCase("df2" +  _std)){
                renderSal.setSeriesVisible(i, _tip);
                renderSal.setSeriesShapesVisible(i, _tip);
            }
        }
    }
    
    public void verCadaSerie(String _name, boolean _tipo){
        for(int i=0; i<datasetBDS.getSeriesCount(); i++){
            if(datasetBDS.getSeries(i).getDescription().equalsIgnoreCase(_name)){
                renderBDS.setSeriesVisible(i, _tipo && conBorde);
            }
            if(datasetBDS.getSeries(i).getDescription().equalsIgnoreCase("f1d"+_name)){
                renderBDS.setSeriesVisible(i, _tipo && fNormal && conBorde);
            }
            if(datasetBDS.getSeries(i).getDescription().equalsIgnoreCase("df1"+_name)){
                renderBDS.setSeriesVisible(i, _tipo && fNormal && conBorde);
            }
            if(datasetBDS.getSeries(i).getDescription().equalsIgnoreCase("f2d"+_name)){
                renderBDS.setSeriesVisible(i, _tipo && fSgolay && conBorde);
            }
            if(datasetBDS.getSeries(i).getDescription().equalsIgnoreCase("df2"+_name)){
                renderBDS.setSeriesVisible(i, _tipo && fSgolay && conBorde);
            }
        }
        
        for(int i=0; i<datasetSTD.getSeriesCount(); i++){
            if(datasetSTD.getSeries(i).getDescription().equalsIgnoreCase(_name)){
                renderSTD.setSeriesVisible(i, _tipo && conStand);
            }
            if(datasetSTD.getSeries(i).getDescription().equalsIgnoreCase("f1d"+_name)){
                renderSTD.setSeriesVisible(i, _tipo && fNormal && conStand);
            }
            if(datasetSTD.getSeries(i).getDescription().equalsIgnoreCase("df1"+_name)){
                renderSTD.setSeriesVisible(i, _tipo && fNormal && conStand);
            }
            if(datasetSTD.getSeries(i).getDescription().equalsIgnoreCase("f2d"+_name)){
                renderSTD.setSeriesVisible(i, _tipo && fSgolay && conStand);
            }
            if(datasetSTD.getSeries(i).getDescription().equalsIgnoreCase("df2"+_name)){
                renderSTD.setSeriesVisible(i, _tipo && fSgolay && conStand);
            }
        }

    }
    //Sera para crear una lista de las curvas que quiero mover
    public void crearLista(boolean  bl, String _name){
        if(listAnimales.isEmpty() && !bl) return;
        
        for(int i=0; i<datasetBDS.getSeriesCount(); i++){
            if(datasetBDS.getSeries(i).getDescription().equalsIgnoreCase(_name)){
                if(bl)
                    listAnimales.add(i);
                else{
                    int td = listAnimales.indexOf(i);
                    if(td > -1)
                        listAnimales.remove(td);
                }}}
    }
    
    /**
     * Metodo que mueve las curvas indicadas por usuario, guardadas en la 
    variabler: 'listAnimales'.
    */
    public void moverSeries(int _valor){
        dataMovBDS.removeAllSeries();
        for(int i=0; i<listAnimales.size();i++){
            int ii = Integer.parseInt(listAnimales.get(i).toString()); 
            TimeSeries tm = datasetBDS.getSeries(ii);
            TimeSeries td = new TimeSeries("z1");
            
            for(int j=0; j<tm.getItemCount();j++){
                Date dt = tm.getTimePeriod(j).getStart();
                long vd = dt.getTime() + (long)_valor;
                td.add(new Minute(new Date(vd)), tm.getValue(j));
            }
            
            dataMovBDS.addSeries(td);
            rendMovBDS.setSeriesVisible(i, true);
            rendMovBDS.setSeriesShapesVisible(i, false);
            rendMovBDS.setSeriesPaint(i, renderBDS.getSeriesPaint(ii));

            renderBDS.setSeriesVisible(ii, false);
        }
    }
    public void moverSeriesSTD(int _valor){
        _valor = _valor * 60 * 60 * 100;
        dataMovSTD.removeAllSeries();
        
        for(int i=0; i<listAnimalSTD.size();i++){
            int ii = Integer.parseInt(listAnimalSTD.get(i).toString()); 
            TimeSeries tm = datasetSTD.getSeries(ii);
            TimeSeries td = new TimeSeries("z1");
            
            for(int j=0; j<tm.getItemCount();j++){
                Date dt = tm.getTimePeriod(j).getStart();
                long vd = dt.getTime() + (long)_valor;
                td.add(new Minute(new Date(vd)), tm.getValue(j));
            }
            dataMovSTD.addSeries(td);
            
            rendMovSTD.setSeriesVisible(i, true);
            rendMovSTD.setSeriesShapesVisible(i, false);
            
            renderSTD.setSeriesVisible(ii, false);
        }
    }
    public void limpiarSeriesMovimiento(){
        dataMovBDS.removeAllSeries();
        dataMovSTD.removeAllSeries();
    }
    
    public XYDataset createCicloLuz(Date Inicio, long ranHor){
        TimePeriodValues s1 = new TimePeriodValues("Series 1");
        TimePeriodValues s2 = new TimePeriodValues("Series 2");
        
        long tt = 1 * 60 * 60 * 1000; //Una hora en milisegundos.
        long td = 0;
        Date dateReferencia = new Date(Inicio.getTime());
        
        for(int i=1; i<5;i++){
            td = dateReferencia.getTime();
            s1.add(new SimpleTimePeriod(td, td+ranHor*tt), ranCiclo);
            s2.add(new SimpleTimePeriod(td+ranHor*tt, td+2*ranHor*tt), ranCiclo);
            dateReferencia.setTime(td+2*ranHor*tt);
        }
        final TimePeriodValuesCollection dataset = new TimePeriodValuesCollection();
        dataset.addSeries(s1);
        dataset.addSeries(s2);
        return(dataset);
    }
    //Esto fijara la cantidad de horas que veremos.
    public void resetData(){
        serieBordes.clear();
        serieLocDes.clear();
        serieLoadBordes.clear();
        serieLoadLDesv.clear();
    }
    public void clearAllSeries(){
        datasetBDS.removeAllSeries();
        datasetSTD.removeAllSeries();
        dataSalida.removeAllSeries();
    }

    // EVENTOS MOUSE SOBRE EL PANEL-/-GRAFICOS.
    
    /**
     *   Este metodo, ejecuta los requerimientos de un click del mouse sobre el 
     * Chart (Grafico principal).
     * Es un metodo desarrollado por mi, y NO parte de la implementacion de una 
     * INTERFACE.
     */
    public void mysetMouseClicker(double tiempoClick, JPanel _panel){
        
        int mouseY = -1;
        int mouseX = -1;
        double witth = -1;
        double hight = -1;
        
        Date mDat = new Date(new Double(tiempoClick).longValue());
        positionMaker_InSerie(new Double(tiempoClick).longValue(), 0); //- POSICIONAR EL MARCADOR -\\

    }
    
    
    public void calcTramos(JTable tabla){ 
        DefaultTableModel model = (DefaultTableModel)tabla.getModel();
        model.setNumRows(0);
        
        for(int i=0; i < serieBordes.getItemCount()-1; i++){
            model.insertRow(i, new Object[]{"", "", "", "", "", ""});
            
            long t2 = serieBordes.getTimePeriod(i+1).getStart().getTime(); 
            long t1 = serieBordes.getTimePeriod(i).getStart().getTime();
            double t3 = Math.round((double)(100*(t2 - t1)) 
                    / (double)(60*60*1000)) / 100.0;
            
            double dY = puntos[i+1][1] - puntos[i][1];
            double dX = puntos[i+1][0] - puntos[i][0];
            double pend = dY / dX;
            
            tabla.setValueAt(Integer.toString(i+1), i, 0);
            tabla.setValueAt(Double.toString(Math.round(pend * 100) / 100.0), i, 1);
            tabla.setValueAt(Double.toString(Math.round(Math.toDegrees(Math.atan(pend))*100)/100.0), i, 2);
            
            tabla.setValueAt(Double.toString(t3), i, 3);
            tabla.setValueAt(serieBordes.getTimePeriod(i).toString().substring(8, 16), i,  4);
            tabla.setValueAt(serieBordes.getTimePeriod(i+1).toString().substring(8, 16), i, 5);
        }
    }
    
    /**
     * Entrega parametros para calcular las diferencias segun la cantidad de puntos.
     * @param i
     * @param _rango
     * @param _a
     * @param _b 
     */
    public void setParamCurvaData(int i, int _rango, boolean _a, boolean _b){
        switch(i){
            case 0:
                serieBordes.clear();
                break;
            case 1:
                renderer.setSeriesVisible(0, _a);
                renderer.setSeriesShapesVisible(0, true);
                renderer.setSeriesShape(0, ShapeUtilities.createDiamond(2.5f));
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                ranPuntos = _rango;
                break;
        }
    }
    
    public Color generarColor(){
        double dd = Math.round(80*Math.random());
        
        Color newCol = new Color(0,(int)dd , 255);
        return(newCol);
    }
    public Color generarColorData(){
        double dd = Math.round(80*Math.random());
        
        Color newCol = new Color(255, (int)dd, 0);
        return(newCol);
    }
    
    
    public void stop(){
        CONTROL = false;
    }
    public synchronized void DORMIR(){
        try {
            wait();
        } catch (InterruptedException ex) {
            Logger.getLogger(jPlot_times.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public synchronized void despertar(){
        notify();
    }
    
    //  SECTOR DE HEBRA. PARA PODER CARGAR DATA     \\
    public void starrt(String _pathDir){
        CONTROL = true;
        jPathGraficos = _pathDir;
        
        miHebra = new Thread(this);
        miHebra.start();
    }
    
    /**
     * CUERPO DE LA HEBRA.... Para visualizar los graficos.
     */
    public  void run() {        
        int indice = 0;
        String descriptor = "";
        
        lista = new File(jPathGraficos).list(new MyFilter(".xls"));        
        
        DefaultTableModel model  = (DefaultTableModel)mTabla.getModel();
        DefaultTableModel modMov = (DefaultTableModel)nTablaMover.getModel();
        
        clearAllSeries();  //LIMPIO TODAS LAS SERIES DE DATOS
        
        model.setNumRows(0);
        modMov.setNumRows(0);
        
        if(lista.length == 0)
            CONTROL = false;
        
        while(CONTROL){
            if(lista.length > 0){
                
                String nameFile = jPathGraficos + "/" + lista[indice];
                File ff = new File(nameFile);
                
                int index = -1;
                if(ff.exists()){
                    
        //      ElEMENTO MUY IMPORTANTE, YA QUE DEFINE QUE SE TOMARA DE EXCELL   \\        
                    index = AbrirCadaSerie(ff);
        //  ==============================================================  \\        
                    
                    if(index == 0){
                        // ANALISIS - PARA - DETECTAR-PUNTOS  //
                        descriptor = ff.getName().substring(5, 8);
                        
                        model.insertRow(mTabla.getRowCount(), new Object[]{"", "", false});
                        mTabla.setValueAt(strinTemp, mTabla.getRowCount()-1, 0);
                        mTabla.setValueAt(descriptor, mTabla.getRowCount()-1, 1);
                        
                        modMov.insertRow(nTablaMover.getRowCount(), new Object[]{"", ""});
                        nTablaMover.setValueAt(descriptor, nTablaMover.getRowCount()-1, 1);
                        
                //--------------------------------------------------------------\\
                        setControl(2); //Para apagar todo
                        verCadaSerie(descriptor, false);           //Apago la serie
                        setCurvaColor(descriptor, generarColor()); //Al descriptor asigno color random
                        
                        setCurvaColorDATA(descriptor, generarColorData());
                        
                        setControl(tipoFiltro); //Vuelvo al tipo Original
                //--------------------------------------------------------------\\
                    }
                }
                indice++;
            }
            if(indice >= lista.length){
                CONTROL = false;
                mCONTROL.setControl(3, true);
                
        //  --- MOSTRAR LA PRIMERA --- \\
                verCadaSerie((String)mTabla.getValueAt(0, 1), true);
                mTabla.setValueAt(true, 0, 2);
                
                setHoraInicioCicloLuz();
                setLineCero();
                
                setTextPosition(0, 0);
                /**------------------------------------------------------  
                 * TERMINADO DE CARGAR Y ADAPTAR CURVAS, SE ANALIZA 
                 * LOS MOMENTOS ADECUADOS. */ 
                ANALISIS_y_DETECCION("df2", 0); //OJO, llama con 0, para borrar toda la Lista.
            }
        }
        
    }
    
    /**
     * METODO ENCARGADO DE TOMAR LOS DATOS DESDE LOS EXCEL'S. TOMA UNA O 
     * AMBAS HOJAS DESDE EL ARCHIVO EXCEL INDICADO.
     * @param _path
     * @return 
     */
    public   int AbrirCadaSerie(File _path){
        int ret = -1;
        String _name = _path.getName();
        
        FileInputStream fileInput = null;
        try {
            fileInput = new FileInputStream(_path);
            HSSFWorkbook workbook = new HSSFWorkbook(fileInput);
   
            int indd = workbook.getNumberOfSheets();
            
            if(indd > 1){ // Entra si tiene ambas hojas: Bordes y Desviacion
                HSSFSheet workStandar = workbook.getSheetAt(0);
                    crearSerieDataset(_name.substring(5, 8), workStandar, datasetSTD, renderSTD);
                HSSFSheet workBordes  = workbook.getSheetAt(1);
                    crearSerieDataset(_name.substring(5, 8), workBordes, datasetBDS, renderBDS);
                    
            }else{// Solo si tiene una hoja: Bordes o Desviacion    
                HSSFSheet workStandar = workbook.getSheetAt(0);
                crearSerieDataset(_name.substring(5, 8), workStandar, datasetSTD, renderSTD);
                crearSerieDataset(_name.substring(5, 8), workStandar, datasetBDS, renderBDS);
            }
            fileInput.close();
            
            
            
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(jPlot_times.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(jPlot_times.class.getName()).log(Level.SEVERE, null, ex);
        }
        return(0);
    }
    
    public int crearSerieDataset(String _name, HSSFSheet _HojaData,
                            TimeSeriesCollection _col, XYLineAndShapeRenderer _ren){
        
        TimeSeries dSerie = new TimeSeries("a1");     //nombre sin letra inicial
        
        TimeSeries f1Serie = new TimeSeries("f1");    //nombre sin letra inicial
        TimeSeries difSer  = new TimeSeries("difA1"); //OJO, que viene con la letra inicial d ó f
        
        TimeSeries f2Serie = new TimeSeries("f2");    //nombre sin letra inicial
        TimeSeries difSer2 = new TimeSeries("difA2")    ; //OJO, que viene con la letra inicial d ó f
        
        dSerie.setDescription(_name);
        
        f1Serie.setDescription("f1d"+_name);
        difSer.setDescription("df1"+ _name);
        
        f2Serie.setDescription("f2d"+_name);
        difSer2.setDescription("df2"+ _name);
        
        double min   = 0.0;
        long   tCero = 0L;    //Este numero es para construir la fecha-hora del experimento
        Row    row   = null;  //FILA QUE MANEJA TODO.
        
        row = _HojaData.getRow(0); //Tiempo de control, para las series temporales
        if(row == null) return(-1);
        
        if(row.getCell(4) == null)
            tCero = 0L;
        else{
            tCero = (long)row.getCell(4).getNumericCellValue();
            horaRefInit = new Date(tCero);
            setCurrentMarker(horaRefInit, true);
        }
        

        int rango = _HojaData.getLastRowNum()+1;
        for(int i = 2; i < rango; i++){
            row = _HojaData.getRow(i);
            
            min = row.getCell(4).getNumericCellValue() * 1000; //Se Amplifica por 1000
            Date dat = new Date(tCero + (long)min);
            
            dSerie.add(new Minute(dat),  row.getCell(5).getNumericCellValue());  //DATA
            
            f1Serie.add(new Minute(dat), row.getCell( 6).getNumericCellValue()); //Filtro 5 ptos.
             difSer.add(new Minute(dat), row.getCell( 7).getNumericCellValue()); //DIFERENCIA 5ptos.
            
            f2Serie.add(new Minute(dat), row.getCell( 9).getNumericCellValue()); //FiltroRuso
            difSer2.add(new Minute(dat), row.getCell(10).getNumericCellValue()); //DIFERENCIA FiltroRuso
        }
        
        _col.addSeries(dSerie);
        _ren.setSeriesShapesVisible(_col.getSeriesCount()-1, false);
        
        _col.addSeries(f1Serie);
        _ren.setSeriesShapesVisible(_col.getSeriesCount()-1, false);
        _col.addSeries(difSer);
        _ren.setSeriesShapesVisible(_col.getSeriesCount()-1, false);
        
        _col.addSeries(f2Serie);
        _ren.setSeriesShapesVisible(_col.getSeriesCount()-1, false);
        _col.addSeries(difSer2);
        _ren.setSeriesShapesVisible(_col.getSeriesCount()-1, false);
        
        return(0);
    }
    
    public int ANALISIS_y_DETECCION(String _std, int bd){
        int rango = 5;
        int tdt   = 0;
        
        dataSalida.removeAllSeries();
        
        TimeSeries temSerie = null;
        for(int i=0; i<datasetBDS.getSeriesCount(); i++) {
            String STRD = datasetBDS.getSeries(i).getDescription();
            //"df2" define el indicador de las series de diferencia
            if(STRD.toLowerCase().contains(_std.toLowerCase())){
                temSerie = datasetBDS.getSeries(i);
                
                TimeSeries dSerie = ANALISIS_SECCION(temSerie, UMBRAlGRAF, rango);
                dataSalida.addSeries(dSerie); //Se adiere la serie
                
                renderSal.setSeriesShape(dataSalida.getSeriesCount()-1, punto2);
                renderSal.setSeriesPaint(dataSalida.getSeriesCount()-1, Color.RED);
                renderSal.setSeriesVisible(dataSalida.getSeriesCount()-1, false);
                renderSal.setSeriesShapesVisible(dataSalida.getSeriesCount()-1, false);
                renderSal.setSeriesLinesVisible(dataSalida.getSeriesCount()-1, false);
            }
        }
        return(0);
    }
    
    public int positionMaker_InSerie(long _time, double _yy){
        long dxTem = _time;
        int  dxInd = -1;
        String std = serieNomb.getText().substring(7, 10);
        
        for(int i=0; i<dataSalida.getSeriesCount(); i++){
            if(renderSal.getSeriesVisible(i)){
                int id = dataSalida.getSeries(i).getDescription().
                                        substring(3, 6).
                                            compareToIgnoreCase(std);
                if(id == 0){
                    TimeSeries tSerie = dataSalida.getSeries(i);
                    for(int j=0; j<tSerie.getItemCount(); j++){
                        if(Math.abs(_time - tSerie.getTimePeriod(j).getFirstMillisecond()) < dxTem){
                            dxTem = Math.abs(_time - tSerie.getTimePeriod(j).getFirstMillisecond());
                            dxInd = j;
                        }
                    }
                    
                //-------- INDICADOR-FIJACION ----------------------------------\\
                    double dt = 0.2 * Math.random() - 0.1;
                    pointer.setAngle(3.5 + dt);
                    pointer.setX(tSerie.getTimePeriod(dxInd).getFirstMillisecond());
                    pointer.setY(tSerie.getValue(dxInd).doubleValue());
                //--------------------------------------------------------------\\        
                    
                    String stIme = tSerie.getTimePeriod(dxInd).toString().
                            substring(8, 19);
                    
                    nTablaMover.setValueAt(stIme, INDEXtabla, 0);  //INDICO EN LA TABLA 2
                }
            }
        }
        return(0);
    }

    private int posicionSERIES(String _std, TimeSeriesCollection _colect){
        int dd = -1;
        for(int i=0; i<_colect.getSeriesCount(); i++)
            if(_colect.getSeries(i).getDescription().compareToIgnoreCase(_std) == 0){
                dd = i;
                break;
            }
        
        return(dd);
    }
    
    private TimeSeries ANALISIS_SECCION(TimeSeries tSerie,int _umbral, int _segmento){
        int segm   = _segmento;
        int umBral = _umbral;
        int sSegm  =  0;  //Int control de cantidad
        long Tdt   = -1;
        
        TimeSeries d_Serie = new TimeSeries("");
        d_Serie.setDescription(tSerie.getDescription()); //Igual nombre a la serie salida
        
        for (int i=2; i < tSerie.getItemCount() - 2; i++){
            Tdt = tSerie.getTimePeriod(i).getFirstMillisecond();
            
            if(Math.abs(Tdt - tSerie.getTimePeriod(i-2).getFirstMillisecond()) == 1440000)
                if(tSerie.getValue(i-2).intValue() > umBral) sSegm++;
            if(Math.abs(Tdt - tSerie.getTimePeriod(i-1).getFirstMillisecond()) == 720000)
                if(tSerie.getValue(i-1).intValue() > umBral) sSegm++;
            
            if(tSerie.getValue( i ).intValue() > umBral) 
                        sSegm++;
            
            if(Math.abs(Tdt - tSerie.getTimePeriod(i+1).getFirstMillisecond()) == 720000)
                if(tSerie.getValue(i+1).intValue() > umBral) sSegm++;
            if(Math.abs(Tdt - tSerie.getTimePeriod(i+2).getFirstMillisecond()) == 1440000)
                if(tSerie.getValue(i+2).intValue() > umBral) sSegm++;
            
            if(sSegm >= 3)
                d_Serie.add(tSerie.getTimePeriod(i), 1000);
            
            sSegm = 0;
        }
        
        return(d_Serie);
    }
    
    public  void timEspera(long _time){
        try {
            Thread.sleep(_time);
        } catch (InterruptedException ex) {
            Logger.getLogger(jPlot_times.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void mensaje(Object _mensaje){
        System.out.println(_mensaje);
    }
    public String findInList(String _name){
        if(lista.length > 0){
            for(int i=0;i<lista.length;i++)
                if(lista[i].contains(_name))
                    return(lista[i]);
        }
        return("");
    }

    @Override
    public void chartMouseClicked(ChartMouseEvent cme) {
        
        int mouseX = cme.getTrigger().getX();
        int mouseY = cme.getTrigger().getY();
        mensaje(mouseX + "   " + mouseY);
        
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void chartMouseMoved(ChartMouseEvent cme) {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}






//    RESALTA LAS SERIES...
//    public void resaltarSerie(String _name){
//        for(int i=0; i<datasetBDS.getSeriesCount(); i++){
//            if(datasetBDS.getSeries(i).getDescription().equalsIgnoreCase(_name)){
//                renderBDS.setSeriesShapesVisible(i, true);
//            }else
//                renderBDS.setSeriesShapesVisible(i, false);
//
//        }
//        this.repaint();
//    }


//                strinTemp = obb.getGenotipe() + " " + obb.getHoraColect();
//                dataSalida.addSeries(tSerie);
//                renderSal.setSeriesShape(dataSalida.getSeriesCount()-1, cross);
//                renderSal.setSeriesPaint(dataSalida.getSeriesCount()-1, Color.red);
//                renderSal.setSeriesShapesVisible(dataSalida.getSeriesCount()-1, false);
                
                //Cargo Serie Bordes
//                obb.getSerieBorde().setDescription(std);
//                obb.getSerieStdLocal().setDescription(std);
                
                //Cargo ambas series, std y bordes
//                datasetBDS.addSeries(tSerie);
//                renderBDS.setSeriesShapesVisible(datasetBDS.getSeriesCount()-1, false);
//                datasetSTD.addSeries(tSerie);
//                renderSTD.setSeriesShapesVisible(datasetSTD.getSeriesCount()-1, false);

    
    /**
     * Captura de los puntos que permiten determinar las caracteristicas de tiempo.
     * @param cme 
     */
//    public void chartMouseClicked(ChartMouseEvent cme) {
//        int mouseY = -1;
//        int mouseX = -1;
//        double witth = -1;
//        double hight = -1;
//        
//        if(!renderer.getSeriesVisible(0)){ return; }
//        
//        if(cme.getEntity().getArea()instanceof java.awt.Rectangle){            
//            mouseX = cme.getTrigger().getX() - cme.getEntity().getArea().getBounds().x;
//            mouseY = cme.getEntity().getArea().getBounds().height - 
//                    (cme.getTrigger().getY() - cme.getEntity().getArea().getBounds().y);
//            
//            witth  = cme.getEntity().getArea().getBounds().getWidth();
//            hight  = cme.getEntity().getArea().getBounds().getHeight();
//            
//            NumberAxis numberAxis = (NumberAxis)plot.getRangeAxis();
//            Range rY = numberAxis.getRange();
//            double dSup = rY.getUpperBound();
//            double dInf = rY.getLowerBound();
//            double valY = dInf + mouseY * ((dSup - dInf) / hight);
//            
//            DateAxis axis = (DateAxis)plot.getDomainAxis();
//            Range rr      = axis.getRange();
//            long dMin = axis.getMinimumDate().getTime();
//            long dMax = axis.getMaximumDate().getTime();
//            long val  = (long) (dMin + (long)mouseX * ((dMax - dMin) / witth));
//            Date dDate = new Date(val);
//            
//            //ADIERO EL DATO...
//            if(serieBordes.getItems().size() < ranPuntos){
//                serieBordes.addOrUpdate(new Minute(dDate), valY);
//            }
//            else{
//                Iterator cd = serieBordes.getTimePeriods().iterator();
//                while(cd.hasNext()){
//                    RegularTimePeriod td = (RegularTimePeriod)cd.next();
//                    long dif = Math.abs(td.getStart().getTime() - dDate.getTime());
//                    if(dif < 5){}
//                }}}
//    }
    

//    public int ANALISIS_y_DETECCION(String _std, int bd){
//        int rango = 5;
//        int tdt   = 0;
//        
//        if(bd == 0)
//            dataSalida.removeAllSeries();
//        else{
//            int id = posicionSERIES(_std, dataSalida);
//            dataSalida.removeSeries(dataSalida.getSeries(id));
//        }
//        
//        for(int i=0; i<datasetBDS.getSeriesCount(); i++) {
//            String STRD = datasetBDS.getSeries(i).getDescription();
//            //"df2" define el indicador de las series de diferencia
//            if(STRD.toLowerCase().contains(_std.toLowerCase())){
//                TimeSeries temSerie = datasetBDS.getSeries(i);
//                
//                TimeSeries dSerie = ANALISIS_SECCION(temSerie, UMBRAlGRAF, rango);
//                
//                dataSalida.addSeries(dSerie); //Se adiere la serie
//                
//                renderSal.setSeriesShape(dataSalida.getSeriesCount()-1, punto2);
//                renderSal.setSeriesPaint(dataSalida.getSeriesCount()-1, Color.RED);
//                renderSal.setSeriesVisible(dataSalida.getSeriesCount()-1, false);
//                renderSal.setSeriesShapesVisible(dataSalida.getSeriesCount()-1, false);
//                renderSal.setSeriesLinesVisible(dataSalida.getSeriesCount()-1, false);
//            }
//        }
//                
//        return(0);
//    }