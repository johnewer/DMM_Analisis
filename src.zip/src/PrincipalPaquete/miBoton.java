package PrincipalPaquete;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.RenderingHints;
import java.awt.Shape;
import javax.swing.*;
//import org.jvnet.substance.skin.NebulaSkin;


public class miBoton extends JButton {
	private Color COLOR1 = new Color(255, 255, 255);
	private Color COLOR2 = new Color(82, 82, 82);
	private float pct;
	private String style = "round";
	private static final int OUTER_BEVEL_SIZE = 2;
	private int size;
	private Color color;
	private Color pressedColor;
	private Color overColor;
	private Color selectedColor;

	public miBoton() {
		super();
                setPreferredSize(new Dimension(80, 80));
		color = new Color(82, 82, 82);
		pressedColor = new Color(161, 64, 0);
		overColor = new Color(115, 201, 29);
		selectedColor = pressedColor;
		setContentAreaFilled(false);
		setBorderPainted(false);
		setFocusable(false);
		setPreferredSize(new Dimension(68, 65));
		setRolloverEnabled(true);
		setForeground(Color.BLACK);
                setFont(new java.awt.Font("Tahoma", Font.BOLD, 14));

	}

	public miBoton(String s) {
		super();
		color = new Color(47, 96, 208);
		pressedColor = new Color(161, 64, 0);
		overColor = new Color(115, 201, 29);
		selectedColor = pressedColor;
                
		setText(s);
		setContentAreaFilled(false);
		setBorderPainted(false);
		setFocusable(false);
		setPreferredSize(new Dimension(80, 80));
		setRolloverEnabled(true);
		setForeground(Color.BLACK);
                setFont(new java.awt.Font("Tahoma", Font.BOLD, 12));

	}

	public miBoton(String s, Color startColor, Color pressedColor) {
		super();
		color = new Color(109, 124, 135);
		pressedColor = new Color(161, 64, 0);
		overColor = new Color(225, 102, 0);
		selectedColor = pressedColor;
		setText(s);
		setContentAreaFilled(false);
		setBorderPainted(false);
		setFocusable(false);
		setPreferredSize(new Dimension(100, 100));
		setRolloverEnabled(true);
		setForeground(Color.BLACK);
                setFont(new java.awt.Font("Tahoma", Font.BOLD, 14));

	}

	/**
	 *  This method sets the Actual Background Color of the Button
	 */
	public void setStartColor(Color color) {
		this.color = color;
                repaint();
	}
	/**
	 *  This method sets the Pressed Color of the Button
	 */
	public void setPressedColor(Color pressedColor) {
		this.pressedColor = pressedColor;
	}
	/**
	 *  This method sets the Over Color of the Button
	 */
	public void setOverColor(Color overColor) {
		this.overColor = overColor;
	}

//        public void setSize(int with, int heght){
//            setPreferredSize(new Dimension(100, 100));
//        }
	
	/**
	 * @return Actual Background Color of the Button
	 */
	public Color getStartColor() {
		return this.color;
	}
	/**
	 * @return Pressed Background Color of the Button
	 */
	public Color getPressedColor() {
		return this.pressedColor;
	}
	/**
	 * @return Pressed Background Color of the Button
	 */
	public Color getOverColor() {
		return this.overColor;
	}
        
    @Override
	public void paintComponent(Graphics g) {
		int size = Math.min(getWidth(), getHeight()) - 4;
		int totalSize = size + 4;
		Graphics2D graphics = (Graphics2D) g;
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		Color baseColor = color;
		ButtonModel model = getModel();
		if (model.isPressed()) {
			baseColor = pressedColor;
			setForeground(new Color(0,0,0));
		} else if (model.isRollover()) {
			baseColor = overColor;
			setForeground(new Color(0,0,0));
		} else if (model.isSelected()) {
			baseColor = selectedColor;
			setForeground(new Color(0,0,0));
		}else if (!model.isEnabled()) {
			baseColor = new Color(192,192,192);
			setForeground(new Color(82,82,82));
		}
		GradientPaint outerBevel = new GradientPaint(0.0F, 0.0F, new Color(
				0.0F, 0.0F, 0.0F, 0.15F), 0.0F, totalSize, new Color(1.0F,
				1.0F, 1.0F, 0.25F));
		graphics.setPaint(outerBevel);
		paintInsetCircle(graphics, totalSize, 0);
		
		float colorComponents[] = baseColor.getRGBComponents(new float[4]);
		Color shadowColor = new Color(colorComponents[0] * 0.52F,
				colorComponents[1] * 0.63F, colorComponents[2] * 0.69F);
		
		graphics.setPaint(shadowColor);
		graphics.setPaint(baseColor);
		paintInsetCircle(graphics, totalSize, 3);
		
		GradientPaint highlight = new GradientPaint(0.0F, 0.0F, new Color(1.0F,
				1.0F, 1.0F, 1.0F), 0.0F, (float) totalSize * .45F, new Color(
				1.0F, 1.0F, 1.0F, 0.0F));
		
		graphics.setPaint(highlight);
		paintInsetCircle(graphics, totalSize, 4);
		//g2d.setPaint(Color.WHITE);
		paintInsetCircle(graphics, totalSize, 8);
	
		Icon icon = getIcon();
		super.paintComponent(graphics);

	}
	private void paintInsetCircle(Graphics2D graphics, int size, int inset) {
            graphics.fillOval(inset, inset, size - inset * 2, size - inset * 2);
	}
	public static void main(String args[]) {
            JFrame frame = new JFrame("Custom Panels Demo");
            frame.setLayout(new FlowLayout());
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            
            miBoton standardButton = new miBoton("Standard Button");
            miBoton rollOverButton = new miBoton("Rollover Button");
            miBoton pressedButton = new miBoton("Pressed Button");
            miBoton disabledButton = new miBoton("Disabled Button");
            disabledButton.setEnabled(false);
            
            //standardButton.setDirection(GradientOvalButton.VERTICAL);
            //standardButton.setGradientType(GradientOvalButton.NORMAL);
            standardButton.setPreferredSize(new Dimension(60, 60));
            rollOverButton.setPreferredSize(new Dimension(120, 120));
            pressedButton.setPreferredSize(new Dimension(120, 120));
            disabledButton.setPreferredSize(new Dimension(120, 120));
            
//            standardButton.addActionListener(new java.awt.event.ActionListener() {
//                public void actionPerformed(java.awt.event.ActionEvent evt) {
//                    jButton3ActionPerformed(evt);
//                }
//                
//                private void jButton3ActionPerformed(ActionEvent evt) {
//                    System.out.println("Pas.....");
//                }});
                
                frame.add(standardButton);
		frame.add(rollOverButton);
		frame.add(pressedButton);
		frame.add(disabledButton);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBackground(Color.WHITE);
		frame.setSize(700, 180);
		frame.setVisible(true);
	}
}

