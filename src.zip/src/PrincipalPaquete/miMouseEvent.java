/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PrincipalPaquete;

import java.awt.event.*;

/**
 *
 * @author Felipe
 */
public class miMouseEvent implements MouseListener, KeyListener{
    public miMouseEvent(){}

    public void mouseClicked(MouseEvent e) {
        System.out.println("Mouse click");
    }

    public void mousePressed(MouseEvent e) {
        System.out.println("Mouse Pressed");
    }

    public void mouseReleased(MouseEvent e) {
        System.out.println("Mouse Released");
    }

    public void mouseEntered(MouseEvent e) {
        System.out.println("Mouse Entered");
    }

    public void mouseExited(MouseEvent e) {
        System.out.println("Mouse Exited");
    }

    
    
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void keyPressed(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void keyReleased(KeyEvent e) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
    
}
