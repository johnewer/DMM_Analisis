/* ===========================================================
 * JFreeChart : a free chart library for the Java(tm) platform
 * ===========================================================
 *
 * (C) Copyright 2000-2004, by Object Refinery Limited and Contributors.
 *
 * Project Info:  http://www.jfree.org/jfreechart/index.html
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation;
 * either version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with this
 * library; if not, write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307, USA.
 *
 * [Java is a trademark or registered trademark of Sun Microsystems, Inc. 
 * in the United States and other countries.]
 *
 * --------------------------
 * TimePeriodValuesDemo2.java
 * --------------------------
 * (C) Copyright 2003, 2004, by Object Refinery Limited and Contributors.
 *
 * Original Author:  David Gilbert (for Object Refinery Limited);
 * Contributor(s):   -;
 *
 * $Id: TimePeriodValuesDemo2.java,v 1.7 2004/04/26 19:12:03 taqua Exp $
 *
 * Changes
 * -------
 * 30-Jul-2002 : Version 1 (DG);
 *
 */

package ejemplos;

import java.awt.Color;
import java.util.Date;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.AxisLocation;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CombinedRangeXYPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.SeriesRenderingOrder;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYBarRenderer;
import org.jfree.chart.renderer.xy.XYItemRenderer;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.time.*;
import org.jfree.data.xy.XYDataset;
import org.jfree.ui.ApplicationFrame;
import org.jfree.ui.RectangleInsets;
import org.jfree.ui.RefineryUtilities;

/**
 * An example of....
 *
 */
public class TimePeriodValuesDemo2 extends ApplicationFrame {

    /**
     * A demonstration application showing how to....
     *
     * @param title  the frame title.
     */
    public TimePeriodValuesDemo2(final String title) {

        super(title);
        final XYDataset data1 = createDataset();
        final XYDataset data2 = createDataset2(new Date(System.currentTimeMillis() - 12*60*60*1000), 12);
        
        final JFreeChart chart = ChartFactory.createTimeSeriesChart(
            title, 
            "Date", 
            "Price",
            data1, 
            true,
            true,
            false
        );
        
        XYPlot plot = chart.getXYPlot();        
        
        final XYItemRenderer renderer1 = plot.getRenderer();
        final XYBarRenderer  renderer2 = new XYBarRenderer();
        
        final DateAxis domainAxis = new DateAxis();
        final ValueAxis rangeAxis = new NumberAxis();
        
        domainAxis.setRange(new Date(System.currentTimeMillis() - 12*60*60*1000), 
                new Date(System.currentTimeMillis() + 48*60*60*1000));
        
        plot.setDataset(1, data2);
        plot.setRenderer(1, renderer2);

        
        renderer1.setSeriesPaint(0, Color.red);
        renderer1.setSeriesPaint(1, Color.blue);
        renderer2.setSeriesPaint(0, Color.BLACK);
        renderer2.setSeriesPaint(1, Color.GRAY);
        renderer2.setShadowVisible(false);
        
       
        final ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
        chartPanel.setMouseZoomable(true, false);
        setContentPane(chartPanel);

    }

    /**
     * Creates a dataset, consisting of two series of monthly data.
     *
     * @return the dataset.
     */
    public XYDataset createDataset() {
                        
        Hour hr = new Hour();
        final TimeSeries s1 = new TimeSeries("L&G European Index Trust");
        s1.add(hr.previous(), 175.5);
        s1.add(hr, 181.8);
        s1.add(hr.next(), 167.3);
        
        final TimeSeries s2 = new TimeSeries("L&G UK Index Trust");
        s2.add(hr.previous(), 159.6);
        s2.add(hr, 129.6);
        s2.add(hr.next(), 183.2);
        
        final TimeSeriesCollection dataset = new TimeSeriesCollection();
        dataset.addSeries(s1);
        dataset.addSeries(s2);
        return(dataset);
    }
    
    public XYDataset createDataset2(Date Inicio, long ranHor) {
        TimePeriodValues s1 = new TimePeriodValues("Series 1");
        TimePeriodValues s2 = new TimePeriodValues("Series 2");
        
        long tt = 1 * 60 * 60 * 1000; //Una hora en milisegundos.
        long td = 0;
        Date dt = new Date(Inicio.getTime());
        
        for(int i=1; i<5;i++){
            td = dt.getTime();
            s1.add(new SimpleTimePeriod(td, td+ranHor*tt), 20.00);
            s2.add(new SimpleTimePeriod(td+ranHor*tt, td+2*ranHor*tt), 20.00);
            
            dt.setTime(td+2*ranHor*tt);
        }
        
        final TimePeriodValuesCollection dataset = new TimePeriodValuesCollection();
        dataset.addSeries(s1);
        dataset.addSeries(s2);
        return dataset;        
    }
    

    public static void main(final String[] args) {
        final TimePeriodValuesDemo2 demo = new TimePeriodValuesDemo2("Time Period Values Demo 2");
        demo.pack();
        RefineryUtilities.centerFrameOnScreen(demo);
        demo.setVisible(true);
    }
}