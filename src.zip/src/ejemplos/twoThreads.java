/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplos;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author felipe
 */
public class twoThreads {
    boolean CONTROL1 = false;
    boolean CONTROL2 = false;
    boolean otroCont = false;
    private int INDICE  = 0;
    private int INDICE2 = 0;
    
    public twoThreads(){
        CONTROL1 = true;
        CONTROL2 = true;
                
        thread1.start();
        thread2.start();
        
    }
    
    public Thread thread1 = new Thread () {
        public void run () {
            while(CONTROL1){
                System.out.println("HEBRA 1: " + INDICE);
                INDICE++;
                
                if(INDICE > 20){
                    INDICE = 0;
                    thread2.notify();
                    
                    try {
                        thread1.wait();
                    } catch (InterruptedException ex) {
                        Logger.getLogger(twoThreads.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                
                
                try {
                    Thread.sleep(500);
                } catch (InterruptedException ex) {
                    Logger.getLogger(twoThreads.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    };
    
    
    Thread thread2 = new Thread () {
        public void run () {
            while(CONTROL2){
                System.out.println("HEBRA 2: " + INDICE2);
                INDICE2++;
                
                if(INDICE2 > 50){
                    thread1.notifyAll();
                }
                
                try {
                    Thread.sleep(200);
                } catch (InterruptedException ex) {
                    Logger.getLogger(twoThreads.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    };
    
    
    
    
    

    
     public static void main(String args[]) {
         new twoThreads();
     }
}
