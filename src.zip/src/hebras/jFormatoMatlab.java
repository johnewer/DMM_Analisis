/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hebras;

import Abrir_guardar.abrirObjeto;
import Abrir_guardar.objetoGuardar2;
import PrincipalPaquete.jAnalisis;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;

/**
 *
 * @author Felipe
 */
public class jFormatoMatlab extends JLabel implements Serializable, Runnable{
    
    private boolean CONTROL = false;
    public Thread   miHebra = null;
    
    public String path        = null;
    public String listExper[] = null;
    public String direcFolder = null;
    
//  Set de codigos que serán enviados a MATLAB.
    public static int codError  = 2000;
    public static int codActiv  = 2001; //Codigo para llamar a formato en matlab (Excell en este caso).
    public static int codAnalis = 2002;
    public static int codFondo  = 2012;
    public static int codPrueba = 2013;
    public static int codOtros  = 2331;
    public objetoGuardar2 obb = null;
    
    //Elementos para convertir el archivo .datt.
    public String filtNombre = "5_pts";
    public JButton jBControl = null;
    
    
    
    public jFormatoMatlab(){
        addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyPressed(java.awt.event.KeyEvent evt) {}
        });
    }
    
    public void setElements(JButton _jb){
        jBControl = _jb;
    }
    
    /**
     * 
     */
    public void run() {
        int indice = 0;
        while(CONTROL){
            jBControl.setText("-  ");
            dormirUNrato(1000);
            
            //Redundante, pero me sirve para matlab ;).
            direcFolder = path + "/" + listExper[indice];
            File ff = new File( direcFolder + "/Serie_Datos.datt");
            
            int tt = -1;
            if(ff.exists()){
                tt = AbrirCadaSerie(ff.getAbsolutePath());
            }
            
            jBControl.setText("-- ");
            dormirUNrato(1000);
            
            indice++;
            if(indice == listExper.length) CONTROL = false;
            jBControl.setText("---");
            
            dormirUNrato(1000);
        }
        
        jBControl.setText("INICIAR");
    }
    
    /**
     * Metodo para abrir cada serie de datos, curvas. Llama a Matlab, y esta 
     * genera los archivos con ambas curvas y las guarda.
     */
    public int AbrirCadaSerie(String _path){
        int ret = -1;
        try {
            abrirObjeto abrir = new abrirObjeto();
            abrir.abrir(_path); //Abre la direccion entregada.
            obb = abrir.leer();
            
            miMetodo(codActiv);  //LLAMADO A MATLAB !!!.
            
            esperar();  //Espera a que Matlab termine !.
            
            return(ret);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(jFormatoMatlab.class.getName()).log(Level.SEVERE, null, ex);
            ret = 1;
        } catch (IOException ex) {
            Logger.getLogger(jFormatoMatlab.class.getName()).log(Level.SEVERE, null, ex);
            ret = 1;
        }
        return(ret);
    }
    
    /**
     * 
     */
    public void startt(String _path, String[] _listExper){
        path      = _path;
        listExper = _listExper;
        
        if(listExper.length != 0){
            CONTROL = true;
            
            miHebra = new Thread(this);
            miHebra.start();
        }    
    }
    /**
     * Metodo para hacer que la hebra ESPERE. Usado para detener la ejecuciòn 
     * de esta hebra, por ejemplo por Matlab o por el objeto que analiza completo
     * de un experimento. 
     * Se suele usar la detensiòn de esta hebra, para ver si està funcionando bien
     * la detecciòn o anàlisis de la misma.
     */
    public synchronized void esperar(){
      try {
          wait();
      } catch (InterruptedException ex) {
          Logger.getLogger(jAnalisis.class.getName()).log(Level.SEVERE, null, ex);
      }
    }    
    /**
     * Metodo para despertar la hebra. Usado para reactivar la ejecuciòn 
     * de esta hebra, por ejemplo por Matlab o por el objeto que analiza completo
     * de un experimento.
     */
    public synchronized void despertar(){
        notify();
    }  
    /**
     * Metodo llamado por Matlab, para despertar a esta hebra y continuar con su 
     * ejecuciòn. Usado principalmente opr Matlab y no por esta hebra.
     */
    public void matlabDespierta(){
            despertar();
    }
    public void miMetodo(int _code){
        processKeyEvent(new KeyEvent(this, KeyEvent.KEY_PRESSED, 
                System.currentTimeMillis(), 0, _code, '-'));
    }
    
    
    
    public void fijarNombreFiltro(String _name){
        filtNombre = _name;
    }
    private void mensaje(Object _mensaje){
        System.out.println(_mensaje);
    }
    private void dormirUNrato(long _tiempo){
        try {
            Thread.sleep(_tiempo);
            
        } catch (InterruptedException ex) {
            Logger.getLogger(jFormatoMatlab.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
