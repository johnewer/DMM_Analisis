package hebras;

import PrincipalPaquete.jAnalisis;
import com.sun.media.jai.codec.FileSeekableStream;
import com.sun.media.jai.codec.ImageCodec;
import com.sun.media.jai.codec.ImageEncoder;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.awt.image.renderable.ParameterBlock;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.media.jai.JAI;
import javax.swing.ImageIcon;
import javax.swing.JProgressBar;

/**
 *
 * @author FELIPE
 */
public class jHebraBuscar implements Runnable, Serializable{
    private jAnalisis panelFoto = null;
    private String direc[]      = null;
    private String path         = null;
    private String pathDestino  = null;
    private int INDICE  = 0;
    private int imgGuia = 0;
    private int jTemp   = 0;
    private JProgressBar mi_bar = null;
    
    private boolean CONTROL = true;
    private boolean fijImag = true;
    private BufferedImage im;
    
    private Thread miHebra = null;
    
    
    
public jHebraBuscar(jAnalisis _panelFoto, String _direc[], String _path,
        int _ind, String _pathDestino, JProgressBar _mi_bar){
    panelFoto   = _panelFoto;
    direc       = _direc;
    path        = _path;
    imgGuia     = _ind;
    pathDestino = _pathDestino;
    mi_bar      = _mi_bar;
}

@Override
public void run(){
    double tem  = 0.0;
    double  dd  = 0.0;
    double tem2 = 0.0; 
    FileSeekableStream fTemp = null;
    
    im  = leerIm(path, direc[imgGuia]);
    tem = corr2(im,leerIm(path, direc[0]));
    
    while(INDICE < (direc.length - 1) && CONTROL){
        try {
            dd = getTime(direc[INDICE]);
            
            while (temCompare(dd , getTime(direc[INDICE])) < 3 && INDICE < (direc.length-1)) {
                tem2 = corr2(im, leerIm(path, direc[INDICE]));
                if (tem2 >= tem) {
                    tem = tem2;
                    jTemp = INDICE;
                }
                INDICE++;
            }
            
            fTemp = new FileSeekableStream(path + "/" + direc[jTemp]);
            FileOutputStream os = new FileOutputStream(pathDestino + "/" + direc[jTemp]);
            ImageEncoder encoder = ImageCodec.createImageEncoder("TIFF", os, null);
            encoder.encode(JAI.create("stream", fTemp));
            os.close();
            } catch (IOException ex) {
                Logger.getLogger(jHebraBuscar.class.getName()).log(Level.SEVERE, null, ex);
            }
        if(tem > 0.99 && fijImag)
            im = leerIm(path, direc[jTemp]);
        
        panelFoto.setIcon(new ImageIcon((Image)JAI.create("stream", fTemp).getAsBufferedImage()));
        tem = 0.0;
        mi_bar.setValue(INDICE);
       
    }
}

public void start(){
    CONTROL = true; INDICE = 0;
    
    miHebra = new Thread(this);
    miHebra.start();
}

public void stopp(){
    CONTROL = false;
}
//CORRELACION de imagenes
private double corr2(BufferedImage img1, BufferedImage img2){
        double coefCorr = 0;
        double mean1    = 0;
        double mean2    = 0;
        double mean_a1  = 0;
        double mean_a2  = 0;
        double meanX    = 0;
        int Area        = img1.getWidth()*img1.getHeight();
        
        double[][] matrix  = {{ 0.3D, 0.59D, 0.11D, 0D }};
	ParameterBlock pb  = new ParameterBlock();
	pb.addSource(img1);
        
        pb.add(matrix);        
	DataBuffer A1 = JAI.create("BandCombine", pb, null).getData().getDataBuffer();
        
        ParameterBlock pb2 = new ParameterBlock();
        pb2.addSource(img2);
        
        pb2.add(matrix);
        DataBuffer A2 = JAI.create("BandCombine", pb2, null).getData().getDataBuffer();
        
        for(int i = 0; i < A1.getSize(); i++){
            mean1  = mean1 + A1.getElem(i);
            mean_a1 = mean_a1 + A1.getElem(i)*A1.getElem(i);
            mean2  = mean2 + A2.getElem(i);
            mean_a2 = mean_a2 + A2.getElem(i)*A2.getElem(i); 
            
            meanX = meanX + A1.getElem(i)*A2.getElem(i);
        }
        
        mean1 = mean1/Area;
        mean2 = mean2/Area;
        meanX = meanX - Area*(mean1 - mean2);
        
        coefCorr = meanX / Math.sqrt(mean_a1*mean_a2 - Area*(mean2*mean_a1 
                - mean1*mean_a2 - Area*mean1*mean2));
        
        return(coefCorr);
}

private double getTime(String dia){
    return(new Integer(dia.substring(13, 15)).doubleValue());
}

private double temCompare(Double tem1, Double tem2){
    Double tem = Math.abs(tem1 - tem2);
    
    if(tem > 50){
        tem = 60.0 - Math.max(tem1, tem2) + Math.min(tem1, tem2);
    }
    return(tem);
}

public void cambioImag(boolean _fijImag){
    fijImag = _fijImag;
}

private BufferedImage leerIm(String path, String name){
    FileSeekableStream fTemp = null;
    try {
        fTemp = new FileSeekableStream(path + "/" + name);
    } catch (IOException ex) {
        Logger.getLogger(jHebraBuscar.class.getName()).log(Level.SEVERE, null, ex);
        }
    return JAI.create("stream", fTemp).getAsBufferedImage();   
}
    
public void setData(String _pathDestino, String _path, String _direc[], int _indice){
    pathDestino = _pathDestino;
    path        = _path;
    direc       = _direc;
    imgGuia     = _indice;
}

public void setCambioImagen(boolean _fijImag){
    fijImag = _fijImag;
}

}

