/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hebras;

import com.sun.media.jai.codec.FileSeekableStream;
import com.sun.media.jai.codec.ImageCodec;
import com.sun.media.jai.codec.ImageEncoder;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.awt.image.renderable.ParameterBlock;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.media.jai.JAI;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JProgressBar;

/**
 *    ESTA ES LA HEBRA PRINCIPAL DE BUSQUEDA. DENTRO DE TODO EL SET DE 
 * IMAGENES, SEPARA LAS IMAGENES CORRESPONDIENTES A UN MISMO ANIMAL, CADA 
 * 12 MINUTOS.
 *    Detecta, crea y guarda cada imagen, por cada 12 mìnutos que aparece un
 * nuevo animal, en un directorio o carpeta creado con el nombre de la posiciòn
 * que ocupa dicho animale en el onden del disco.
 * 
 * @author Felipe
 */
public class jhebraDetectar implements Runnable, Serializable{
    /**
     * Variable control de hebra principal. Controla todo el sistema.
     */
    private boolean CONTROL = false;
    /**
     * Variable para controlar la fijación de una imagen como guia para 
     * la busqueda de las siguietnes.
     */
    private boolean fijImg  = false;
    
    
    /**
     * Indice guìa para indicar donde empieza, dentro de TODA la lista, la busqueda
     * de un animal. Usado por la hebra que controla la separación de un experimento
     * completo.
     */
    private int indexGuia = 0;
    
    /**
     * Guarda en indice de la mejor imagen encontrada en un set de imagenes en 
     * un tiempo respectivo.
     */
    private int jTemp     = 0;
    /**
     * Indice que indica donde me encuentro en la ejecución.
     */
    private int INDICE    = 0;
    
    /**
     * Indicador que dice què tan proximo debo estar de una imagen, para considerarla
     * parte de un animal, y no de otros.
     */
    private double Tolerancia   = 2.5;
    /**
     * Salto de tiempo... Casi 720 segundos, o 12 minutos en segundos.
     */
    private double tSalto       = 719.98;

    /**
     * Lista de nombres (texto) de cada imagen en el directorio trabajado.
     */
    private String  direc[]   = null;
    /**
     * Direcciòn de la carpeta donde estamos trabajando.
     */
    private String  path      = null;
    /**
     * Direcciòn destino de las imagenes, experimento.
     */
    private String  p_Destino = null;
    
    /**
     * Cuadro para mostrar las imàgenes que se están trabajando.
     */
    private JLabel        foto    = null;
    /**
     * Barra de progreso. Para indicar en que punto estamos.
     */
    private JProgressBar  mi_bar  = null;
    /**
     * Imagen de referencia para busquedas.
     */
    private BufferedImage imgGuia = null;
    
    /**
     * Hebra, corazón de esta clase.
     */
    private Thread miHebra = null;
    /**
     * Hebra de control, que manera el experimento completo.
     */
    private jhebraEncontrar miHebraControl = null;
    
    // Objeto para limpiar la memoria que queda como basura. \\
        Runtime LimpiadorMemoria = Runtime.getRuntime();
    //---------------------------------------------------------\\
    
    
     /**
     * CONSTRUCTOR. Requiere como entrada la objeto tipo JLabel, que permite cargar
     * imàgenes en èl. Ademàs, la barra de progreso de serie de imagenes, para 
     * indicarle a la UI cuanto han avanzado en la serie trabajada.
     * @param _foto: JLabel donde se mostrarà cada imagen y cada evento gràfico.
     * @param _mi_bar: Barra de progreso, que indica en que parte estamos parados.
     */
    public jhebraDetectar(JLabel _foto, JProgressBar _mi_bar){
        foto    = _foto;
        mi_bar  = _mi_bar;
    }

    /**
    * METODO PRINCIPAL: Toda hebra tiene una mètodo tipo RUN, que se ejecuta en forma
    * indefinida, y es controlado por un ciclo "WHILE" y una variable CONTROL. Al 
    * momento de salir de dicho ciclo, por cualquier razon, la hebra muere, y se debe
    * volver a crear. Metodos como star() y stop() controlan la vida o muerte de
    * la hebra.
    * <p>
    *      CONTROL y el INDICE de la lista de imagenes, controlan esta hebra.
    */
    
    @Override
    public void run(){
        //TIEMPOS
        boolean cGuardar = false;/* Contro de guardar imagen. */

        double  imtem;
        double  temResguardo = 100.0;
        double  tem2 = getTime(direc[indexGuia]);

        /* ---- Factores de CORRELACIONES---- */
        double corrActual = 0.0;
        double corrGuia   = 0.0;

        /* IMAGEN GUIA !!!. Es la imagen inicial para la bùsqueda */
        imgGuia = leerImg(path, direc[indexGuia]);
        mi_bar.setMaximum(direc.length);// Fija el maximo de la barra indicadora.
        mi_bar.setMinimum(0);           // Fija el minimo de la barra indicadora.
        
        /**
         * Este es el bucle principal de esta hebra.' El bucle "while" 
         * controla la vida de la hebra en su totalidad.' Si sale del "while",
         * la hebra ha muerto, y debe ser llamada nuevamente el mètodo start()
         * para volver a crearla.' Es un bucle controlado por dos variables:
         *      INDICE:  La hebra està viva mientras busque el set de 
         *              imàgenes que debe encontrar.' Una vez recorrida toda
         *              la lista, la hebra concluye su ejecuciòn y muere.'
         * 
         *      CONTROL: Controla desde fuera de la hebra, o eventos fuera
         *              del bucle while.' Si control pasa a ser "False", la
         *              hebra muere.'
         * 
         * Esta hebra puede ser controlada por eventos externos, pudiendo
         * ser detenida en cualquier momento, no necesariamente cuando acabe
         * la bùsqueda.' Los mètodos como "start()" o "stop()" con los princi-
         * pales de control.' Vida y muerte de esta hebra.
         *
         */
        //---  CICLO PRINCIPAL DE LA HEBRA. --- \\
        while( INDICE < (direc.length - 1) && CONTROL){
            corrGuia = 0.0;
            imtem = getTime(direc[INDICE]); // tiempo de la imagen actual.

               /**
                * SE ENGANCHA...
                *  Si la diferencia entre el tiempo de la imagen actùal y 
                * un tiempo de referencia, es menor a una "Tolerancia", quiere 
                * decir que està en el set correspondiente, y empieza ahora a
                * buscar la mejor imagen, respecto a la anterior encontrada. 
                * Recordar que cada 12 min se repite el ciclo de imagenes de
                * un mismo animal...
                */ 
            while (Math.abs(imtem - tem2) < Tolerancia) {
                cGuardar = true;
                corrActual = corr2(imgGuia, leerImg(path, direc[INDICE]));
                if (corrActual >= corrGuia) {
                    corrGuia = corrActual;
                    jTemp = INDICE; //Guarda el INDICE de la mejor imagen.
                }
                INDICE++;
                if(INDICE >= direc.length) break; //Fin de la lista. Salgo del While.
                
                mi_bar.setValue(INDICE);
                imtem = getTime(direc[INDICE]);
            }


            /**
            * Al momento de encontrar la imagen adecuada, la mejor de un
            * grupo de 5 o màs imagenes por segmento de tiempo, sale del
            * while anterior, guarda una nueva imagen en la direcciòn
            * respectiva, indicada para dicho animal.
            */
            if (cGuardar) {
                cGuardar = false;
                /* Acà guarda la imagen segùn el indice.*/
                guardarImg(direc[jTemp]);
                /* Muestro la imagen en pantalla.*/
                foto.setIcon(new ImageIcon((Image) leerImg(path, direc[jTemp])));


                /* Si la imagen encontrada es muy buena respecto a la imagen 
                    * guia, y le he dicho a la hebra que la cambie, este "if"
                    * lo hace */
                if (corrGuia > 0.990 && fijImg) {
                    imgGuia = leerImg(path, direc[jTemp]);
                }
                
            /**
            * Una vez encontrada la imagen "mejor", se procede a usar 
            * el tiempo de esa imagen como guia para la busqueda de la
            * siguiente. 
            * Luego se ocupa la operaciòn "resto (%)" para asegurarnos
            * que si pasò a un nuevo dìa, el tiempo quede en los minutos
            * correspondientes a 24 horas.
            */
                tem2  = getTime(direc[jTemp]) + tSalto;
                tem2 %= 86400;   // Si pasa de las 24 horas, otro día, toma solo los minutos que restan.
            }

            temResguardo = tem2 - imtem;
            if (temResguardo < -10 && temResguardo > -85600) {
                tem2 = tem2 + tSalto;
                tem2 %= 86400;
            }

            INDICE++; /* Voy a la siguiente imagen.*/
            mi_bar.setValue(INDICE); /*Marco el nùmero de la imagen en la UI*/
        }
        
   //-- Limpia la memoria, antes de morir ------.
        limpiarMemoria();
   //-----------------------------------------------/

        CONTROL = false;
        miHebraControl.despertar();
    }

    /**
     * Funcion de CORRELACION: Esta permite comparar dos imagenes (los parametros son 
     * vectores de ambas imagenes) para determinar su correlacion. Es usado ampliamente
     * en el algoritmo de busqueda de la mejor zona de la imagen, para centrarla y 
     * enviarsela a Matlab para realizar el anàlisis.
     * 
     * @param img1: Primera imagen a comparar.
     * @param img2: Segunda imagen a comparar.
     * @return Factor de correclacion entre imagenes.
     */  
    private double corr2(BufferedImage img1, BufferedImage img2){
        double coefCorr = 0;
        double mean1 = 0;
        double mean2 = 0;
        double mean_a1 = 0;
        double mean_a2 = 0;
        double meanX = 0;
        int Area = img1.getWidth()*img1.getHeight();

        double[][] matrix = {{ 0.3D, 0.59D, 0.11D, 0D }};
        ParameterBlock pb = new ParameterBlock();
        pb.addSource(img1);

        pb.add(matrix);
        DataBuffer A1 = JAI.create("BandCombine", pb, null).getData().getDataBuffer();

        ParameterBlock pb2 = new ParameterBlock();
        pb2.addSource(img2);

        pb2.add(matrix);
        DataBuffer A2 = JAI.create("BandCombine", pb2, null).getData().getDataBuffer();

        for(int i = 0; i < A1.getSize(); i++){
            mean1   += A1.getElem(i);
            mean_a1 += Math.pow(A1.getElem(i),2);
            mean2   += A2.getElem(i);
            mean_a2 += Math.pow(A2.getElem(i),2);

            meanX += A1.getElem(i)*A2.getElem(i);
        }

        mean1 = mean1/Area;
        mean2 = mean2/Area;
        meanX = meanX - Area*(mean1 - mean2);
        coefCorr = meanX / Math.sqrt(mean_a1*mean_a2 - Area*(mean2*mean_a1
                - mean1*mean_a2 - Area*mean1*mean2));

        return(coefCorr);
    }

    /**
     * Mètodo que convierte el String del nombre de la imagen, en un numero Double
     * que REPRESENTA EL MOMENTO, TIEMPO EN QUE FUE CAPTURADA, y
     * que se ocupa para comparar la imagen con dicho nombre, con la imagen guia.
     * Es usado para encontrar dentro de toda la lista de imagenes, la imagen 
     * siguiente, el grupo siguiente (recordar que cada animal, en cada momento 
     * està formado por unas 5 imagenes).
     * @param dia: String que es el nombre de la imagen.
     * @return 
     */
    public double getTime(String dia){
        if(dia.contains(","))
            dia = dia.replace(",",".");
        int d = dia.length();

        return( Double.parseDouble(dia.substring(d-16, d-14))*3600 +
                Double.parseDouble(dia.substring(d-13, d-11))*60 + 
                Double.parseDouble(dia.substring(d-10,  d-4)));
    }

    /**
     * Compara la diferencia de tiempo entre dos tiempos (como nùmero Double).
     * Recordar que se està trabajando con tiempo en minutos, y por ende debe 
     * tenerse presente los cambios de dìa y año.
     * @param tem1: Double con la hora de una imagen.
     * @param tem2: Double con la hora de otra imagen.
     * @return la diferencia entre ambos.
     */
    private double temCompare(Double tem1, Double tem2){
        Double tem = Math.abs(tem1 - tem2);
        if(tem > 50){
            tem = 60.0 - Math.max(tem1, tem2) + Math.min(tem1, tem2);
        }
        return(tem);
    }

    /**
    * Mètodo que lee una imagen, desde la direcciòn indicada. Usado en la ejecuciòn 
    * de la hebra, mètodo RUN de esta clase.
    * 
    * @param path de la imagen.
    * @param name de la imagen.
    * @return La imagen ya leida y cargada en un objeto de tipo Bufferd.
    */
    private BufferedImage leerImg(String path, String name){
        try {
            FileSeekableStream fTemp = new FileSeekableStream(path + "/" + name);
            return(JAI.create("stream", fTemp).getAsBufferedImage());
        } catch (IOException ex) {
            Logger.getLogger(jhebraDetectar.class.getName()).log(Level.SEVERE, null, ex);
            return(null);
        }
    }

    /**
    * Mètodo encargado de guardar la imagen reconocida como la mejor, la continuaciòn 
    * del ciclo en 12 min de avance.
    * 
    * @param imgName: Imagen a guardar. Nombre (String) con el cual ser guardará.
    * @return 
    */
    private boolean guardarImg(String imgName){
        FileSeekableStream fTemp = null;
        try {
            fTemp = new FileSeekableStream(path + "/" + imgName);
            FileOutputStream os = new FileOutputStream(p_Destino + "/" + imgName);
            ImageEncoder encoder = ImageCodec.createImageEncoder("TIFF", os, null);
            encoder.encode(JAI.create("stream", fTemp));
            os.close();
            return(true);

        } catch (IOException ex) {
            Logger.getLogger(jhebraDetectar.class.getName()).log(Level.SEVERE, null, ex);
            return(false);
        } finally {
            try {
                fTemp.close();
                return(false);
            } catch (IOException ex) {
                Logger.getLogger(jhebraDetectar.class.getName()).log(Level.SEVERE, null, ex);
                return(false);
            }
        }
    }
    
    /**
     * Metodo para fijar el tiempo en que avanza una imagen, al set siguiente de 
     * imàgenes. Por lo general son 720 seg (12 min).
     * @param _tSalto Double que indica la cantidad de tiempo en segundos.
     */
    public void setTimeSalto(double _tSalto){
        tSalto = _tSalto;
    }
    
    /**
     * Metodo para fijar el RANGO de tiempo en el cual se engancha la deteccion. 
     * Por lo general son 2.5 seg (min 0.5 - max 8 seg).
     * @param _tSalto Double que indica la cantidad de tiempo en segundos.
     */
    public void setTolerancia(double _Tolerancia){
        Tolerancia = ((double)Math.round(10 * _Tolerancia)) / 10;
    }
    
    /**
     * Mètodo para cargar datos usados para la separaciòn, desde la hebra que controla
     * un experimento completo.
     * @param _direc Lista de imagenes.
     * @param _path  path origen.
     * @param _p_Destino Path Destino.
     * @param _indx Indice donde se encuentra la imagen guia.
     */
    public void setData(String _direc[], String _path, String _p_Destino, int _indx){
        direc = _direc;
        path  = _path; 
        p_Destino = _p_Destino;
        indexGuia = _indx;
        INDICE = _indx;
    }
    
    /**
     * Mètodo para dar vida a la hebra. Activa la variable "CONTROL", crea
     * una nueva instancia de la clase "Thread" y luego la hace correr, con el 
     * metodo start() de la clase misma. Este mètodo es llamdo siempre que se 
     * quiera dar inicio a una busqueda de un set de imagenes, dentro de un
     * experimento completo.
     */
    public void start(){
        CONTROL = true;

        miHebra = new Thread(this);
        miHebra.start();
    }
    
    /**
     * Mètodo para detener y dar muerte a la hebra. Con el solo hecho de poner
     * la variable "CONTROL" en false, se sale del bucle "while" del mètodo RUN
     * y la hebra muere. Mètodo invocado por lo principal desde fuera de esta
     * hebra, desde la UI (User Interface).
     */
    public void stop(){
        CONTROL = false;
    }
    
    /**
     * Retorna la variable "Control", que indica si la hebra està en ejecuciòn o
     * si ha finalizado la busqueda.\
     * Usado principalmente por mètodos externos a esta hebra, en la UI (User
     * Interface).
     * @return: Varibale CONTROL, que indica si la hebra està en ejecuciòn.
     */
    public boolean isLive(){
        return(CONTROL);
    }
    
    /**
     * Metodo para indicar que al momento de encontrar la nueva imagen adecuada,
     * cambie la imagen guia por la encontrada.
     * @param _fijImg 
     */
    public void fijCambio(boolean _fijImg){
        fijImg = _fijImg;
    }
    
    public void limpiarMemoria(){
        miHebra = null;
        direc   = null;
        
        LimpiadorMemoria.gc();
    }
    
    /**
     * OJO MUY IMPORTANTE:
     *   Como sistema orientado a objetos, cada objeto està dentro de otro, 
     * o conviven en un mismo ambiente (ambos en dentro de otro objeto).\ Ahora, 
     * dado que esta hebra es la encargada de detectar una secuencia de 
     * imagenes, un animal en particular, es otra hebra la que trabaja la
     * detecciòn de todos los animales de un experimento.\ Por ende, existen 
     * eventos que de una hebra, deben pasar a la otra, y controlarse entre sí.\
     * ACA, conectamos ambas hebras, mediante un objeto en comùn.
     * 
     * @param _hControl 
     */
    public void fijarHebraControl(jhebraEncontrar _hControl){
        miHebraControl = _hControl;
    }
    
    
    private void mensaje(Object _mensaje){
        System.out.println(_mensaje);
    }
}
