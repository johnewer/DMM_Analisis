/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hebras;

import PrincipalPaquete.jCONTROLES;
import com.sun.media.jai.codec.FileSeekableStream;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.media.jai.JAI;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

/**
 *     Hebra encargada de separar un grupo de animales, o un experimento completo. 
 * Trabajando en conjunto con la hebra jhebraDetectar, la cual separa un animal 
 * a la vez, esta hebra maneja todo lo referente a la lista de animales a separar
 * en un mismo experimento.
 *
 * @author Felipe
 */
public class jhebraEncontrar implements Runnable, Serializable{
    private jCONTROLES mCONTROL = null;
    
    /**
     * Lista de todas las imagenes.
     */
    public String[] direc = null;
    /**
     * 
     */
    public List listImagen = new LinkedList();
    public File guiaFolder = null;
    public File destFolder = null;
    public JComboBox listName = null; //Lista de SUB-directorios, donde irá cada animal
    
    public Thread miHebra = null;
    public jhebraDetectar mi_hebra = null;
    
    public int index = 0;
    public int ddd = 1001;
    
//  Objeto para limpiar la memoria que queda como basura.      \\
     Runtime LimpiadorMemoria = Runtime.getRuntime();
//-------------------------------------------------------------\\
    
        
    /**
     * CONSTRUCTOR: Al crear esta hebra, se ejecutan los siguientes comandos.
     *    Se entrega la lista de imágenes guía para separar, los nombres generados,
     * y el set de varaibles de "CONTROL" inherente a todas las clases.
     * 
     * @param _miHebra
     * @param _listName
     * @param _mControl 
     */
    public jhebraEncontrar(jhebraDetectar _miHebra, JComboBox _listName, jCONTROLES _mControl){
        mCONTROL   = _mControl;
        listName   = _listName;
        mi_hebra   = _miHebra;
        mi_hebra.fijarHebraControl(this);
        
        listImagen.add("");
    }
    
   /**
    * METODO PRINCIPAL: Toda hebra tiene una mètodo RUN, que se ejecuta 
    * al momento de dar INICIO (star) a la hebra, pudiendo ser controlado 
    * por un ciclo "WHILE" INDEFINIDO, y una o màs variable de CONTROL. Al
    * momento de salir de dicho ciclo, por cualquier razòn, la hebra muere, 
    * y se debe volver a crear. 
    * Metodos como star() y stop() controlan la vida o muerte de la hebra.
    * <p>
    * CONTROL y el INDICE de la lista de imagenes, controlan esta hebra.
    */
    public void run(){
        boolean conGuardar = false;
        int dt = -1;
        
        /** 
         * CICLO PRINCIPAL DE LA HEBRA...
         * Este bucle es controlado por una variable guardada en el set general 
         * de variables de control, pero principalmente por la lista de imagenes, 
         * animales a separar.
         * Inicia la separación en base a una lista entregada por la UI Principal, 
         * para ejecutar una por una la hebra de separación, entregando a cada 
         * ciclo de ejecución de esta hebra.
         * 
         */
        while(mCONTROL.getControl(10) && index < listImagen.size()){
            /**
             * Genera un file con la dirección de animal a separar. 
             */
            File ff = new File(destFolder.getAbsolutePath()+ "/" + ((String)listName.getItemAt(index)));
            /**
             * Si NO existe el directorio, lo crea.
             */ 
            if(!ff.exists()) ff.mkdir();
            
            
            /**
             * Ciclo que busca el INDICE, el indicador de la ubicación de la
             * imagen guía de este animal, dentro de TODO el set de imagenes.
             * Recordar que estamos separando grupos de animales, pero cada uno,
             * cada imagen guía tiene una posición en la lista general.
             */
            for(int i=0; i< direc.length; i++)
                if(direc[i].compareToIgnoreCase((String)listImagen.get(index)) == 0){
                    dt = i;            //Indice de la imagen guía, dentro de TODA LA COLECCION.
                    conGuardar = true; //Activa la entrada a guardar de màs abajo.
                    break;             // Sale de este ciclo, en forma inmediata.
                }
            /**
             * Entra a ejecutar la hebra de busqueda de un animal especifico.
             */
            if(conGuardar){
                //Carga de datos.
                mi_hebra.setData(direc, guiaFolder.getAbsolutePath(), ff.getAbsolutePath(), dt);
                // Llamada a ejecutarse.
                mi_hebra.start();
                /**
                 * Cambia a false la condicion de guardar, para la siguiente animal.
                */
                conGuardar = false;
                
                /**
                 * IMPORTANTE: Detiene esta hebra, para no generar busquedas en 
                 * paralelo. La hebra de Separación se encarga de despertarla cuando
                 * ha finalizado la separación del animal actual. Este inter-
                 * coneccion es esquematizada en el documento guía de este trabajo.
                 */
                esperar();
            }
            dt = -1;
            index++;
            ddd++;
        }
        /**
         * IMPORTANTE: Vuelve a cero, el indice que maneja la lista de animales
         * a separar.
         */
        index = 0;
        
        /**
         * Mensaje para borrar la lista nombre de cada imagen, o no hacerlo.
         * Puede quererse guardar la lista en otra carpeta, y no borrar la lista.
         * 
         */
        String opc[] = {"SI", "NO"};
        int opd = JOptionPane.showOptionDialog(null, "Desea BORRAR la lista de nombres ?", "BORRAR LISTA",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, null,
                    opc, opc[0]);
        if (opd == 0){
            borrarListas();
        }
    }
    
    public void start(){
        mCONTROL.setControl(10, true);//Control ejecucion hebra.
        miHebra = new Thread(this);
        miHebra.start();
    }
    
    public synchronized void esperar(){
        try {
            wait();
        } catch (InterruptedException ex) {
            Logger.getLogger(jhebraEncontrar.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
    public synchronized void despertar(){
        notify();
    }
    
    

    public void setData(String[] _direc, File _jPathImage, File _jDestino, List _lisImagen){
        direc = _direc;
        guiaFolder = _jPathImage;
        destFolder = _jDestino;
        listImagen = _lisImagen;
    }
    
    private BufferedImage leerImg(String path, String name){
        try {
            FileSeekableStream fTemp = new FileSeekableStream(path + "/" + name);
            return(JAI.create("stream", fTemp).getAsBufferedImage());
        } catch (IOException ex) {
            Logger.getLogger(jhebraEncontrar.class.getName()).log(Level.SEVERE, null, ex);
            return(null);
        }
    }
    
    public void borrarListas(){
        listName.removeAllItems();
        listName.setMaximumRowCount(5);
        listImagen.clear();
    }
    
    public void limpiarMemoria(){
        miHebra = null;
        direc   = null;
        
        LimpiadorMemoria.gc();
    }
}



//
//    private double corr2(BufferedImage img1, BufferedImage img2){
//        double coefCorr = 0;
//        double mean1 = 0;
//        double mean2 = 0;
//        double mean_a1 = 0;
//        double mean_a2 = 0;
//        double meanX = 0;
//        int Area = img1.getWidth()*img1.getHeight();
//        
//        double[][] matrix = {{ 0.3D, 0.59D, 0.11D, 0D }};
//        ParameterBlock pb = new ParameterBlock();
//        pb.addSource(img1);
//        
//        pb.add(matrix);
//        DataBuffer A1 = JAI.create("BandCombine", pb, null).getData().getDataBuffer();
//        
//        ParameterBlock pb2 = new ParameterBlock();
//        pb2.addSource(img2);
//        
//        pb2.add(matrix);
//        DataBuffer A2 = JAI.create("BandCombine", pb2, null).getData().getDataBuffer();
//        
//        for(int i = 0; i < A1.getSize(); i++){
//            mean1   += A1.getElem(i);
//            mean_a1 += Math.pow(A1.getElem(i),2);
//            mean2   += A2.getElem(i);
//            mean_a2 += Math.pow(A2.getElem(i),2);
//            
//            meanX += A1.getElem(i)*A2.getElem(i);
//        }
//        
//        mean1 = mean1/Area;
//        mean2 = mean2/Area;
//        meanX = meanX - Area*(mean1 - mean2);
//        coefCorr = meanX / Math.sqrt(mean_a1*mean_a2 - Area*(mean2*mean_a1
//                - mean1*mean_a2 - Area*mean1*mean2));
//        
//        return(coefCorr);
//    }