/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jObjetoMosca;

import java.awt.Point;
import java.util.List;

/**
 *
 * @author Felipe
 */
public class jListaMoscas {
    private String Path = "";
    private Point p1 = null;
    private Point p2 = null;
    private List  listPuntos = null;
    
    public jListaMoscas(String _path, Point _p1, Point _p2, List _lista){
        Path = _path;
        p1 = _p1;
        p2 = _p2;
        listPuntos = _lista;
    }
    public Point getP1(){
        return p1;
    }

    public Point getP2(){
        return p2;
    }
    public String getPath(){
        return Path;
    }
    public List getLista(){
        return listPuntos;
    }
}
