/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jObjetoMosca;

import java.awt.Point;
import java.io.File;

/**
 *
 * @author Felipe
 */
public class jObjetoAnalisis {
    
    private String nombreFile = null;
    private int i1 = -1;
    private int j1 = -1;
    
    private int Width  = -1;
    private int Height = -1;
    
    public jObjetoAnalisis(){}
    public void setPath(String _name){
        nombreFile = _name;
    }
    public void setPunto(int _i, int _j, int _Width, int _Height){
        i1 = _i;
        j1 = _j;
        
        Width  = _Width;
        Height = _Height;
    }
    public File getPath(){
        return(new File(nombreFile));
    }
    public Point getPunto(){
        return(new Point(i1, j1));
    }
    public Point getWithHeight(){
        return(new Point(Width, Height));
    }
}
