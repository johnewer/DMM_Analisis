/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package python;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

/**
 *
 * @author felipe
 */
public class ApachePOIExcelWrite {
    private static final String FILE_NAME = "myXls.xlsx";

    public static void main(String[] args) throws FileNotFoundException, IOException {
        FileInputStream file = new FileInputStream(new File(FILE_NAME));

        //Get the workbook instance for XLS file 
        HSSFWorkbook workbook = new HSSFWorkbook(file);

        //Get first sheet from the workbook
        HSSFSheet sheet = workbook.getSheetAt(0);

        //Get iterator to all the rows in current sheet
        Iterator<Row> rowIterator = sheet.iterator();
        
        
        Row row = rowIterator.next();
        //Get iterator to all cells of current row
        Iterator<Cell> cellIterator = row.cellIterator();
        

    }
}
