/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package python;

/**
 *
 * @author felipe
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public class PoiReadExcelFile {
    public static void main(String[] args) {
        try {
            FileInputStream fileInputStream = new FileInputStream("data_001.xls");
            HSSFWorkbook workbook = new HSSFWorkbook(fileInputStream);

//            HSSFSheet   worksheet = workbook.getSheet("POI Worksheet");
//            HSSFSheet   worksheet = workbook.getSheetAt(0);
            HSSFSheet worksheet     = workbook.createSheet("PO3 Worksheet");
            System.out.println(worksheet.getSheetName());
            
/*            
            HSSFRow     row1      = worksheet.getRow(0);
            HSSFCell    cellA1    = row1.getCell(0);
            String      a1Val     = cellA1.getStringCellValue();
            
            HSSFCell cellB1 = row1.getCell(1);
            String  b1Val   = cellB1.getStringCellValue();
            
            HSSFCell cellC1 = row1.getCell(2);
            boolean c1Val = cellC1.getBooleanCellValue();
            HSSFCell cellD1 = row1.getCell(3);
            Date d1Val = cellD1.getDateCellValue();
            
            System.out.println("A1: " + a1Val);
            System.out.println("B1: " + b1Val);
            System.out.println("C1: " + c1Val);
            System.out.println("D1: " + d1Val);
            
            */
            Row row1 = null;
            int indR = 3;
            if(worksheet.getRow(indR) == null)
                row1    = worksheet.createRow(indR);
            else
                row1    = worksheet.getRow(indR);
            
            
            Cell colum = null;
            int indC = 5;
            if(row1.getCell(indC) == null)
                colum = row1.createCell(indC);
            else
                colum = row1.getCell(indC);
            
            colum.setCellValue("Vivir");
            
            
            fileInputStream.close();
            FileOutputStream out = new FileOutputStream("data_001.xls");
            workbook.write(out);
            out.close();
            
            
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
