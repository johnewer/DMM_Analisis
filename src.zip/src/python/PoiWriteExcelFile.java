/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package python;

/**
 *
 * @author felipe
 */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

public class PoiWriteExcelFile {
    
    public static void main(String[] args) {
        FileInputStream fileInput   = null;
        try {
            fileInput = new FileInputStream("data_001.xls");
            HSSFWorkbook workbook = new HSSFWorkbook(fileInput);
            HSSFSheet worksheet0  = workbook.getSheetAt(0);
            HSSFSheet worksheet1  = workbook.getSheetAt(1);
            

            for(int x = 2; x<500; x++){
                Row rro = null;
                if(worksheet0.getRow(x) != null){
                    rro = worksheet0.getRow(x);
                    
                    for(int y=4; y< 20; y++){
                        Cell cellA1 = rro.getCell(y);
                        if(cellA1 != null)
                            rro.removeCell(cellA1);
                    }
                }
            }
            
/*
            HSSFSheet worksheet      = workbook.createSheet("PO3 Worksheet");            
            // index from 0,0... cell A1 is cell(0,0)
            HSSFRow row1 = worksheet.createRow(0);
            
            
            HSSFCell cellA1 = row1.createCell(0);
            cellA1.setCellValue("Hello");
            
            for(int i=1; i<10; i++){
                row1 = worksheet.createRow(i);
                cellA1 = row1.createCell(0);
                cellA1.setCellValue(2000.0 + i);
            }
            
            
            row1 = worksheet.getRow(0);
            
            HSSFCellStyle cellStyle = workbook.createCellStyle();
            cellStyle.setFillForegroundColor(HSSFColor.GOLD.index);
            cellA1.setCellStyle(cellStyle);
            
            HSSFCell cellB1 = row1.createCell(1);
            cellB1.setCellValue("Goodbye");
            cellStyle = workbook.createCellStyle();
            cellStyle.setFillForegroundColor(HSSFColor.LIGHT_CORNFLOWER_BLUE.index);
            cellB1.setCellStyle(cellStyle);
            
            HSSFCell cellC1 = row1.createCell(2);
            cellC1.setCellValue(true);
            
            HSSFCell cellD1 = row1.createCell(3);
            cellD1.setCellValue(new Date());
            cellStyle = workbook.createCellStyle();
            cellStyle.setDataFormat(HSSFDataFormat.getBuiltinFormat("m/d/yy h:mm"));
            
            cellD1.setCellStyle(cellStyle);
            
            row1 = worksheet.getRow(5);
            
            
            cellB1 = row1.getCell(0);
            cellB1.setCellValue(222.0);
  
            HSSFRow row1 = worksheet.createRow(0);
            
            for(int i=0; i<10; i++ ){
                row1 = worksheet.getRow(i);
                if(row1 == null)
                        row1 = worksheet.createRow(i);
                
                HSSFCell cellA1 = row1.createCell(2);
                cellA1.setCellValue(5000.0 + i*10);
            }
  */

            
            FileOutputStream fileOut = new FileOutputStream("data_001.xls");            
            workbook.write(fileOut);
            fileOut.flush();
            fileOut.close();
            
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    
    }
    
    
    
    
    
}
