import time
import sys

import numpy as np
import scipy.signal
from matplotlib import pyplot
import cv2



if __name__=='__main__':

	
	file = open("data_Python.txt", "r")
	Message = file.readlines();
	file.close();

		
	pathDir = Message[0];
	dd      = len(pathDir);
	pathDir = pathDir[:dd-1];

	punto = Message[1].split();
	dimen = Message[2].split();

	
#-----------------------------------------------------------------------------------
	kernel	 = np.ones((2, 2), np.uint8)

	img = cv2.imread(pathDir)
	img = img[:, :, 0] #Tomo capa azul, ya que NO tiene letras de hora
	img = cv2.morphologyEx(img, cv2.MORPH_CLOSE, kernel)
#-----------------------------------------------------------------------------------


	xi = int(punto[0]);
	yi = int(punto[1]);
	mWidth  = int(dimen[1]) + xi;
	mHeight = int(dimen[0]) + yi;

	img = img[yi:mHeight, xi:mWidth]


	cv2.namedWindow('IMAGEN')
	cv2.imshow('IMAGEN', img)
	cv2.waitKey(200)

	
	for x in range(0, 4):
		sys.stdout.write(str(x) + '\n')
	




