/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package python;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


/**
 *
 * @author felipe
 */
public class pruebaProceso {
    
    public pruebaProceso() throws IOException, InterruptedException{
        mensaje("entro");
        String line = "";
        
        Process p = new ProcessBuilder("ls -aF").start();
       
        BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
        line = input.readLine();
        
        while (line != null){
            mensaje(line);
        }
        input.close();
    }
    
    private void mensaje(Object _mensaje){
        System.out.println(_mensaje);
    }
    
    public static void main(String args[]) throws IOException, InterruptedException {
        String s;        
        Process p;
        
        File excel = new File("myXls.xlsx");
        FileInputStream fis = new FileInputStream(excel);
        XSSFWorkbook wb = new XSSFWorkbook(fis);
        XSSFSheet ws = wb.getSheet("Sheet1");
        
        int rowNum = ws.getLastRowNum() + 1;
        
        int colNum = ws.getRow(0).getLastCellNum();//reading total num of cols
        String[][] data = new String[rowNum][colNum];//allocating array based on row n col size

        for (int i=0; i<rowNum ; i++){
            XSSFRow row = ws.getRow(i);
            
            for( int j=0; j< colNum; j++) {
                XSSFCell cell = row.getCell(j);
//                String value = cellToString(cell);
                
                data[i][j] = String.valueOf(j);//based on its excel location, values will be stored in seperate array
                System.out.println( data[i][j]);
            }
        }

    }
}
