import time
import sys


if __name__=='__main__':

	data = sys.argv[1:];

	file = open("Archivo.txt", "w")
	file.write("Hola.." + '\n');
	file.write(data[0] + '\n');
	file.write(data[1] + '\n');
	file.close();		

	print(type(data[0]))

#	while(1):
	sys.stdout.write("Your string to Stdout\n")
	sys.stdout.write("Your string to Stdout\n")
	sys.stdout.write("Your string to Stdout\n")



